// 游戏场景定义
const gameScenes = {
    // 角色创建场景
    characterCreate: {
        title: "欢迎来到艾瑞亚大陆",
        desc: "这片神秘的土地充满了冒险与挑战。在开始你的旅程之前，请为自己取一个名字吧。",
        options: []
    },
    
    // 苏醒场景
    wakeUp: {
        title: "苏醒",
        desc: "你在一间简陋的小木屋里醒来，阳光透过窗户洒在地板上。一位慈祥的老者坐在你的床边，看到你醒来露出了微笑。",
        options: [
            {
                text: "询问老者这里是哪里",
                nextScene: "elderIntroduction",
                action: null
            },
            {
                text: "检查自己的状况",
                nextScene: "checkStatus",
                action: null
            }
        ]
    },
    
    // 村长介绍
    elderIntroduction: {
        title: "村长的介绍",
        desc: "老者：“你终于醒了！这里是晨曦村，我是村长。三天前我们发现你晕倒在村外，就把你救回来了。看你的样子，像是一位旅行者？”",
        options: [
            {
                text: "是的，我是一名冒险者",
                nextScene: "villageGuide",
                action: null
            },
            {
                text: "我记不清自己是谁了",
                nextScene: "villageGuide",
                action: null
            }
        ]
    },
    
    // 检查状态
    checkStatus: {
        title: "检查状态",
        desc: "你感觉身体有些虚弱，但并无大碍。身上穿着简单的粗布衣服，旁边放着一把新手木剑。背包里有两瓶新手药水。",
        options: [
            {
                text: "向老者询问情况",
                nextScene: "elderIntroduction",
                action: null
            }
        ]
    },
    
    // 村庄指引
    villageGuide: {
        title: "村庄指引",
        desc: "村长：“晨曦村是这片地区最安全的地方。村外有一些低级怪物，正好适合你这样的新手历练。对了，最近沼泽里的绿皮青蛙越来越多，已经开始破坏农田了，如果你能帮忙解决这个问题，我会给你奖励。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）",
                    rewardData: {
                        gold: 20,
                        exp: 50,
                        item: {
                            name: "麻布手套",
                            effect: "防御+1",
                            defense: 1,
                            type: "armor",
                            slot: "hand"
                        }
                    }
                }
            },
            {
                text: "先了解一下村庄",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },
    
    // 村庄广场
    villageSquare: {
        title: "晨曦村广场",
        desc: "这是晨曦村的中心广场，有几位村民在这里活动。广场周围有几间重要的建筑：村长家、装备商店和村医的小屋。村口有一条路通向外面的世界。",
        options: [
            {
                text: "前往村长家（可接取任务）",
                nextScene: "villageElderHome",
                action: null
            },
            {
                text: "前往装备商店（购买装备）",
                nextScene: "villageShop",
                action: null
            },
            {
                text: "去村医的小屋（恢复生命/购买药水）",
                nextScene: "villageClinic",
                action: null
            },
            {
                text: "前往村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },
    
    // 村长家
    villageElderHome: {
        title: "村长家",
        desc: "村长正在整理一些文件，看到你进来便放下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "villageElderQuest",
                action: null
            },
            {
                text: "询问关于村外世界的信息",
                nextScene: "villageElderWorldInfo",
                action: null
            },
            {
                text: "离开村长家",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },
    
    // 村长任务
    villageElderQuest: {
        title: "村长的任务",
        desc: "村长：“目前最紧急的就是沼泽里的绿皮青蛙问题，它们破坏了我们的农田。如果你能消灭3只绿皮青蛙，我会给你不错的奖励。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）",
                    rewardData: {
                        gold: 20,
                        exp: 50,
                        item: {
                            name: "麻布手套",
                            effect: "防御+1",
                            defense: 1,
                            type: "armor",
                            slot: "hand"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    
    // 村长介绍世界
    villageElderWorldInfo: {
        title: "村外的世界",
        desc: "村长：“我们晨曦村只是艾瑞亚大陆的一个小村庄。向东是迷雾森林，里面有不少野兔和野狼；向南是沼泽地，那里是绿皮青蛙的栖息地；向西是平原，一直延伸到比奇城。”",
        options: [
            {
                text: "询问关于怪物的信息",
                nextScene: "villageElderMonsterInfo",
                action: null
            },
            {
                text: "感谢村长的介绍",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    
    // 村长介绍怪物
    villageElderMonsterInfo: {
        title: "关于怪物",
        desc: "村长：“绿皮青蛙生活在沼泽，攻击力不高但会轻微中毒；尖牙野兔在森林边缘活动，速度较快；森林深处有野狼，比较危险。你现在的实力，建议先从绿皮青蛙或野兔开始历练。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）",
                    rewardData: {
                        gold: 20,
                        exp: 50,
                        item: {
                            name: "麻布手套",
                            effect: "防御+1",
                            defense: 1,
                            type: "armor",
                            slot: "hand"
                        }
                    }
                }
            },
            {
                text: "返回村长家",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    
    // 装备商店
    villageShop: {
        title: "装备商店",
        desc: "商店老板：“欢迎光临！我这里有一些适合新手的装备，看看有没有需要的？” 在售商品：1. 麻布头盔（防御+1，售价15金币） 2. 粗布护肩（防御+1，售价15金币） 3. 新手药水（恢复20点生命值，售价10金币）",
        options: [
            {
                text: "购买麻布头盔（15金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: { 
                    name: "麻布头盔", 
                    effect: "防御+1", 
                    defense: 1,
                    type: "armor",
                    slot: "head",
                    price: 15
                }
            },
            {
                text: "购买粗布护肩（15金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: { 
                    name: "粗布护肩", 
                    effect: "防御+1", 
                    defense: 1,
                    type: "armor",
                    slot: "shoulder",
                    price: 15
                }
            },
            {
                text: "购买新手药水（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: { 
                    name: "新手药水", 
                    effect: "恢复20点生命值", 
                    type: "potion",
                    price: 10
                }
            },
            {
                text: "离开装备商店",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },
    
    // 村医小屋
    villageClinic: {
        title: "村医的小屋",
        desc: "屋内弥漫着草药的气味，村医正在整理药草。看到你进来，她微笑着打招呼。",
        options: [
            {
                text: "治疗伤势（恢复满生命值，5金币）",
                nextScene: "villageClinic",
                action: "restoreHp",
                actionData: { type: "full", cost: 5 }
            },
            {
                text: "购买新手药水（10金币）",
                nextScene: "villageClinic",
                action: "buyItem",
                actionData: { 
                    name: "新手药水", 
                    effect: "恢复20点生命值", 
                    type: "potion",
                    price: 10
                }
            },
            {
                text: "离开村医的小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },
    
    // 村口
    villageEntrance: {
        title: "晨曦村村口",
        desc: "这里是晨曦村的出口，一条小路通向外面的世界。向东可以看到茂密的森林，向南则是一片沼泽地。",
        options: [
            {
                text: "前往沼泽地（绿皮青蛙）",
                nextScene: "swampArea",
                action: null
            },
            {
                text: "前往森林边缘（尖牙野兔）",
                nextScene: "forestEdge",
                action: null
            },
            {
                text: "返回村庄",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },
    
    // 沼泽地区
    swampArea: {
        title: "沼泽地区",
        desc: "浑浊的沼泽水泛着绿光，不时有气泡冒出。几只绿色的青蛙在沼泽中跳跃，正是你要找的绿皮青蛙。",
        options: [
            {
                text: "攻击绿皮青蛙",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    name: "绿皮青蛙",
                    level: 1,
                    hp: 20,
                    attack: 3,
                    defense: 0,
                    exp: 10,
                    drop: { name: "青蛙腿", count: 1, type: "烹饪材料" },
                    trait: "移动速度慢，攻击附带轻微中毒效果"
                }
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },
    
    // 森林边缘
    forestEdge: {
        title: "森林边缘",
        desc: "这里是森林的边缘地带，树木不算茂密，阳光可以照到地面。几只长着尖锐牙齿的野兔正在啃食青草，看到你靠近便警惕地抬起头。",
        options: [
            {
                text: "攻击尖牙野兔",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    name: "尖牙野兔",
                    level: 2,
                    hp: 25,
                    attack: 4,
                    defense: 0,
                    exp: 15,
                    drop: { name: "野兔肉", count: 1, type: "食材" },
                    trait: "警惕性高，被攻击后会迅速逃跑"
                }
            },
            {
                text: "深入森林",
                nextScene: "forestDeep",
                action: null
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },
    
    // 森林深处
    forestDeep: {
        title: "森林深处",
        desc: "这里树木茂密，光线昏暗。你能听到远处传来狼嚎声，地面上有一些大型动物的脚印。",
        options: [
            {
                text: "继续探索",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    name: "森林野狼",
                    level: 3,
                    hp: 40,
                    attack: 6,
                    defense: 1,
                    exp: 25,
                    drop: { name: "狼皮", count: 1, type: "皮革材料" },
                    trait: "凶猛，会撕咬攻击"
                }
            },
            {
                text: "返回森林边缘",
                nextScene: "forestEdge",
                action: null
            }
        ]
    },
    
    // 战斗场景
    battle: {
        title: "战斗中",
        desc: "", // 动态生成
        options: [
            { text: "普通攻击", action: "playerAttack" },
            { text: "使用道具", action: "useItem" },
            { text: "尝试逃跑", action: "escapeBattle" }
        ]
    },
    
    // 任务完成场景
    questCompleted: {
        title: "任务完成",
        desc: "你已经完成了任务目标，可以返回村庄向发布者领取奖励了。",
        options: [
            {
                text: "返回晨曦村",
                nextScene: "villageSquare",
                action: null
            },
            {
                text: "继续在此区域冒险",
                nextScene: (game) => {
                    // 根据完成的任务决定返回哪个场景
                    return game.player.quests.completed.includes("frogKill") ? "swampArea" : "forestEdge";
                },
                action: null
            }
        ]
    }
};
    