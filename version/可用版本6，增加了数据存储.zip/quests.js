// 任务数据定义 - 根据设计文档完善任务系统
const gameQuests = {
    // 晨曦村主线任务链
    "frogKill": {
        id: "frogKill",
        name: "消灭绿皮青蛙",
        type: "main",
        level: 1,
        area: "晨曦村",
        npc: "村长",
        target: "绿皮青蛙",
        targetCount: 3,
        description: "沼泽里的绿皮青蛙越来越多，已经开始破坏晨曦村的农田，村长希望你能帮忙解决这个问题。",
        reward: {
            gold: 20,
            exp: 50,
            items: ["普通的麻布手套"]
        },
        prerequisite: null,
        nextQuest: "rabbitInvestigation"
    },

    "rabbitInvestigation": {
        id: "rabbitInvestigation",
        name: "森林调查",
        type: "side",
        level: 2,
        area: "晨曦村",
        npc: "猎人汤姆",
        target: "尖牙野兔",
        targetCount: 5,
        description: "猎人汤姆发现森林边缘的野兔最近变得异常凶猛，请求你帮忙调查。",
        reward: {
            gold: 30,
            exp: 80,
            items: ["优秀的皮革护腕"]
        },
        prerequisite: "frogKill",
        nextQuest: "wolfThreat"
    },

    "wolfThreat": {
        id: "wolfThreat",
        name: "森林深处的威胁",
        type: "side",
        level: 3,
        area: "晨曦村",
        npc: "猎人汤姆",
        target: "森林野狼",
        targetCount: 3,
        description: "猎人汤姆发现森林深处有狼群活动，担心威胁到村庄安全。",
        reward: {
            gold: 50,
            exp: 120,
            items: ["优秀的皮头盔"]
        },
        prerequisite: "rabbitInvestigation",
        nextQuest: "toBichiVillage"
    },

    // 比奇村主线任务链
    "toBichiVillage": {
        id: "toBichiVillage",
        name: "前往比奇村",
        type: "main",
        level: 5,
        area: "晨曦村",
        npc: "村长",
        target: null,
        targetCount: 0,
        description: "村长认为你已经有足够的实力去更大的村庄冒险，并介绍比奇村的情况。",
        reward: {
            gold: 100,
            exp: 200
        },
        prerequisite: "wolfThreat",
        nextQuest: "farmProtector"
    },

    "farmProtector": {
        id: "farmProtector",
        name: "农田守护者",
        type: "main",
        level: 5,
        area: "比奇村",
        npc: "村长",
        target: "狂暴野猪",
        targetCount: 10,
        description: "比奇村外的农田被狂暴野猪破坏，需要你帮忙清理。",
        reward: {
            gold: 150,
            exp: 300,
            items: ["精良的精铁护肩"]
        },
        prerequisite: "toBichiVillage",
        nextQuest: "mineExploration"
    },

    "mineExploration": {
        id: "mineExploration",
        name: "矿洞探险",
        type: "side",
        level: 6,
        area: "比奇村",
        npc: "铁匠鲍勃",
        target: "红眼蝙蝠",
        targetCount: 5,
        description: "铁匠需要铁矿石打造装备，但矿井里有蝙蝠骚扰。",
        reward: {
            gold: 200,
            exp: 400,
            items: ["精良的精铁剑", "铁矿镐"]
        },
        prerequisite: "farmProtector",
        nextQuest: "toNangongVillage"
    },

    // 南宫村主线任务链
    "toNangongVillage": {
        id: "toNangongVillage",
        name: "前往南宫村",
        type: "main",
        level: 8,
        area: "比奇村",
        npc: "村长",
        target: null,
        targetCount: 0,
        description: "村长听说南宫村有一位著名的锻造大师，推荐你去学习高级锻造技术。",
        reward: {
            gold: 300,
            exp: 500
        },
        prerequisite: "mineExploration",
        nextQuest: "poisonThreat"
    },

    "poisonThreat": {
        id: "poisonThreat",
        name: "毒刺威胁",
        type: "main",
        level: 8,
        area: "南宫村",
        npc: "锻造大师李",
        target: "毒刺天牛",
        targetCount: 6,
        description: "毒刺天牛在矿洞外活动，影响了矿石采集，需要你帮忙解决。",
        reward: {
            gold: 60,
            exp: 90,
            items: ["精良的抗毒皮甲"]
        },
        prerequisite: "toNangongVillage",
        nextQuest: "giantPoisonBeetle"
    },

    "giantPoisonBeetle": {
        id: "giantPoisonBeetle",
        name: "精英挑战：巨型毒刺天牛",
        type: "side",
        level: 9,
        area: "南宫村",
        npc: "锻造大师李",
        target: "巨型毒刺天牛",
        targetCount: 1,
        description: "矿洞深处有一只变异的巨型毒刺天牛，威胁着整个矿区的安全。",
        reward: {
            gold: 100,
            exp: 150,
            items: ["史诗的毒刺剑", "高级锻造配方"]
        },
        prerequisite: "poisonThreat",
        nextQuest: "toTianjinTown"
    },

    // 天津镇主线任务链
    "toTianjinTown": {
        id: "toTianjinTown",
        name: "前往天津镇",
        type: "main",
        level: 10,
        area: "南宫村",
        npc: "锻造大师李",
        target: null,
        targetCount: 0,
        description: "锻造大师建议你前往天津镇，那里是通往第二大陆的门户。",
        reward: {
            gold: 500,
            exp: 800
        },
        prerequisite: "giantPoisonBeetle",
        nextQuest: "sailingPermit"
    },

    "sailingPermit": {
        id: "sailingPermit",
        name: "航海许可",
        type: "main",
        level: 10,
        area: "天津镇",
        npc: "港口管理员王",
        target: "巨钳蟹",
        targetCount: 1,
        description: "要前往第二大陆，必须获得航海许可证，而许可证被藏在巨钳蟹的巢穴里。",
        reward: {
            gold: 120,
            exp: 180,
            items: ["史诗的蟹钳剑", "航海许可证"]
        },
        prerequisite: "toTianjinTown",
        nextQuest: "secondContinentCall"
    },

    "secondContinentCall": {
        id: "secondContinentCall",
        name: "第二大陆的召唤",
        type: "main",
        level: 10,
        area: "天津镇",
        npc: "港口管理员王",
        target: null,
        targetCount: 0,
        description: "获得航海许可证后，你可以前往更危险但也更富饶的第二大陆冒险。",
        reward: {
            unlock: "瓦尔哈拉荒原"
        },
        prerequisite: "sailingPermit",
        nextQuest: null
    },

    // 获取任务数据的方法
    getQuest: function (questId) {
        return this[questId] ? { ...this[questId] } : null;
    },

    // 获取可接取的任务列表
    getAvailableQuests: function (completedQuests, playerLevel) {
        let available = [];

        Object.values(this).forEach(quest => {
            // 检查等级要求
            if (quest.level > playerLevel) return;

            // 检查前置任务
            if (quest.prerequisite && !completedQuests.includes(quest.prerequisite)) return;

            // 检查是否已经完成
            if (completedQuests.includes(quest.id)) return;

            available.push(quest);
        });

        return available;
    },

    // 获取区域任务
    getQuestsByArea: function (area) {
        let quests = [];

        Object.values(this).forEach(quest => {
            if (quest.area === area) {
                quests.push(quest);
            }
        });

        return quests;
    }
};