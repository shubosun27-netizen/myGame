// 游戏控制类 - 管理游戏流程和场景切换
class Game {
    constructor() {
        // 初始化玩家
        this.player = new Player();
        
        // 检查是否有保存的数据，如果有则设置正确的场景，否则默认为角色创建
        const savedData = localStorage.getItem('playerData');
        if (savedData) {
            // 有保存数据，说明角色已经创建过，设置默认场景为villageGuide
            this.currentScene = "villageSquare";
        } else {
            // 没有保存数据，说明需要创建角色
            this.currentScene = "characterCreate";
        }
        
        // 当前战斗中的怪物
        this.currentMonster = null;
        // 待领取的奖励
        this.pendingReward = null;
        // DOM元素引用
        this.elements = this.initElements();
        // 绑定事件
        this.bindEvents();
        // 初始化声音系统
        this.initAudio();

        // 全局品质颜色映射
        this.qualityColors = {
            "普通": "#FFFFFF", // 白色
            "优秀": "#00FF00", // 绿色
            "精良": "#0070FF", // 蓝色
            "史诗": "#A335EE", // 紫色
            "传说": "#FF8000"  // 橙色
        };

        // 装备槽位定义
        this.equipmentSlots = [
            { slot: "weapon", name: "武器" },
            { slot: "head", name: "头盔" },
            { slot: "shoulder", name: "护肩" },
            { slot: "body", name: "胸甲" },
            { slot: "leg", name: "护腿" },
            { slot: "foot", name: "靴子" },
            { slot: "hand", name: "手套" },
            { slot: "bracelet", name: "手镯" },
            { slot: "necklace", name: "项链" }
        ];

        // 初始化游戏
        this.init();
    }

    // 初始化声音系统
    initAudio() {
        // 背景音乐
        this.audio = {
            backgroundMusic: new Audio("res/sound/beijing.mp3"),
            battleMusic: new Audio("res/sound/yewai.mp3"),
            mineMusic: new Audio("res/sound/dongxue.mp3"), // 新增矿洞音乐
            clickSound: new Audio("res/sound/dianji1.mp3"),
            battleSound: new Audio("res/sound/battle.mp3"),
            playerGongjiSound: new Audio("res/sound/gongji1a.mp3"),
            monsterGongjiSound: new Audio("res/sound/gongji1b.mp3"),
        };

        // 设置背景音乐循环播放
        this.audio.backgroundMusic.loop = true;
        this.audio.battleMusic.loop = true;
        this.audio.mineMusic.loop = true; // 设置矿洞音乐循环播放

        // 设置音量
        this.audio.backgroundMusic.volume = 0.5;
        this.audio.battleMusic.volume = 0.4;
        this.audio.mineMusic.volume = 0.4; // 设置矿洞音乐音量
        this.audio.clickSound.volume = 0.3;
        this.audio.battleSound.volume = 0.3;

        // 当前播放的音乐
        this.currentMusic = null;
    }

    // 播放背景音乐
    playBackgroundMusic(sceneId) {
        // 停止当前音乐
        if (this.currentMusic) {
            this.currentMusic.pause();
            this.currentMusic.currentTime = 0;
        }

        // 根据场景选择音乐
        let musicToPlay = null;

        // 战斗场景播放野外音乐
        if (sceneId === "battle") {
            musicToPlay = this.audio.battleSound;
        }
        // 矿洞场景播放矿洞音乐
        else if (sceneId === "bichiMineEntrance" ||
            sceneId === "bichiMineInterior" ||
            sceneId === "bichiMineDeep") {
            musicToPlay = this.audio.mineMusic;
        }
        // 村庄、室内场景播放背景音乐
        else if (sceneId === "villageSquare" ||
            sceneId === "villageShop" ||
            sceneId === "villageClinic" ||
            sceneId === "hunterCabin" ||
            sceneId === "bichiElderHome" ||
            sceneId === "blacksmithShop" ||
            sceneId === "bichiEquipmentShop" ||
            sceneId === "characterCreate" ||
            sceneId === "wakeUp" ||
            sceneId === "elderIntroduction" ||
            sceneId === "checkStatus" ||
            sceneId === "villageElderQuest" ||
            sceneId === "villageElderWorldInfo" ||
            sceneId === "villageGuide" ||
            sceneId === "hunterQuest" ||
            sceneId === "hunterDeepForestInfo" ||
            sceneId === "hunterQuestCompleted" ||
            sceneId === "bichiElderQuest" ||
            sceneId === "bichiElderNangongInfo" ||
            sceneId === "blacksmithQuest") {
            musicToPlay = this.audio.backgroundMusic;
        }
        // 野外场景也播放野外音乐
        else if (sceneId === "villageEntrance" ||
            sceneId === "swampArea" ||
            sceneId === "forestEdge" ||
            sceneId === "forestDeep" ||
            sceneId === "bichiVillageEntrance" ||
            sceneId === "farmArea" ||
            sceneId === "mineArea" ||
            sceneId === "nangongVillageEntrance") {
            musicToPlay = this.audio.battleMusic;
        }

        // 播放新音乐
        if (musicToPlay) {
            musicToPlay.play().catch(e => {
                console.log("音乐播放失败:", e);
            });
            this.currentMusic = musicToPlay;
        }
    }

    // 播放点击音效
    playClickSound() {
        this.audio.clickSound.currentTime = 0;
        this.audio.clickSound.play().catch(e => {
            console.log("点击音效播放失败:", e);
        });
    }

    // 初始化DOM元素引用
    initElements() {
        return {
            // 导航按钮
            gameNavBtn: document.getElementById("gameNavBtn"),
            inventoryNavBtn: document.getElementById("inventoryNavBtn"),
            equipmentNavBtn: document.getElementById("equipmentNavBtn"),

            // 页面容器
            gamePage: document.getElementById("gamePage"),
            inventoryPage: document.getElementById("inventoryPage"),
            equipmentPage: document.getElementById("equipmentPage"),

            // 状态面板元素
            playerName: document.getElementById("playerName"),
            level: document.getElementById("level"),
            hp: document.getElementById("hp"),
            maxHp: document.getElementById("maxHp"),
            gold: document.getElementById("gold"),
            attack: document.getElementById("attack"),
            defense: document.getElementById("defense"),

            // 场景元素
            sceneTitle: document.getElementById("sceneTitle"),
            sceneDesc: document.getElementById("sceneDesc"),
            optionsContainer: document.getElementById("optionsContainer"),
            characterName: document.getElementById("characterName"),
            startBtn: document.getElementById("startBtn"),
            characterCreatePanel: document.getElementById("characterCreatePanel"),

            // 任务面板
            activeQuestPanel: document.getElementById("activeQuestPanel"),
            activeQuestName: document.getElementById("activeQuestName"),
            activeQuestTarget: document.getElementById("activeQuestTarget"),
            activeQuestProgress: document.getElementById("activeQuestProgress"),
            activeQuestReward: document.getElementById("activeQuestReward"),
            abandonQuestBtn: document.getElementById("abandonQuestBtn"),

            // 背包页面元素
            inventoryList: document.getElementById("inventoryList"),
            backFromInventory: document.getElementById("backFromInventory"),

            // 装备页面元素
            equipmentSlots: document.getElementById("equipmentSlots"),
            backFromEquipment: document.getElementById("backFromEquipment"),

            // 弹窗元素
            modal: document.getElementById("modal"),
            modalTitle: document.getElementById("modalTitle"),
            modalDesc: document.getElementById("modalDesc"),
            modalBtn: document.getElementById("modalBtn"),

            expBar: document.getElementById("expBar"),
            expBarFill: document.querySelector(".exp-bar-fill"), // 新增
            expRatio: document.getElementById("expRatio")
        };
    }

    // 绑定事件处理程序
    bindEvents() {
        // 导航按钮事件 - 添加点击音效
        this.elements.gameNavBtn.addEventListener("click", () => {
            this.playClickSound();
            this.navigateTo("game");
        });
        this.elements.inventoryNavBtn.addEventListener("click", () => {
            this.playClickSound();
            // 检查是否已创建角色
            if (this.elements.characterCreatePanel.classList.contains("hidden")) {
                this.navigateTo("inventory");
                this.renderInventory();
            } else {
                this.showModal("提示", "请先创建角色");
            }
        });
        this.elements.equipmentNavBtn.addEventListener("click", () => {
            this.playClickSound();
            // 检查是否已创建角色
            if (this.elements.characterCreatePanel.classList.contains("hidden")) {
                this.navigateTo("equipment");
                this.renderEquipment();
            } else {
                this.showModal("提示", "请先创建角色");
            }
        });

        // 返回按钮事件 - 添加点击音效
        this.elements.backFromInventory.addEventListener("click", () => {
            this.playClickSound();
            this.navigateTo("game");
        });
        this.elements.backFromEquipment.addEventListener("click", () => {
            this.playClickSound();
            this.navigateTo("game");
        });

        // 开始游戏按钮 - 添加点击音效
        this.elements.startBtn.addEventListener("click", () => {
            this.playClickSound();
            this.startGame();
        });

        // 弹窗按钮 - 添加点击音效
        this.elements.modalBtn.addEventListener("click", () => {
            this.playClickSound();
            this.elements.modal.classList.add("hidden");
            this.renderScene();
        });

        // 放弃任务按钮事件 - 添加点击音效
        this.elements.abandonQuestBtn.addEventListener("click", () => {
            this.playClickSound();
            this.abandonCurrentQuest();
        });
    }

    // 导航到不同页面
    navigateTo(page) {
        // 隐藏所有页面
        this.elements.gamePage.classList.remove("active");
        this.elements.inventoryPage.classList.remove("active");
        this.elements.equipmentPage.classList.remove("active");

        // 移除所有导航按钮的活跃状态
        this.elements.gameNavBtn.classList.remove("active");
        this.elements.inventoryNavBtn.classList.remove("active");
        this.elements.equipmentNavBtn.classList.remove("active");

        // 显示目标页面并激活对应导航按钮
        if (page === "game") {
            this.elements.gamePage.classList.add("active");
            this.elements.gameNavBtn.classList.add("active");
        } else if (page === "inventory") {
            this.elements.inventoryPage.classList.add("active");
            this.elements.inventoryNavBtn.classList.add("active");
        } else if (page === "equipment") {
            this.elements.equipmentPage.classList.add("active");
            this.elements.equipmentNavBtn.classList.add("active");
        }
    }

    // 初始化游戏
    init() {
        // 检查是否有保存的数据
        const savedData = localStorage.getItem('playerData');
        if (savedData) {
            // 有保存数据，隐藏角色创建面板，显示选项容器
            this.elements.characterCreatePanel.classList.add("hidden");
            this.elements.optionsContainer.classList.remove("hidden");
        }
        
        // 渲染场景
        this.renderScene();
    }

    // 开始游戏 - 从角色创建进入第一个场景
    startGame() {
        // 设置玩家名称
        this.player.setName(this.elements.characterName.value.trim());
        // 隐藏角色创建面板
        this.elements.characterCreatePanel.classList.add("hidden");
        // 显示选项容器
        this.elements.optionsContainer.classList.remove("hidden");
        // 切换到第一个场景
        this.currentScene = "wakeUp";
        // 播放场景对应的背景音乐
        this.playBackgroundMusic(this.currentScene);
        // 渲染场景
        this.renderScene();
        
        // 保存玩家数据
        this.savePlayerData();
    }

    // 渲染当前场景
    renderScene() {
        const scene = gameScenes[this.currentScene];
        if (!scene) return;
        this.elements.sceneTitle.textContent = scene.title;

        // 特殊处理战斗场景描述
        if (this.currentScene === "battle" && this.currentMonster) {
            this.elements.sceneDesc.innerHTML = `
                <div class="battle-info">
                    <p>当前对手：<span class="highlight">${this.currentMonster.name}（${this.currentMonster.level}级）</span></p>
                    <p>怪物生命值：<span class="highlight">${this.currentMonster.hp}/${this.currentMonster.maxHp}</span></p>
                    <p>怪物特性：<span class="highlight">${this.currentMonster.trait}</span></p>
                    <p>你的生命值：<span class="highlight">${this.player.hp}/${this.player.maxHp}</span></p>
                    ${this.currentMonster.name.includes("BOSS") ? '<p class="boss-warning">⚠️ BOSS警告：会释放范围技能，请谨慎应对！</p>' : ''}
                </div>
                你与${this.currentMonster.name}展开了战斗！
            `;
        } else {
            this.elements.sceneDesc.textContent = scene.desc;
        }

        // 清空选项容器
        this.elements.optionsContainer.innerHTML = "";

        // 生成场景选项
        if (scene.options && scene.options.length > 0) {
            scene.options.forEach((option) => {
                const btn = document.createElement("button");
                btn.className = "option-btn";
                btn.textContent = this.getOptionText(option);
                btn.addEventListener("click", () => {
                    this.handleOptionSelect(option);
                });
                this.elements.optionsContainer.appendChild(btn);
            });
        }

        // 更新玩家状态面板
        this.updateStatusPanel();

        // 更新任务面板
        this.updateQuestPanel();
    }

    // 渲染背包页面
    renderInventory() {
        this.elements.inventoryList.innerHTML = "";

        // 显示物品
        if (this.player.inventory.items.length > 0) {
            this.player.inventory.items.forEach((item, index) => {
                const itemSlot = document.createElement("div");
                itemSlot.className = "item-slot";
                itemSlot.innerHTML = `
                    <p>${item.name}（${item.count}个）</p>
                    <p>${item.effect}</p>
                    <div class="item-actions">
                        <button class="item-action-btn use" data-index="${index}" data-type="item">使用</button>
                        <button class="item-action-btn sell" data-index="${index}" data-type="item">出售</button>
                    </div>
                `;
                this.elements.inventoryList.appendChild(itemSlot);
            });
        } else {
            const emptySlot = document.createElement("div");
            emptySlot.className = "item-slot";
            emptySlot.innerHTML = "<p>暂无道具</p>";
            this.elements.inventoryList.appendChild(emptySlot);
        }

        // 添加分隔线
        const divider = document.createElement("div");
        divider.style.height = "1px";
        divider.style.backgroundColor = "#555";
        divider.style.margin = "15px 0";
        this.elements.inventoryList.appendChild(divider);

        // 显示装备
        if (this.player.inventory.equipment.length > 0) {
            this.player.inventory.equipment.forEach((item, index) => {
                const itemSlot = document.createElement("div");
                itemSlot.className = "item-slot";

                // 使用全局的品质颜色映射
                const qualityColor = this.qualityColors[item.quality] || "#FFFFFF";

                itemSlot.innerHTML = `
                    <p><span style="color: ${qualityColor}">${item.name}</span></p>
                    <p>${item.effect}</p>
                    <div class="item-actions">
                        <button class="item-action-btn equip" data-index="${index}" data-type="equipment">装备</button>
                        <button class="item-action-btn sell-equipment" data-index="${index}" data-type="equipment">出售</button>
                    </div>
                `;
                this.elements.inventoryList.appendChild(itemSlot);
            });
        } else {
            const emptySlot = document.createElement("div");
            emptySlot.className = "item-slot";
            emptySlot.innerHTML = "<p>暂无装备</p>";
            this.elements.inventoryList.appendChild(emptySlot);
        }

        // 绑定背包物品按钮事件 - 添加点击音效
        document.querySelectorAll(".item-action-btn.use").forEach(btn => {
            btn.addEventListener("click", (e) => {
                this.playClickSound();
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.useItem(index);
                if (result.success) {
                    this.showModal("使用成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("使用失败", result.message);
                }
            });
        });

        document.querySelectorAll(".item-action-btn.sell").forEach(btn => {
            btn.addEventListener("click", (e) => {
                this.playClickSound();
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.sellItem(index);
                if (result.success) {
                    this.showModal("出售成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("出售失败", result.message);
                }
            });
        });

        document.querySelectorAll(".item-action-btn.equip").forEach(btn => {
            btn.addEventListener("click", (e) => {
                this.playClickSound();
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.equipItem(index);
                if (result.success) {
                    this.showModal("装备成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                    this.renderEquipment();
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("装备失败", result.message);
                }
            });
        });

        // 绑定装备出售按钮事件 - 新增
        document.querySelectorAll(".item-action-btn.sell-equipment").forEach(btn => {
            btn.addEventListener("click", (e) => {
                this.playClickSound();
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.sellEquipment(index);
                if (result.success) {
                    this.showModal("出售成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("出售失败", result.message);
                }
            });
        });
    }

    // 渲染装备页面
    renderEquipment() {
        this.elements.equipmentSlots.innerHTML = "";

        // 渲染每个装备槽位
        this.equipmentSlots.forEach(({ slot, name }) => {
            const equipment = this.player.equipment[slot];
            const slotElement = document.createElement("div");
            slotElement.className = `equipment-slot ${equipment ? "" : "empty"}`;

            if (equipment) {
                // 获取装备品质对应的颜色
                const qualityColor = this.qualityColors[equipment.quality] || "#FFFFFF";

                slotElement.innerHTML = `
                    <p>${name}：<span style="color: ${qualityColor}">${equipment.name}</span></p>
                    <p>${equipment.effect}</p>
                    <div class="item-actions">
                        <button class="item-action-btn unequip" data-slot="${slot}">卸下</button>
                    </div>
                `;
            } else {
                slotElement.innerHTML = `<p>${name}：无</p>`;
            }

            this.elements.equipmentSlots.appendChild(slotElement);
        });

        // 绑定卸下装备按钮事件 - 添加点击音效
        document.querySelectorAll(".item-action-btn.unequip").forEach(btn => {
            btn.addEventListener("click", (e) => {
                this.playClickSound();
                const slot = e.currentTarget.dataset.slot;
                const result = this.player.unequipItem(slot);
                if (result.success) {
                    this.showModal("卸下装备", result.message);
                    this.updateStatusPanel();
                    this.renderEquipment();
                    this.renderInventory();
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("操作失败", result.message);
                }
            });
        });
    }

    // 获取选项文本（处理动态文本）
    getOptionText(option) {
        if (option.action === "useItem" && this.player.inventory.items.length === 0) {
            return "使用道具（无可用道具）";
        }
        return option.text;
    }

    // 处理选项选择
    handleOptionSelect(option) {
        // 播放点击音效
        this.playClickSound();

        // 处理动态场景
        if (typeof option.nextScene === "function") {
            option.nextScene = option.nextScene(this);
        }

        // 执行选项动作
        if (option.action) {
            const actionResult = this.executeAction(option.action, option.actionData);
            if (!actionResult) return; // 动作执行失败（如没钱买装备）
        }

        // 切换到下一场景
        if (option.nextScene) {
            this.currentScene = option.nextScene;
            // 播放场景对应的背景音乐
            this.playBackgroundMusic(this.currentScene);
            this.renderScene();
        }

        // 自动保存玩家数据
        this.savePlayerData();
    }

    // 保存玩家数据到localStorage
    savePlayerData() {
        if (this.player && typeof this.player.saveToStorage === 'function') {
            return this.player.saveToStorage();
        }
        return false;
    }

    // 放弃当前任务
    abandonCurrentQuest() {
        if (this.player.currentQuest) {
            const questName = this.player.currentQuest.name;
            this.player.abandonQuest();
            this.updateQuestPanel();
            this.showModal("放弃任务", `你已放弃任务【${questName}】`);
            this.savePlayerData(); // 保存数据
        }
    }

    // 执行动作（如获取物品、接受任务）
    executeAction(actionType, actionData) {
        switch (actionType) {
            // 获取物品
            case "getItem":
                const item = this.player.getItem(actionData);
                this.showModal("获得物品", `你获得了${item.name}（${item.effect}）！`);
                this.renderInventory(); // 更新背包显示
                this.savePlayerData(); // 保存数据
                return true;

            // 接受任务
            case "acceptQuest":
                const questResult = this.player.acceptQuest(actionData);
                if (questResult.success) {
                    // 根据任务类型显示不同的提示信息
                    let targetText = "";
                    if (questResult.quest.target && questResult.quest.targetCount > 0) {
                        // 打怪任务
                        targetText = `目标：消灭${questResult.quest.targetCount}只${questResult.quest.target}`;
                    } else if (questResult.quest.target) {
                        // 导航任务（有目标地点但不需要打怪）
                        targetText = `目标：${questResult.quest.target}`;
                    } else {
                        // 纯导航任务
                        targetText = `目标：完成导航任务`;
                    }

                    this.showModal("接受任务",
                        `你接受了任务【${questResult.quest.name}】\n` +
                        `${targetText}\n` +
                        `奖励：${questResult.quest.reward}`
                    );
                    this.savePlayerData(); // 保存数据
                    return true;
                } else {
                    this.showModal("接受任务失败", questResult.message);
                    return false;
                }

            // 恢复生命值
            case "restoreHp":
                // 检查是否需要付费
                if (actionData.cost && this.player.gold < actionData.cost) {
                    this.showModal("金币不足", `治疗需要${actionData.cost}金币，但你只有${this.player.gold}金币`);
                    return false;
                }

                // 扣除金币
                if (actionData.cost) {
                    this.player.gold -= actionData.cost;
                }

                this.player.restoreHp(actionData.type === "full" ? "full" : actionData.amount);
                this.showModal("生命值恢复",
                    `你恢复了生命值，当前生命值：${this.player.hp}/${this.player.maxHp}`
                );
                this.savePlayerData(); // 保存数据
                return true;

            // 遭遇怪物
            case "encounterMonster":
                // 检查actionData和monster参数是否存在
                if (!actionData || !actionData.monster) {
                    console.error("encounterMonster: actionData或monster参数缺失", actionData);
                    this.showModal("战斗错误", "战斗参数配置错误，无法遭遇怪物！");
                    return false;
                }

                // 检查是否遇到精英怪
                let finalMonsterName = actionData.monster;
                let isElite = false;

                // 如果有精英怪配置，检查是否触发精英怪
                if (actionData.eliteChance && actionData.eliteMonster) {
                    const eliteChance = actionData.eliteChance;
                    if (Math.random() < eliteChance) {
                        finalMonsterName = actionData.eliteMonster;
                        isElite = true;
                    }
                }

                // 从monsters.js中获取怪物数据
                const monsterName = finalMonsterName;

                // 检查怪物数据是否存在
                if (!gameMonsters["艾瑞亚大陆"] || !gameMonsters["艾瑞亚大陆"][monsterName]) {
                    console.error("encounterMonster: 怪物不存在", monsterName, gameMonsters["艾瑞亚大陆"]);
                    this.showModal("怪物不存在", `怪物"${monsterName}"不存在！请检查怪物配置。`);
                    return false;
                }

                const monsterData = gameMonsters["艾瑞亚大陆"][monsterName];

                // 初始化怪物数据
                this.currentMonster = {
                    name: monsterData.name,
                    level: monsterData.level,
                    hp: monsterData.hp,
                    maxHp: monsterData.hp,
                    attack: monsterData.attack,
                    defense: monsterData.defense,
                    exp: monsterData.exp,
                    drop: monsterData.drop,
                    equipmentDrop: monsterData.equipmentDrop,
                    trait: monsterData.trait,
                    area: monsterData.area
                };

                // 显示遭遇信息（如果是精英怪，显示特殊提示）
                if (isElite) {
                    this.showModal("遭遇精英怪",
                        `你遇到了精英${this.currentMonster.name}！\n` +
                        `精英怪物比普通怪物更加强大，但击败后会有更好的奖励！`
                    );
                }

                // 切换到战斗场景
                this.currentScene = "battle";
                this.renderScene();
                return true;

            // 玩家攻击
            case "playerAttack":
                this.audio.playerGongjiSound.play();
                if (!this.currentMonster) return false;

                // 计算伤害（玩家攻击-怪物防御，最低1点）
                const damageToMonster = Math.max(1, this.player.totalAttack - this.currentMonster.defense);
                this.currentMonster.hp -= damageToMonster;

                // 检查怪物是否死亡
                if (this.currentMonster.hp <= 0) {
                    this.handleMonsterDeath();
                    return true;
                }

                // 怪物反击
                const damageToPlayer = this.player.takeDamage(this.currentMonster.attack);
                this.audio.monsterGongjiSound.play();

                // 检查玩家是否死亡
                if (this.player.hp <= 0) {
                    this.handlePlayerDeath();
                    return true;
                }

                // 显示战斗结果
                this.showModal("战斗回合",
                    `你对${this.currentMonster.name}造成了${damageToMonster}点伤害！\n` +
                    `${this.currentMonster.name}对你反击，造成${damageToPlayer}点伤害！\n` +
                    `当前生命值：${this.player.hp}/${this.player.maxHp}`
                );
                this.savePlayerData(); // 保存数据
                return true;

            // 使用道具
            case "useItem":
                if (this.player.inventory.items.length === 0) {
                    this.showModal("无可用道具", "你的背包中没有可使用的道具！");
                    return false;
                }

                // 生成道具选择弹窗
                let itemOptions = this.player.inventory.items.map((item, index) =>
                    `${index + 1}. ${item.name}（${item.count}个）- ${item.effect}`
                ).join("\n");

                const itemIndex = prompt(`请选择要使用的道具（输入编号）：\n${itemOptions}`) - 1;
                if (isNaN(itemIndex) || itemIndex < 0 || itemIndex >= this.player.inventory.items.length) {
                    this.showModal("选择无效", "你选择了无效的道具编号！");
                    return false;
                }

                const useResult = this.player.useItem(itemIndex);
                if (useResult.success) {
                    this.showModal("使用道具",
                        `${useResult.message}！\n` +
                        `当前生命值：${this.player.hp}/${this.player.maxHp}`
                    );
                    this.renderInventory(); // 更新背包显示
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("使用失败", useResult.message);
                }
                return useResult.success;

            // 尝试逃跑
            case "escapeBattle":
                if (!this.currentMonster) return false;
                // 计算逃跑成功率（普通怪物70%，BOSS50%）
                const escapeRate = this.currentMonster.name.includes("BOSS") ? 0.5 : 0.7;
                const isEscapeSuccess = Math.random() < escapeRate;

                if (isEscapeSuccess) {
                    // 逃跑成功

                    // 根据怪物区域动态设置返回场景
                    const areaToSceneMap = {
                        "晨曦村周边沼泽": "swampArea",
                        "森林边缘": "forestEdge",
                        "森林深处": "forestDeep",
                        "南宫村矿洞外": "bichiMineEntrance",
                        "比奇村矿洞": "bichiMineInterior",
                        "比奇村矿洞深处": "bichiMineDeep",
                        "南宫村矿洞深处": "nangongMineDeep",
                        "天津镇周边": "tianjinVillageEntrance"
                    };

                    // 默认返回村庄入口，如果怪物有area属性则使用对应场景
                    this.currentScene = areaToSceneMap[this.currentMonster.area] || "villageEntrance";

                    this.currentMonster = null;

                    this.showModal("逃跑成功", "你成功逃离了战斗！");
                } else {
                    // 逃跑失败，被怪物攻击
                    const damageToPlayer = this.player.takeDamage(this.currentMonster.attack);

                    this.showModal("逃跑失败",
                        `你尝试逃跑失败！\n${this.currentMonster.name}对你发动攻击，造成${damageToPlayer}点伤害！\n` +
                        `当前生命值：${this.player.hp}/${this.player.maxHp}`
                    );
                }
                this.savePlayerData(); // 保存数据
                return true;

            // 购买物品
            case "buyItem":
                const buyResult = this.player.buyItem(actionData);
                if (buyResult.success) {
                    this.showModal("购买成功",
                        `${buyResult.message}，花费了${actionData.price}金币。\n` +
                        `剩余金币：${this.player.gold}`
                    );
                    this.renderInventory(); // 更新背包显示
                    this.savePlayerData(); // 保存数据
                } else {
                    this.showModal("购买失败", buyResult.message);
                }
                return buyResult.success;

            // 获取任务奖励
            case "getQuestReward":
                if (!this.player.currentQuest) {
                    this.showModal("无法领取", "你没有可领取奖励的任务");
                    return false;
                }

                // 发放任务奖励
                this.player.gold += actionData.reward.gold;
                this.player.addExp(actionData.reward.exp);
                this.player.getItem(actionData.reward.item);
                // 标记任务为已完成
                this.player.finishQuest();

                this.showModal("任务奖励",
                    `你获得了任务奖励：\n` +
                    `金币：${actionData.reward.gold}\n` +
                    `经验值：${actionData.reward.exp}\n` +
                    `物品：${actionData.reward.item.name}（${actionData.reward.item.effect}）`
                );
                this.renderInventory(); // 更新背包显示
                this.savePlayerData(); // 保存数据
                return true;


            // 在Game类的executeAction方法中修复checkFrogQuestStatus动作处理
            case "checkFrogQuestStatus":
                if (this.player.currentQuest && this.player.currentQuest.id === "frogKill") {
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 任务已完成，显示奖励选项
                        this.showModal("任务完成",
                            `恭喜你完成了消灭绿皮青蛙的任务！\n` +
                            `任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n\n` +
                            `是否领取奖励？\n` +
                            `- 金币：20\n` +
                            `- 经验值：50\n` +
                            `- 麻布手套（防御+1）`
                        );

                        // 临时保存奖励数据，等待用户确认
                        this.pendingReward = {
                            gold: 20,
                            exp: 50,
                            item: {
                                name: "麻布手套（白色）1111",
                                effect: "防御+1",
                                defense: 1,
                                type: "armor",
                                slot: "hand"
                            }
                        };

                        // 修改弹窗按钮事件，处理奖励领取
                        const originalOnClick = this.elements.modalBtn.onclick;
                        this.elements.modalBtn.onclick = () => {
                            this.elements.modal.classList.add("hidden");
                            this.player.gold += this.pendingReward.gold;
                            this.player.addExp(this.pendingReward.exp);
                            this.player.getItem(this.pendingReward.item);
                            this.player.finishQuest();
                            this.showModal("领取奖励成功",
                                `你获得了：\n` +
                                `金币：${this.pendingReward.gold}\n` +
                                `经验值：${this.pendingReward.exp}\n` +
                                `麻布手套（防御+1）`
                            );
                            this.elements.modalBtn.onclick = originalOnClick;
                            this.renderInventory();
                        };
                    } else {
                        // 任务未完成，显示进度
                        this.showModal("任务进度",
                            `消灭绿皮青蛙任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n` +
                            `继续努力！完成后可以获得金币20、经验值50和麻布手套。`
                        );
                    }
                } else {
                    this.showModal("未接任务", "你还没有接受消灭绿皮青蛙的任务。");
                }
                return true;

            // 检查猎人任务状态（新增）
            case "checkHunterQuestStatus":
                if (this.player.currentQuest && this.player.currentQuest.id === "rabbitInvestigation") {
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        this.showModal("任务完成",
                            `恭喜你完成了森林调查的任务！\n` +
                            `任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n\n` +
                            `是否领取奖励？\n` +
                            `- 金币：30\n` +
                            `- 经验值：80\n` +
                            `- 麻布手套（防御+2）`
                        );

                        // 临时保存奖励数据，等待用户确认
                        this.pendingReward = {
                            questId: "rabbitInvestigation",
                            gold: 30,
                            exp: 80,
                            item: {
                                name: "普通的麻布手套",
                                effect: "防御+2",
                                defense: 2,
                                type: "armor",
                                slot: "bracelet",
                                quality: "普通",
                                level: 1,
                                price: 10
                            }
                        };

                        // 修改弹窗按钮事件，处理奖励领取
                        const originalOnClick = this.elements.modalBtn.onclick;
                        this.elements.modalBtn.onclick = () => {
                            this.elements.modal.classList.add("hidden");
                            this.player.gold += this.pendingReward.gold;
                            this.player.addExp(this.pendingReward.exp);
                            this.player.getItem(this.pendingReward.item);
                            this.player.completeQuest();
                            this.showModal("领取奖励成功",
                                `你获得了：\n` +
                                `金币：${this.pendingReward.gold}\n` +
                                `经验值：${this.pendingReward.exp}\n` +
                                `麻布手套（防御+2）`
                            );
                            this.elements.modalBtn.onclick = originalOnClick;
                            this.renderInventory();
                        };
                    } else {
                        // 任务未完成，显示进度
                        this.showModal("任务进度",
                            `森林调查任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n` +
                            `继续努力！完成后可以获得金币30、经验值80和麻布手套。`
                        );
                    }
                } else {
                    this.showModal("未接任务", "你还没有接受森林调查的任务。");
                }
                return true;


            // 检查森林深处的威胁任务状态（新增）
            case "claimWolfThreatReward":
                if (this.player.currentQuest && this.player.currentQuest.id === "wolfThreat") {
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        this.showModal("任务完成",
                            `恭喜你完成了森林深处的威胁任务！\n` +
                            `任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n\n` +
                            `是否领取奖励？\n` +
                            `- 金币：50\n` +
                            `- 经验值：120\n` +
                            `- 狼皮背心（防御+3）`
                        );

                        // 临时保存奖励数据，等待用户确认
                        this.pendingReward = {
                            questId: "wolfThreat",
                            gold: 50,
                            exp: 120,
                            item: {
                                name: "优秀的狼皮护肩",
                                effect: "防御+3",
                                defense: 3,
                                type: "armor",
                                slot: "body"
                            }
                        };

                        // 修改弹窗按钮事件，处理奖励领取
                        const originalOnClick = this.elements.modalBtn.onclick;
                        this.elements.modalBtn.onclick = () => {
                            this.elements.modal.classList.add("hidden");
                            this.player.gold += this.pendingReward.gold;
                            this.player.addExp(this.pendingReward.exp);
                            this.player.getItem(this.pendingReward.item);
                            this.player.completeQuest();
                            this.showModal("领取奖励成功",
                                `你获得了：\n` +
                                `金币：${this.pendingReward.gold}\n` +
                                `经验值：${this.pendingReward.exp}\n` +
                                `狼皮背心（防御+3）`
                            );
                            this.elements.modalBtn.onclick = originalOnClick;
                            this.renderInventory();
                        };
                    } else {
                        // 任务未完成，显示进度
                        this.showModal("任务进度",
                            `森林深处的威胁任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n` +
                            `继续努力！完成后可以获得金币50、经验值120和狼皮背心。`
                        );
                    }
                } else {
                    this.showModal("未接任务", "你还没有接受森林深处的威胁任务。");
                }
                return true;

            // 通用任务完成检查（新增）
            case "checkQuestStatus":
                if (this.player.currentQuest) {
                    const questInfo = gameQuests.getQuest(this.player.currentQuest.id);
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 根据任务类型显示不同的进度信息
                        let progressText = "";
                        if (this.player.currentQuest.target && this.player.currentQuest.targetCount > 0) {
                            progressText = `任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}`;
                        } else if (this.player.currentQuest.target) {
                            progressText = `任务状态：${this.player.currentQuest.currentCount >= 1 ? "已完成" : "未完成"}`;
                        } else {
                            progressText = `任务状态：${this.player.currentQuest.currentCount >= 1 ? "已完成" : "未完成"}`;
                        }

                        this.showModal("任务完成",
                            `恭喜你完成了${this.player.currentQuest.name}的任务！\n` +
                            `${progressText}\n\n` +
                            `是否领取奖励？\n` +
                            `- 金币：${questInfo.reward.gold}\n` +
                            `- 经验值：${questInfo.reward.exp}\n` +
                            `${questInfo.reward.items ? questInfo.reward.items.map(item => gameItems.getItem(item)?.name).join('、') : ''}`
                        );

                        // 临时保存奖励数据，等待用户确认
                        this.pendingReward = {
                            questId: this.player.currentQuest.id,
                            gold: questInfo.reward.gold,
                            exp: questInfo.reward.exp,
                            items: questInfo.reward.items
                        };

                        // 修改弹窗按钮事件，处理奖励领取
                        const originalOnClick = this.elements.modalBtn.onclick;
                        this.elements.modalBtn.onclick = () => {
                            this.elements.modal.classList.add("hidden");
                            this.player.gold += this.pendingReward.gold;
                            this.player.addExp(this.pendingReward.exp);
                            this.player.completeQuest();
                            this.showModal("领取奖励成功",
                                `你获得了：\n` +
                                `金币：${this.pendingReward.gold}\n` +
                                `经验值：${this.pendingReward.exp}\n` +
                                `${this.pendingReward.items ? this.pendingReward.items.map(item => gameItems.getItem(item)?.name).join(' ') : ''}`
                            );
                            this.elements.modalBtn.onclick = originalOnClick;
                            this.renderInventory();
                        };
                    } else {
                        // 任务未完成，显示进度
                        this.showModal("任务进度",
                            `${this.player.currentQuest.name}任务进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n` +
                            `继续努力！完成后可以获得奖励。`
                        );
                    }
                } else {
                    this.showModal("未接任务", "你当前没有进行中的任务。");
                }
                return true;

            // 领取猎人任务奖励（新增）
            case "claimHunterQuestReward":
                if (this.player.currentQuest && this.player.currentQuest.id === "rabbitInvestigation") {
                    // 检查任务是否完成
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 发放猎人任务奖励
                        this.player.gold += 30;
                        this.player.addExp(80);
                        this.player.getItem({
                            name: "麻布手套（白色）222",
                            effect: "防御+2",
                            defense: 2,
                            type: "armor",
                            slot: "bracelet",
                            quality: "普通",
                            level: 1,
                            price: 10
                        });

                        // 完成任务
                        this.player.finishQuest();

                        this.showModal("领取奖励成功",
                            `你获得了猎人任务的奖励：\n` +
                            `金币：30\n` +
                            `经验值：80\n` +
                            `麻布手套（防御+2）`
                        );
                        this.renderInventory();
                        return true;
                    } else {
                        // 任务未完成，显示进度
                        this.showModal("任务未完成",
                            `森林调查任务尚未完成！\n` +
                            `当前进度：${this.player.currentQuest.currentCount}/${this.player.currentQuest.targetCount}\n` +
                            `请继续消灭${this.player.currentQuest.targetCount - this.player.currentQuest.currentCount}只尖牙野兔。`
                        );
                        return false;
                    }
                } else {
                    this.showModal("无法领取", "你没有可领取的猎人任务奖励。");
                    return false;
                }

            // 检查任务前置条件（新增）
            case "checkQuestPrerequisite":
                const requiredQuest = actionData.requiredQuest;
                if (this.player.completedQuests && this.player.completedQuests.includes(requiredQuest)) {
                    // 前置任务已完成，允许前往
                    this.currentScene = actionData.nextScene || "villageSquare";
                    this.renderScene();
                    return true;
                } else {
                    // 前置任务未完成，显示提示
                    const questInfo = gameQuests.getQuest(requiredQuest);
                    this.showModal("前置任务未完成",
                        `你需要先完成"${questInfo?.name || requiredQuest}"任务才能前往该区域。\n` +
                        `任务描述：${questInfo?.description || "未知任务"}`
                    );
                    return false;
                }

            // 处理前往比奇村任务完成（新增）
            case "completeToBichiVillage":
                if (this.player.currentQuest && this.player.currentQuest.id === "toBichiVillage") {
                    // 更新任务进度
                    this.player.currentQuest.currentCount = 1;

                    // 检查任务是否完成
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 自动完成任务并发放奖励
                        this.player.gold += 100;
                        this.player.addExp(200);
                        this.player.finishQuest();

                        this.showModal("任务完成",
                            `恭喜你完成了"前往比奇村"任务！\n` +
                            `你获得了：\n` +
                            `- 金币：100\n` +
                            `- 经验值：200\n\n` +
                            `欢迎来到比奇村！`
                        );
                        this.renderInventory();
                    }
                }
                return true;

            // 处理前往比奇村任务完成（新增）
            case "completeToBichiVillage":
                if (this.player.currentQuest && this.player.currentQuest.id === "toBichiVillage") {
                    // 更新任务进度
                    this.player.currentQuest.currentCount = 1;

                    // 检查任务是否完成
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 自动完成任务并发放奖励
                        this.player.gold += 100;
                        this.player.addExp(200);
                        this.player.finishQuest();

                        this.showModal("任务完成",
                            `恭喜你完成了"前往比奇村"任务！\n` +
                            `你获得了：\n` +
                            `- 金币：100\n` +
                            `- 经验值：200\n\n` +
                            `欢迎来到比奇村！`
                        );
                        this.renderInventory();
                    }
                }
                return true;

            // 采矿功能（新增）
            case "mineOre":
                // 检查玩家是否有铁矿镐
                const hasPickaxe = this.player.inventory.some(item => item.name === "铁矿镐");
                if (!hasPickaxe) {
                    this.showModal("无法采矿", "你需要铁矿镐才能进行采矿。可以在铁匠铺购买。");
                    return false;
                }

                // 采矿成功概率
                const successRate = 0.7; // 70%成功率
                if (Math.random() < successRate) {
                    // 采矿成功
                    const ironOreCount = Math.floor(Math.random() * 3) + 1; // 1-3个铁矿石
                    this.player.getItem({
                        name: "铁矿石",
                        count: ironOreCount,
                        effect: "锻造材料",
                        type: "material"
                    });

                    this.showModal("采矿成功",
                        `你成功采集到了${ironOreCount}个铁矿石！\n` +
                        `铁矿石可以用于锻造装备或出售。`
                    );
                    this.renderInventory();
                } else {
                    // 采矿失败
                    this.showModal("采矿失败", "这次采矿没有收获，继续努力！");
                }
                return true;

            // 处理前往南宫村任务完成（新增）
            case "completeToNangongVillage":
                if (this.player.currentQuest && this.player.currentQuest.id === "toNangongVillage") {
                    // 更新任务进度
                    this.player.currentQuest.currentCount = 1;

                    // 检查任务是否完成
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 自动完成任务并发放奖励
                        this.player.gold += 300;
                        this.player.addExp(500);
                        this.player.finishQuest();

                        this.showModal("任务完成",
                            `恭喜你完成了"前往南宫村"任务！\n` +
                            `你获得了：\n` +
                            `- 金币：300\n` +
                            `- 经验值：500\n\n` +
                            `欢迎来到南宫村！`
                        );
                        this.renderInventory();
                    }
                }
                return true;

            // 处理前往天津镇任务完成（新增）
            case "completeToTianjinTown":
                if (this.player.currentQuest && this.player.currentQuest.id === "toTianjinTown") {
                    // 更新任务进度
                    this.player.currentQuest.currentCount = 1;

                    // 检查任务是否完成
                    if (this.player.currentQuest.currentCount >= this.player.currentQuest.targetCount) {
                        // 自动完成任务并发放奖励
                        this.player.gold += 500;
                        this.player.addExp(800);
                        this.player.finishQuest();

                        this.showModal("任务完成",
                            `恭喜你完成了"前往天津镇"任务！\n` +
                            `你获得了：\n` +
                            `- 金币：500\n` +
                            `- 经验值：800\n\n` +
                            `欢迎来到天津镇！`
                        );
                        this.renderInventory();
                    }
                }
                return true;

            // 恢复全部状态（精灵泉功能）
            case "restoreFullStatus":
                // 恢复玩家全部状态
                this.player.restoreFullStatus();

                // 显示恢复信息
                const message = actionData.message || "你的状态已经完全恢复了！";
                this.showModal("状态恢复",
                    `${message}\n` +
                    `当前生命值：${this.player.hp}/${this.player.maxHp}\n` +
                    `当前魔法值：${this.player.mp}/${this.player.maxMp}\n` +
                    `当前体力值：${this.player.stamina}/${this.player.maxStamina}`
                );

                // 更新状态面板
                this.updateStatusPanel();
                return true;

            default:
                this.showModal("功能未实现", `该动作（${actionType}）暂未实现！`);
                return false;
        }
    }

    // 处理怪物死亡
    handleMonsterDeath() {
        const monster = this.currentMonster;
        let rewardText = `你击败了${monster.name}（${monster.level}级）！\n获得经验值：${monster.exp}点\n`;

        // 增加经验
        const leveledUp = this.player.addExp(monster.exp);
        if (leveledUp) {
            rewardText += `恭喜！你升级到了${this.player.level}级！\n`;
        }

        // 获得掉落物品
        if (monster.drop) {
            // 修复：使用monster.drop.item而不是monster.drop.name
            // 生成随机数判断是否掉落
            const dropChance = Math.random();
            if (dropChance <= monster.drop.chance) {
                // 掉落成功
                this.player.getItem({
                    name: monster.drop.item,  // 修复这里
                    count: monster.drop.count,
                    effect: "怪物掉落材料",
                    type: "material"
                });
                rewardText += `获得掉落物：${monster.drop.item}（${monster.drop.count}个）\n`;
            }
        }

        // 处理装备掉落（精英怪、BOSS专属）
        if (monster.equipmentDrop) {
            let equipmentDropped = false;
            monster.equipmentDrop.forEach(equipment => {
                const dropChance = Math.random();
                if (dropChance <= equipment.chance) {
                    // 从items.js中获取装备完整信息
                    const itemInfo = gameItems.equipment[equipment.item];
                    if (itemInfo) {
                        this.player.getItem({
                            name: equipment.item,
                            effect: itemInfo.effect,
                            type: itemInfo.type,
                            attack: itemInfo.attack || 0,
                            defense: itemInfo.defense || 0,
                            slot: itemInfo.slot,
                            quality: itemInfo.quality,
                            level: itemInfo.level,
                            price: itemInfo.price
                        });
                        rewardText += `获得装备：${equipment.item}\n`;
                        equipmentDropped = true;
                    }
                }
            });

            if (!equipmentDropped) {
                rewardText += "没有掉落装备\n";
            }
        }

        // 检查任务进度
        const questUpdate = this.player.updateQuestProgress(monster.name);
        if (questUpdate.quest) {
            rewardText += `任务【${questUpdate.quest.name}】进度：${questUpdate.quest.currentCount}/${questUpdate.quest.targetCount}\n`;

            // 检查任务是否完成
            if (questUpdate.completed) {
                rewardText += `任务【${questUpdate.quest.name}】已完成！可以回村领取奖励了！\n`;
            }
        }

        // 重置战斗状态
        this.currentMonster = null;

        // 根据怪物名称返回对应的场景
        let returnScene = "villageSquare"; // 默认返回村庄广场

        // 处理精英怪：去掉"精英"前缀，然后按照普通怪物逻辑处理
        let monsterNameForScene = monster.name;
        if (monsterNameForScene.startsWith("精英")) {
            monsterNameForScene = monsterNameForScene.substring(2); // 去掉"精英"前缀
        }

        // 根据怪物类型确定返回场景
        switch (monster.name) {
            case "绿皮青蛙":
                returnScene = "swampArea";
                break;
            case "尖牙野兔":
                returnScene = "forestEdge";
                break;
            case "森林野狼":
                returnScene = "forestDeep";
                break;
            case "狂暴野猪":
                returnScene = "bichiFarmArea";
                break;
            case "红眼蝙蝠":
                returnScene = "bichiMineEntrance";
                break;
            case "毒刺天牛":
                returnScene = "nangongMineEntrance";
                break;
            case "巨型毒刺天牛":
                returnScene = "nangongMineDeep";
                break;
            case "巨钳蟹":
                returnScene = "tianjinBeach";
                break;
            default:
                returnScene = "villageSquare";
        }

        // 返回战斗前的场景
        this.currentScene = returnScene;

        // 显示奖励弹窗
        this.showModal("战斗胜利", rewardText);
        this.renderInventory(); // 更新背包显示
        this.savePlayerData(); // 保存数据
    }

    // 处理玩家死亡
    handlePlayerDeath() {
        // 重置玩家状态（回到村庄，生命值恢复50%，损失少量金币）
        const goldLost = Math.floor(this.player.gold * 0.1);
        this.player.gold = Math.max(0, this.player.gold - goldLost);
        this.player.hp = Math.floor(this.player.maxHp * 0.5);

        // 保存怪物名称用于显示，然后重置怪物状态
        const monsterName = this.currentMonster?.name || "怪物";
        this.currentMonster = null;
        this.currentScene = "villageSquare";

        this.showModal("战斗失败",
            `你被${monsterName}击败了！\n` +
            `损失金币：${goldLost}（当前剩余：${this.player.gold}）\n` +
            `你在晨曦村复活，生命值恢复至${this.player.hp}/${this.player.maxHp}`
        );
        this.savePlayerData(); // 保存数据
    }

    // 显示弹窗
    showModal(title, desc) {
        this.elements.modalTitle.textContent = title;
        this.elements.modalDesc.textContent = desc;
        this.elements.modal.classList.remove("hidden");
    }

    // 更新状态面板
    updateStatusPanel() {
        this.elements.playerName.textContent = this.player.name;
        this.elements.level.textContent = this.player.level;
        this.elements.hp.textContent = `${this.player.hp}/${this.player.maxHp}`;
        this.elements.gold.textContent = this.player.gold;
        this.elements.attack.textContent = this.player.totalAttack;
        this.elements.defense.textContent = this.player.totalDefense;

        // 计算经验百分比
        const expPercent = Math.min(100, (this.player.exp / this.player.expToNextLevel) * 100);

        // 显示当前经验/升级所需经验
        this.elements.expRatio.textContent = `${this.player.exp}/${this.player.expToNextLevel}`;

        // 可以添加经验条颜色变化效果，比如快升级时变色
        if (expPercent > 80) {
            this.elements.expBarFill?.classList.add("almost-level-up");
        } else {
            this.elements.expBarFill?.classList.remove("almost-level-up");
        }
    }

    // 更新任务面板 - 修复为使用新的任务系统
    // 修复updateQuestPanel方法
    updateQuestPanel() {
        if (this.player.currentQuest) {
            const quest = this.player.currentQuest;
            this.elements.activeQuestName.textContent = `当前任务：${quest.name}`;
            // 修复任务目标显示逻辑
            if (quest.target && quest.targetCount > 0) {
                this.elements.activeQuestTarget.textContent = `消灭${quest.targetCount}只${quest.target}`;
                this.elements.activeQuestProgress.textContent = `${quest.currentCount || 0}/${quest.targetCount}`;
            } else {
                this.elements.activeQuestTarget.textContent = quest.description || "未知目标";
                this.elements.activeQuestProgress.textContent = "进行中";
            }

            // reward:"金币20，经验值50，麻布手套（防御+1）"
            if (quest.reward) {
                this.elements.activeQuestReward.textContent = quest.reward;
            } else {
                this.elements.activeQuestReward.textContent = "未知奖励";
            }
            this.elements.abandonQuestBtn.style.display = "block";
            this.elements.activeQuestPanel.style.display = "block";
        } else {
            this.elements.abandonQuestBtn.style.display = "none";
            this.elements.activeQuestPanel.style.display = "none";
        }
    }

    // 检查任务前置条件
    checkQuestPrerequisite(actionData) {
        const requiredQuest = actionData.requiredQuest;
        if (this.player.completedQuests.includes(requiredQuest)) {
            // 前置任务已完成，允许前往
            this.changeScene(actionData.nextScene || 'villageSquare');
        } else {
            // 前置任务未完成，显示提示
            this.updateStatusPanel();
            this.displayMessage(`你需要先完成"${gameQuests.getQuest(requiredQuest)?.name}"任务才能前往该区域。`);
        }
    }

    // 更新显示消息方法，支持任务链提示
    displayMessage(message, isImportant = false) {
        const messageElement = document.getElementById('gameMessage');
        if (messageElement) {
            messageElement.textContent = message;
            messageElement.className = isImportant ? 'message important' : 'message';

            // 自动滚动到消息区域
            messageElement.scrollIntoView({ behavior: 'smooth' });
        }
    }
}

// 当页面加载完成后启动游戏
window.addEventListener("DOMContentLoaded", () => {
    // 确保DOM完全加载后再初始化游戏
    setTimeout(() => {
        new Game();
    }, 100);
});