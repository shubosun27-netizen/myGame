// 怪物数据定义 - 根据设计文档完善怪物系统
const gameMonsters = {
    // 艾瑞亚大陆怪物（1-10级）
    "艾瑞亚大陆": {
        "绿皮青蛙": {
            name: "绿皮青蛙",
            level: 1,
            hp: 20,
            maxHp: 20,
            attack: 3,
            defense: 0,
            exp: 10,
            gold: 5,
            drop: {
                item: "青蛙腿",
                chance: 0.7,
                count: 1
            },
            trait: "移动速度慢，攻击附带轻微中毒效果",
            area: "沼泽地区"
        },
        "尖牙野兔": {
            name: "尖牙野兔",
            level: 2,
            hp: 25,
            maxHp: 25,
            attack: 4,
            defense: 0,
            exp: 15,
            gold: 8,
            drop: {
                item: "野兔肉",
                chance: 0.8,
                count: 1
            },
            trait: "警惕性高，被攻击后会迅速逃跑",
            area: "森林边缘"
        },
        "森林野狼": {
            name: "森林野狼",
            level: 3,
            hp: 40,
            maxHp: 40,
            attack: 6,
            defense: 1,
            exp: 25,
            gold: 12,
            drop: {
                item: "狼皮",
                chance: 0.6,
                count: 1
            },
            trait: "凶猛，会撕咬攻击",
            area: "森林深处"
        },
        "毒刺天牛": {
            name: "毒刺天牛",
            level: 4,
            hp: 50,
            maxHp: 50,
            attack: 8,
            defense: 3,
            exp: 35,
            gold: 18,
            drop: {
                item: "天牛甲壳",
                chance: 0.5,
                count: 1
            },
            trait: "防御能力较高，会喷射毒液",
            area: "南宫村矿洞外"
        },
        // 南宫村区域怪物
        "巨型毒刺天牛": {
            name: "巨型毒刺天牛",
            level: 9,
            hp: 300,
            attack: 40,
            defense: 25,
            exp: 200,
            drop: ["毒刺剑", "天牛王甲壳", "高级锻造配方"],
            trait: "精英怪物，攻击力强大且有毒刺攻击"
        },

        // 天津镇区域怪物
        "巨钳蟹": {
            name: "巨钳蟹",
            level: 10,
            hp: 400,
            attack: 50,
            defense: 35,
            exp: 300,
            drop: ["蟹钳剑", "蟹壳盾", "航海许可证"],
            trait: "防御力高，钳子攻击威力强大"
        },
        "红眼蝙蝠": {
            name: "红眼蝙蝠",
            level: 5,
            hp: 45,
            maxHp: 45,
            attack: 10,
            defense: 2,
            exp: 40,
            gold: 15,
            drop: {
                item: "蝙蝠翅膀",
                chance: 0.4,
                count: 1
            },
            trait: "在夜间，其攻击力会有所提升",
            area: "废弃矿井"
        },
        "狂暴野猪": {
            name: "狂暴野猪",
            level: 6,
            hp: 70,
            maxHp: 70,
            attack: 12,
            defense: 4,
            exp: 50,
            gold: 22,
            drop: {
                item: "野猪肉",
                chance: 0.7,
                count: 1
            },
            trait: "被攻击后会进入狂暴状态，攻击力增强",
            area: "比奇村农田"
        },
        "荆棘史莱姆": {
            name: "荆棘史莱姆",
            level: 7,
            hp: 60,
            maxHp: 60,
            attack: 9,
            defense: 6,
            exp: 45,
            gold: 20,
            drop: {
                item: "史莱姆凝胶",
                chance: 0.6,
                count: 1
            },
            trait: "对钝器伤害具有免疫能力",
            area: "湿地"
        },
        "亡灵骷髅": {
            name: "亡灵骷髅",
            level: 8,
            hp: 55,
            maxHp: 55,
            attack: 14,
            defense: 2,
            exp: 55,
            gold: 25,
            drop: {
                item: "骷髅骨",
                chance: 0.8,
                count: 1
            },
            trait: "物理防御较低，害怕火焰伤害",
            area: "古代墓地"
        },
        "闪电飞鼠": {
            name: "闪电飞鼠",
            level: 9,
            hp: 40,
            maxHp: 40,
            attack: 16,
            defense: 1,
            exp: 60,
            gold: 28,
            drop: {
                item: "飞鼠尾",
                chance: 0.4,
                count: 1
            },
            trait: "移动速度极快，攻击带有麻痹效果",
            area: "大树顶端"
        }
    },

    // 瓦尔哈拉荒原怪物（11-20级）
    "瓦尔哈拉荒原": {
        "迅捷天马": {
            name: "迅捷天马",
            level: 11,
            hp: 80,
            maxHp: 80,
            attack: 22,
            defense: 5,
            exp: 80,
            gold: 35,
            trait: "会使用冲撞技能，玩家需要预判并躲避",
            area: "草原"
        },
        "风刃狮鹫": {
            name: "风刃狮鹫",
            level: 12,
            hp: 95,
            maxHp: 95,
            attack: 25,
            defense: 6,
            exp: 95,
            gold: 40,
            trait: "属于飞行单位，地面近战职业难以命中",
            area: "悬崖峭壁"
        },
        "暗影豹": {
            name: "暗影豹",
            level: 13,
            hp: 85,
            maxHp: 85,
            attack: 28,
            defense: 4,
            exp: 105,
            gold: 45,
            trait: "在夜晚会进入隐身状态，只受到光明魔法伤害",
            area: "黑森林"
        },
        "熔岩蜥蜴": {
            name: "熔岩蜥蜴",
            level: 14,
            hp: 110,
            maxHp: 110,
            attack: 30,
            defense: 10,
            exp: 120,
            gold: 50,
            trait: "玩家接触到它会受到灼烧伤害",
            area: "火山边缘"
        },
        "冰晶巨人": {
            name: "冰晶巨人",
            level: 15,
            hp: 200,
            maxHp: 200,
            attack: 35,
            defense: 15,
            exp: 250,
            gold: 120,
            trait: "死后会分裂成3只小冰晶怪",
            area: "冰川地带",
            isBoss: true
        }
    },

    // 获取怪物数据的方法
    getMonster: function (monsterName) {
        // 先在艾瑞亚大陆查找
        if (this["艾瑞亚大陆"][monsterName]) {
            return { ...this["艾瑞亚大陆"][monsterName] };
        }
        // 在瓦尔哈拉荒原查找
        if (this["瓦尔哈拉荒原"][monsterName]) {
            return { ...this["瓦尔哈拉荒原"][monsterName] };
        }
        return null;
    },

    // 根据区域获取怪物列表
    getMonstersByArea: function (area) {
        let monsters = [];

        // 查找艾瑞亚大陆的怪物
        Object.values(this["艾瑞亚大陆"]).forEach(monster => {
            if (monster.area === area) {
                monsters.push(monster);
            }
        });

        // 查找瓦尔哈拉荒原的怪物
        Object.values(this["瓦尔哈拉荒原"]).forEach(monster => {
            if (monster.area === area) {
                monsters.push(monster);
            }
        });

        return monsters;
    },

    // 根据等级获取合适的怪物
    getMonstersByLevel: function (level) {
        let monsters = [];
        const continent = level <= 10 ? "艾瑞亚大陆" : "瓦尔哈拉荒原";

        Object.values(this[continent]).forEach(monster => {
            if (Math.abs(monster.level - level) <= 2) {
                monsters.push(monster);
            }
        });

        return monsters;
    }
};

