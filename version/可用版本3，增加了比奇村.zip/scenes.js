// 游戏场景定义
const gameScenes = {
    // 角色创建场景
    characterCreate: {
        title: "欢迎来到艾瑞亚大陆",
        desc: "这片神秘的土地充满了冒险与挑战。在开始你的旅程之前，请为自己取一个名字吧。",
        options: []
    },

    // 苏醒场景
    wakeUp: {
        title: "苏醒",
        desc: "你在一间简陋的小木屋里醒来，阳光透过窗户洒在地板上。一位慈祥的老者坐在你的床边，看到你醒来露出了微笑。",
        options: [
            {
                text: "询问老者这里是哪里",
                nextScene: "elderIntroduction",
                action: null
            },
            {
                text: "检查自己的状况",
                nextScene: "checkStatus",
                action: null
            }
        ]
    },

    // 村长介绍
    elderIntroduction: {
        title: "村长的介绍",
        desc: "老者：“你终于醒了！这里是晨曦村，我是村长。三天前我们发现你晕倒在村外，就把你救回来了。看你的样子，像是一位旅行者？”",
        options: [
            {
                text: "是的，我是一名冒险者",
                nextScene: "villageGuide",
                action: null
            },
            {
                text: "我记不清自己是谁了",
                nextScene: "villageGuide",
                action: null
            }
        ]
    },

    // 检查状态
    checkStatus: {
        title: "检查状态",
        desc: "你感觉身体有些虚弱，但并无大碍。身上穿着简单的粗布衣服，旁边放着一把新手木剑。背包里有两瓶新手药水。",
        options: [
{
                text: "向老者询问情况",
                nextScene: "elderIntroduction",
                action: null
            }
        ]
    },

    // 村庄指引
    villageGuide: {
        title: "村庄指引",
        desc: "村长：“晨曦村是这片地区最安全的地方。村外有一些低级怪物，正好适合你这样的新手历练。对了，最近沼泽里的绿皮青蛙越来越多，已经开始破坏农田了，如果你能帮忙解决这个问题，我会给你奖励。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）"
                }
            },
{
                text: "先了解一下村庄",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 村庄广场
    villageSquare: {
        title: "晨曦村广场",
        desc: "这是晨曦村的中心广场，有几位村民在这里活动。广场周围有几间重要的建筑：村长家、装备商店和村医的小屋。村口有一条路通向外面的世界。",
        options: [
            {
                text: "前往村长家（可接取任务）",
                nextScene: "villageElderHome",
                action: null
            },
            {
                text: "前往猎人小屋（可接取任务）",
                nextScene: "hunterCabin",
                action: null
            },
            {
                text: "前往装备商店（购买装备）",
                nextScene: "villageShop",
                action: null
            },
            {
                text: "去村医的小屋（恢复生命/购买药水）",
                nextScene: "villageClinic",
                action: null
            },
            {
                text: "前往村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },

    // 村长家
    villageElderHome: {
        title: "村长家",
        desc: "村长正在整理一些文件，看到你进来便放下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "villageElderQuest",
                action: null
            },
            {
                text: "询问关于村外世界的信息",
                nextScene: "villageElderWorldInfo",
                action: null
            },
            // 添加检查任务完成状态的选项
            {
                text: "查看任务完成情况",
                nextScene: "villageElderHome",
                action: "checkFrogQuestStatus",
                actionData: {}
            },
            {
                text: "离开村长家",
                nextScene: "villageSquare",
                action: null
            },
        ]
    },

    // 村长任务
    villageElderQuest: {
        title: "村长的任务",
        desc: "村长：“目前最紧急的就是沼泽里的绿皮青蛙问题，它们破坏了我们的农田。如果你能消灭3只绿皮青蛙，我会给你不错的奖励。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）"
                }
            },
            {
                text: "暂时不接受",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 村长介绍世界
    villageElderWorldInfo: {
        title: "村外的世界",
        desc: "村长：“我们晨曦村只是艾瑞亚大陆的一个小村庄。向东是迷雾森林，里面有不少野兔和野狼；向南是沼泽地，那里是绿皮青蛙的栖息地；向西是平原，一直延伸到比奇城。”",
        options: [
            {
                text: "询问关于怪物的信息",
                nextScene: "villageElderMonsterInfo",
                action: null
            },
            {
                text: "感谢村长的介绍",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 村长介绍怪物
    villageElderMonsterInfo: {
        title: "关于怪物",
        desc: "村长：“绿皮青蛙生活在沼泽，攻击力不高但会轻微中毒；尖牙野兔在森林边缘活动，速度较快；森林深处有野狼，比较危险。你现在的实力，建议先从绿皮青蛙或野兔开始历练。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）",
                    rewardData: {
                        gold: 20,
                        exp: 50,
                        item: {
                            name: "麻布手套",
                            effect: "防御+1",
                            defense: 1,
                            type: "armor",
                            slot: "hand"
                        }
                    }
                }
            },
            {
                text: "返回村长家",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 装备商店
    villageShop: {
        title: "装备商店",
        desc: "商店老板：欢迎光临！我这里有一些适合新手的装备，看看有没有需要的？",
        options: [
            {
                text: "购买麻布头盔（15金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "麻布头盔",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "head",
                    price: 15
                }
            },
            {
                text: "购买粗布护肩（15金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "粗布护肩",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "shoulder",
                    price: 15
                }
            },
            {
                text: "购买新手药水（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "新手药水",
                    effect: "恢复20点生命值",
                    type: "potion",
                    price: 10
                }
            },
            {
                text: "离开装备商店",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 村医小屋
    villageClinic: {
        title: "村医的小屋",
        desc: "屋内弥漫着草药的气味，村医正在整理药草。看到你进来，她微笑着打招呼。",
        options: [
            {
                text: "治疗伤势（恢复满生命值，5金币）",
                nextScene: "villageClinic",
                action: "restoreHp",
                actionData: { type: "full", cost: 5 }
            },
            {
                text: "购买新手药水（10金币）",
                nextScene: "villageClinic",
                action: "buyItem",
                actionData: {
                    name: "新手药水",
                    effect: "恢复20点生命值",
                    type: "potion",
                    price: 10
                }
            },
            {
                text: "离开村医的小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 村口
    villageEntrance: {
        title: "晨曦村村口",
        desc: "这里是晨曦村的出口，一条小路通向外面的世界。向东可以看到茂密的森林，向南则是一片沼泽地。",
        options: [
            {
                text: "前往沼泽地（绿皮青蛙）",
                nextScene: "swampArea",
                action: null
            },
            {
                text: "前往森林边缘（尖牙野兔）",
                nextScene: "forestEdge",
                action: null
            },
            {
                text: "前往森林深处（森林野狼）",
                nextScene: "forestDeep",
                action: null
            },
            {
                text: "前往比奇村（需要完成森林深处的威胁任务）",
                nextScene: "bichiVillageSquare",
                action: "checkQuestPrerequisite",
                actionData: { requiredQuest: "wolfThreat" }
            },
            {
                text: "返回村庄",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 沼泽地区
    swampArea: {
        title: "沼泽地区",
        desc: "浑浊的沼泽水泛着绿光，不时有气泡冒出。几只绿色的青蛙在沼泽中跳跃，正是你要找的绿皮青蛙。",
        options: [
            {
                text: "攻击绿皮青蛙",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "绿皮青蛙"
                }
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },

    // 森林边缘
    forestEdge: {
        title: "森林边缘",
        desc: "这里是森林的边缘地带，树木不算茂密，阳光可以照到地面。几只长着尖锐牙齿的野兔正在啃食青草，看到你靠近便警惕地抬起头。",
        options: [
            {
                text: "攻击尖牙野兔",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "尖牙野兔"
                }
            },
            {
                text: "深入森林",
                nextScene: "forestDeep",
                action: null
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },

    // 森林深处
    forestDeep: {
        title: "森林深处",
        desc: "茂密的森林深处，光线变得昏暗。几只野狼在远处徘徊，它们的眼睛在黑暗中闪烁着绿光。",
        options: [
            {
                text: "攻击森林野狼",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "森林野狼"
                }
            },
            {
                text: "返回森林边缘",
                nextScene: "forestEdge",
                action: null
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },
    // 添加森林深处任务完成场景

    forestQuestCompleted: {
        title: "森林调查完成",
        desc: "你已经完成了森林调查任务，可以返回猎人小屋向猎人汤姆报告并领取奖励。",
        options: [
            {
                text: "返回猎人小屋",
                nextScene: "hunterCabin",
                action: null
            },
            {
                text: "继续探索森林",
                nextScene: "forestDeep",
                action: null
            }
        ]
    },

    // 战斗场景
    battle: {
        title: "战斗中",
        desc: "", // 动态生成
        options: [
            { text: "普通攻击", action: "playerAttack" },
            { text: "使用道具", action: "useItem" },
            { text: "尝试逃跑", action: "escapeBattle" }
        ]
    },

    // 任务完成场景
    questCompleted: {
        title: "任务完成",
        desc: "你已经完成了任务目标，可以返回村庄向发布者领取奖励了。",
        options: [
            {
                text: "返回晨曦村",
                nextScene: "villageSquare",
                action: null
            },
            {
                text: "继续在此区域冒险",
                nextScene: (game) => {
                    // 根据完成的任务决定返回哪个场景
                    return game.player.quests.completed.includes("frogKill") ? "swampArea" : "forestEdge";
                },
                action: null
            }
        ]
    },

    // 添加任务状态检查场景
    checkQuestStatus: {
        title: "任务状态",
        desc: "村长正在查看你的任务完成情况...",
        options: [
            {
                text: "查看消灭绿皮青蛙任务进度",
                nextScene: "villageElderHome",
                action: "checkFrogQuestStatus",
                actionData: {}
            },
            {
                text: "返回村长家",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 添加任务完成场景
    questCompleted: {
        title: "任务完成！",
        desc: "恭喜你完成了任务！请回到村长那里领取奖励。",
        options: [
            {
                text: "立即返回村庄",
                nextScene: "villageSquare",
                action: null
            },
            {
                text: "前往村长家领取奖励",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    // 猎人汤姆的小屋（新增场景）
    hunterCabin: {
        title: "猎人小屋",
        desc: "猎人汤姆正在整理他的狩猎工具，看到你进来便停下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "hunterQuest",
                action: null
            },
            {
                text: "查看任务完成情况",
                nextScene: "hunterCabin",
                action: "checkHunterQuestStatus",
                actionData: {}
            },
            {
                text: "询问关于森林深处的信息",
                nextScene: "hunterDeepForestInfo",
                action: null
            },
            {
                text: "报告森林调查结果",
                nextScene: "hunterQuestCompleted",
                action: "claimHunterQuestReward",
                actionData: {}
            },
            {
                text: "报告森林深处的威胁任务结果",
                nextScene: "hunterDeepForestQuestCompleted",
                action: "claimWolfThreatReward",
                actionData: {}
            },
            {
                text: "离开猎人小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 添加森林深处信息场景
    hunterDeepForestInfo: {
        title: "森林深处情报",
        desc: "猎人汤姆：“森林深处有野狼出没，比较危险。如果你已经完成了森林边缘的调查，可以考虑去森林深处看看。不过要小心，那里的野狼比野兔凶猛得多。”",
        options: [
            {
                text: "接受森林深处的任务",
                nextScene: "hunterDeepForestQuest",
                action: null
            },
            {
                text: "返回猎人小屋",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 添加森林深处任务场景
    hunterDeepForestQuest: {
        title: "森林深处的威胁",
        desc: "猎人汤姆：“最近森林深处的野狼活动频繁，我担心它们会威胁到村庄的安全。你能帮我消灭3只森林野狼吗？”",
        options: [
            {
                text: "接受任务“森林深处的威胁”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "wolfThreat",
                    name: "森林深处的威胁",
                    target: "森林野狼",
                    targetCount: 3,
                    reward: "金币50，经验值120，狼皮背心（防御+3）",
                    rewardData: {
                        gold: 50,
                        exp: 120,
                        item: {
                            name: "狼皮背心",
                            effect: "防御+3",
                            defense: 3,
                            type: "armor",
                            slot: "body"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 猎人任务完成场景（新增）
    hunterQuestCompleted: {
        title: "任务完成",
        desc: "猎人汤姆：“感谢你帮忙调查森林的情况！这是给你的奖励。”",
        options: [
            {
                text: "领取奖励",
                nextScene: "hunterCabin",
                action: "claimHunterQuestReward",
                actionData: {}
            },
            {
                text: "询问其他任务",
                nextScene: "hunterQuest",
                action: null
            },
            {
                text: "离开猎人小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 猎人任务场景
    hunterQuest: {
        title: "猎人的请求",
        desc: "猎人汤姆：“森林边缘的野兔最近变得异常凶猛，你能帮我调查一下吗？我需要你消灭5只尖牙野兔。”",
        options: [
            // 修复villageGuide场景中的任务数据

            // 修复hunterQuest场景中的任务数据
            {
                text: "接受任务“森林调查”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "rabbitInvestigation",
                    name: "森林调查",
                    target: "尖牙野兔",
                    targetCount: 5,
                    reward: "金币30，经验值80，皮革护腕（防御+2）",
                    rewardData: {
                        gold: 30,
                        exp: 80,
                        item: {
                            name: "皮革护腕",
                            effect: "防御+2",
                            defense: 2,
                            type: "armor",
                            slot: "bracelet"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 猎人森林信息
    hunterForestInfo: {
        title: "森林情报",
        desc: "猎人汤姆：“迷雾森林分为三个区域：森林边缘主要是野兔，森林深处有野狼出没，最深处据说还有更危险的生物。建议你从森林边缘开始探索。”",
        options: [
            {
                text: "感谢信息",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 比奇村场景（新增）
    bichiVillageSquare: {
        title: "比奇村广场",
        desc: "比晨曦村更大的村庄广场，人来人往十分热闹。这里有村长家、铁匠铺和更大的装备商店。",
        options: [
            {
                text: "前往村长家",
                nextScene: "bichiElderHome",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往铁匠铺",
                nextScene: "blacksmithShop",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往装备商店",
                nextScene: "bichiEquipmentShop",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往村口",
                nextScene: "bichiVillageEntrance",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往南宫村",
                action: "checkQuestPrerequisite",
                requiredQuest: "mineExploration",
                nextScene: "nangongVillageSquare"
            },
            {
                text: "返回晨曦村",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 比奇村长家
    bichiElderHome: {
        title: "比奇村长家",
        desc: "比奇村的村长正在处理村庄事务，看到你进来便热情地打招呼。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "bichiElderQuest",
                action: null
            },
            {
                text: "查看任务完成情况",
                nextScene: "bichiElderHome",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "离开村长家",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 比奇村长任务
    bichiElderQuest: {
        title: "比奇村长的请求",
        desc: "村长：“村外的农田被狂暴野猪破坏，严重影响我们的粮食收成。你能帮忙消灭10只狂暴野猪吗？”",
        options: [
            {
                text: "接受任务“农田守护者”",
                nextScene: "bichiVillageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "farmProtector",
                    name: "农田守护者",
                    target: "狂暴野猪",
                    targetCount: 10,
                    reward: "金币150，经验值300，精铁护肩（防御+3）",
                    rewardData: {
                        gold: 150,
                        exp: 300,
                        item: {
                            name: "精铁护肩",
                            effect: "防御+3",
                            defense: 3,
                            type: "armor",
                            slot: "shoulder"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "bichiElderHome",
                action: null
            }
        ]
    },

    // 铁匠任务
    blacksmithQuest: {
        title: "铁匠的困扰",
        desc: "铁匠鲍勃：“矿井里有红眼蝙蝠骚扰，影响我采集铁矿石。你能帮忙清理5只红眼蝙蝠吗？”",
        options: [
            {
                text: "接受任务“矿洞探险”",
                nextScene: "bichiVillageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "mineExploration",
                    name: "矿洞探险",
                    target: "红眼蝙蝠",
                    targetCount: 5,
                    reward: "金币200，经验值400，精铁剑（攻击+5），铁矿镐",
                    rewardData: {
                        gold: 200,
                        exp: 400,
                        items: ["精铁剑", "铁矿镐"]
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "blacksmithShop",
                action: null
            }
        ]
    },
    // 村长家
    villageElderHome: {
        title: "村长家",
        desc: "村长正在整理一些文件，看到你进来便放下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "villageElderQuest",
                action: null
            },
            {
                text: "询问关于村外世界的信息",
                nextScene: "villageElderWorldInfo",
                action: null
            },
            // 添加前往比奇村任务选项
            {
                text: "询问关于比奇村的情况",
                nextScene: "villageElderBichiInfo",
                action: null
            },
            {
                text: "查看任务完成情况",
                nextScene: "villageElderHome",
                action: "checkFrogQuestStatus",
                actionData: {}
            },
            {
                text: "离开村长家",
                nextScene: "villageSquare",
                action: null
            },
        ]
    },

    // 村长介绍比奇村
    villageElderBichiInfo: {
        title: "关于比奇村",
        desc: "村长：“比奇村是我们这里最大的村庄，位于晨曦村西边。那里有更好的装备商店和铁匠铺，还有更多冒险机会。不过路途遥远，需要穿过危险的平原。”",
        options: [
            {
                text: "接受任务“前往比奇村”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "toBichiVillage",
                    name: "前往比奇村",
                    target: "到达比奇村",
                    targetCount: 0,
                    reward: "金币100，经验值200"
                }
            },
            {
                text: "暂时不去",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    // 比奇村村口
    bichiVillageEntrance: {
        title: "比奇村村口",
        desc: "比奇村的出口，视野开阔，可以看到远处的农田和矿洞。这里通向比奇村外的冒险区域。",
        options: [
            {
                text: "前往农田区域（狂暴野猪）",
                nextScene: "bichiFarmArea",
                action: null
            },
            {
                text: "前往矿洞入口（红眼蝙蝠）",
                nextScene: "bichiMineEntrance",
                action: null
            },
            {
                text: "返回比奇村广场",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 比奇村农田区域
    bichiFarmArea: {
        title: "比奇村农田",
        desc: "广阔的农田区域，庄稼被狂暴野猪破坏得一片狼藉。远处可以看到几只野猪正在破坏庄稼。",
        options: [
            {
                text: "攻击狂暴野猪",
                nextScene: "bichiFarmArea",
                action: "encounterMonster",
                actionData: {
                    monster: "狂暴野猪",
                    area: "比奇村农田"
                }
            },
            {
                text: "查看任务进度",
                nextScene: "bichiFarmArea",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "返回比奇村村口",
                nextScene: "bichiVillageEntrance",
                action: null
            }
        ]
    },

    // 比奇村矿洞入口
    bichiMineEntrance: {
        title: "矿洞入口",
        desc: "一个废弃的矿洞入口，洞口黑漆漆的，隐约能听到里面传来蝙蝠的叫声。",
        options: [
            {
                text: "进入矿洞内部",
                nextScene: "bichiMineInterior",
                action: null
            },
            {
                text: "攻击红眼蝙蝠",
                nextScene: "bichiMineEntrance",
                action: "encounterMonster",
                actionData: {
                    monster: "红眼蝙蝠",
                    area: "矿洞入口"
                }
            },
            {
                text: "查看任务进度",
                nextScene: "bichiMineEntrance",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "返回比奇村村口",
                nextScene: "bichiVillageEntrance",
                action: null
            }
        ]
    },

    // 比奇村矿洞内部
    bichiMineInterior: {
        title: "矿洞内部",
        desc: "矿洞内部阴暗潮湿，墙壁上闪烁着微弱的矿石光芒。红眼蝙蝠在洞顶倒挂着。",
        options: [
            {
                text: "攻击红眼蝙蝠",
                nextScene: "bichiMineInterior",
                action: "encounterMonster",
                actionData: {
                    monster: "红眼蝙蝠",
                    area: "矿洞内部"
                }
            },
            {
                text: "探索矿洞深处",
                nextScene: "bichiMineDeep",
                action: null
            },
            {
                text: "查看任务进度",
                nextScene: "bichiMineInterior",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "返回矿洞入口",
                nextScene: "bichiMineEntrance",
                action: null
            }
        ]
    },

    // 比奇村矿洞深处
    bichiMineDeep: {
        title: "矿洞深处",
        desc: "矿洞的最深处，这里矿石资源更加丰富，但也更加危险。",
        options: [
            {
                text: "攻击红眼蝙蝠",
                nextScene: "bichiMineDeep",
                action: "encounterMonster",
                actionData: {
                    monster: "红眼蝙蝠",
                    area: "矿洞深处"
                }
            },
            {
                text: "采集铁矿石",
                nextScene: "bichiMineDeep",
                action: "mineOre",
                actionData: {}
            },
            {
                text: "查看任务进度",
                nextScene: "bichiMineDeep",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "返回矿洞内部",
                nextScene: "bichiMineInterior",
                action: null
            }
        ]
    },

    // 比奇村装备商店
    bichiEquipmentShop: {
        title: "比奇村装备商店",
        desc: "比晨曦村更大的装备商店，货架上摆满了各种精良的装备。",
        options: [
            {
                text: "购买防具",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    shop: "bichiEquipmentShop",
                    items: [
                        {
                            name: "精铁护肩",
                            price: 120,
                            effect: "防御+3",
                            defense: 3,
                            type: "armor",
                            slot: "shoulder"
                        },
                        {
                            name: "精铁头盔",
                            price: 150,
                            effect: "防御+4",
                            defense: 4,
                            type: "armor",
                            slot: "head"
                        },
                        {
                            name: "精铁胸甲",
                            price: 300,
                            effect: "防御+8",
                            defense: 8,
                            type: "armor",
                            slot: "body"
                        },
                        {
                            name: "抗毒皮甲",
                            price: 250,
                            effect: "防御+6，毒抗+10",
                            defense: 6,
                            type: "armor",
                            slot: "body"
                        }
                    ]
                }
            },
            {
                text: "购买饰品",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    shop: "bichiEquipmentShop",
                    items: [
                        {
                            name: "力量戒指",
                            price: 180,
                            effect: "攻击+5",
                            attack: 5,
                            type: "accessory"
                        },
                        {
                            name: "防御戒指",
                            price: 180,
                            effect: "防御+5",
                            defense: 5,
                            type: "accessory"
                        },
                        {
                            name: "生命项链",
                            price: 220,
                            effect: "生命值+20",
                            hpBonus: 20,
                            type: "accessory"
                        }
                    ]
                }
            },
            {
                text: "查看商品信息",
                nextScene: "bichiEquipmentShop",
                action: "showModal",
                actionData: {
                    title: "装备商店商品信息",
                    content: "防具类：\n- 精铁护肩：防御+3，120金币\n- 精铁头盔：防御+4，150金币\n- 精铁胸甲：防御+8，300金币\n- 抗毒皮甲：防御+6，毒抗+10，250金币\n\n饰品类：\n- 力量戒指：攻击+5，180金币\n- 防御戒指：防御+5，180金币\n- 生命项链：生命值+20，220金币"
                }
            },
            {
                text: "离开装备商店",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 比奇村铁匠铺
    blacksmithShop: {
        title: "铁匠铺",
        desc: "铁匠鲍勃正在打造武器，炉火映红了他的脸庞。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "blacksmithQuest",
                action: null
            },
            {
                text: "购买武器",
                nextScene: "blacksmithShop",
                action: "buyItem",
                actionData: {
                    shop: "blacksmithShop",
                    items: [
                        {
                            name: "精铁剑",
                            price: 200,
                            effect: "攻击+5",
                            attack: 5,
                            type: "weapon"
                        },
                        {
                            name: "铁盾",
                            price: 150,
                            effect: "防御+10",
                            defense: 10,
                            type: "armor",
                            slot: "hand"
                        },
                        {
                            name: "精铁斧",
                            price: 250,
                            effect: "攻击+7",
                            attack: 7,
                            type: "weapon"
                        }
                    ]
                }
            },
            {
                text: "购买工具",
                nextScene: "blacksmithShop",
                action: "buyItem",
                actionData: {
                    shop: "blacksmithShop",
                    items: [
                        {
                            name: "铁矿镐",
                            price: 100,
                            effect: "采矿工具，可采集铁矿石",
                            type: "tool"
                        },
                        {
                            name: "修理工具",
                            price: 50,
                            effect: "修复装备耐久度",
                            type: "tool"
                        },
                        {
                            name: "火把",
                            price: 20,
                            effect: "照亮黑暗区域",
                            type: "tool"
                        }
                    ]
                }
            },
            {
                text: "查看武器信息",
                nextScene: "blacksmithShop",
                action: "showModal",
                actionData: {
                    title: "铁匠铺武器信息",
                    content: "精铁剑：攻击+5，价格200金币\n铁盾：防御+10，价格150金币\n精铁斧：攻击+7，价格250金币"
                }
            },
            {
                text: "离开铁匠铺",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 南宫村广场
    nangongVillageSquare: {
        name: "南宫村广场",
        description: "你来到了南宫村的广场，这里比比奇村更加繁华。广场中央有一座巨大的锻造炉，周围有许多工匠在忙碌。空气中弥漫着金属和煤炭的味道。",
        options: [
            {
                text: "前往锻造大师李的工坊",
                action: "changeScene",
                target: "nangongForge"
            },
            {
                text: "前往南宫村装备店",
                action: "changeScene",
                target: "nangongEquipmentShop"
            },
            {
                text: "前往南宫村矿洞",
                action: "changeScene",
                target: "nangongMineEntrance"
            },
            {
                text: "查看任务进度",
                action: "checkQuestStatus"
            }
        ]
    },

    // 南宫村锻造工坊
    nangongForge: {
        name: "锻造大师李的工坊",
        description: "你进入了锻造大师李的工坊，这里摆满了各种高级锻造工具和半成品武器。李大师正在专注地打造一把宝剑。",
        options: [
            {
                text: "与李大师交谈",
                action: "changeScene",
                target: "nangongMasterQuest"
            },
            {
                text: "学习锻造技术",
                action: "showModal",
                title: "锻造技术",
                content: "李大师可以教你高级锻造技术，需要完成相关任务才能学习。"
            },
            {
                text: "查看高级装备",
                action: "showModal",
                title: "高级装备",
                content: "工坊出售：毒刺剑（攻击+25，带毒效果，价格500金币）、抗毒皮甲（防御+12，毒抗+10，价格400金币）"
            },
            {
                text: "返回南宫村广场",
                action: "changeScene",
                target: "nangongVillageSquare"
            }
        ]
    },

    // 南宫村装备店
    nangongEquipmentShop: {
        name: "南宫村装备商店",
        description: "南宫村的装备商店比比奇村的更加豪华，货架上摆满了各种稀有防具和饰品。",
        options: [
            {
                text: "查看稀有防具",
                action: "showModal",
                title: "稀有防具",
                content: "商店出售：天牛王甲壳（防御+20，价格800金币）、毒抗披风（毒抗+15，价格600金币）"
            },
            {
                text: "查看高级饰品",
                action: "showModal",
                title: "高级饰品",
                content: "商店出售：力量手镯（攻击+8，价格400金币）、防御项链（防御+8，价格400金币）"
            },
            {
                text: "返回南宫村广场",
                action: "changeScene",
                target: "nangongVillageSquare"
            }
        ]
    },

    // 南宫村矿洞入口
    nangongMineEntrance: {
        name: "南宫村矿洞入口",
        description: "你来到了南宫村的矿洞入口，这里比比奇村的矿洞更加深邃。洞口周围散落着一些毒刺天牛的甲壳碎片。",
        options: [
            {
                text: "进入矿洞",
                action: "changeScene",
                target: "nangongMineInterior"
            },
            {
                text: "攻击毒刺天牛",
                action: "encounterMonster",
                monster: "毒刺天牛"
            },
            {
                text: "返回南宫村广场",
                action: "changeScene",
                target: "nangongVillageSquare"
            }
        ]
    },

    // 南宫村矿洞内部
    nangongMineInterior: {
        name: "南宫村矿洞内部",
        description: "矿洞内部比想象中更加深邃，墙壁上闪烁着稀有的矿石光芒。空气中弥漫着淡淡的毒气。",
        options: [
            {
                text: "深入矿洞",
                action: "changeScene",
                target: "nangongMineDeep"
            },
            {
                text: "采集稀有矿石",
                action: "mineOre",
                oreType: "稀有矿石",
                successRate: 50,
                minAmount: 1,
                maxAmount: 2
            },
            {
                text: "返回矿洞入口",
                action: "changeScene",
                target: "nangongMineEntrance"
            }
        ]
    },

    // 南宫村矿洞深处
    nangongMineDeep: {
        name: "南宫村矿洞深处",
        description: "你来到了矿洞的最深处，这里有一只巨大的毒刺天牛在守护着珍贵的矿石。它的体型是普通毒刺天牛的三倍大！",
        options: [
            {
                text: "攻击巨型毒刺天牛",
                action: "encounterMonster",
                monster: "巨型毒刺天牛"
            },
            {
                text: "采集珍贵矿石",
                action: "mineOre",
                oreType: "珍贵矿石",
                successRate: 30,
                minAmount: 1,
                maxAmount: 1
            },
            {
                text: "返回矿洞内部",
                action: "changeScene",
                target: "nangongMineInterior"
            }
        ]
    },

    // 南宫村锻造大师任务
    nangongMasterQuest: {
        name: "锻造大师的任务",
        description: "锻造大师李放下手中的锤子，严肃地看着你：'年轻人，矿洞外的毒刺天牛越来越猖獗，已经影响了我们的矿石采集。你能帮我解决这个问题吗？'",
        options: [
            {
                text: "接受任务：毒刺威胁",
                action: "acceptQuest",
                questId: "poisonThreat"
            },
            {
                text: "询问任务详情",
                action: "showModal",
                title: "毒刺威胁任务",
                content: "需要消灭8只毒刺天牛，完成后可以获得400金币、700经验和抗毒皮甲。"
            },
            {
                text: "返回工坊",
                action: "changeScene",
                target: "nangongForge"
            }
        ]
    },

    // 天津镇港口管理员任务
    tianjinPortMaster: {
        name: "港口管理员的任务",
        description: "港口管理员王指着远处的海滩说：'要前往第二大陆，你需要航海许可证。但许可证被藏在巨钳蟹的巢穴里，那只巨大的螃蟹非常危险。'",
        options: [
            {
                text: "接受任务：航海许可",
                action: "acceptQuest",
                questId: "sailingPermit"
            },
            {
                text: "询问任务详情",
                action: "showModal",
                title: "航海许可任务",
                content: "需要消灭巨钳蟹，完成后可以获得1000金币、2000经验、蟹钳剑和航海许可证。"
            },
            {
                text: "返回港口",
                action: "changeScene",
                target: "tianjinPort"
            }
        ]
    },

    // 天津镇港口
    tianjinPort: {
        name: "天津镇港口",
        description: "你来到了天津镇的港口，这里是通往第二大陆的重要门户。码头上停靠着几艘大船，海风吹拂着你的脸庞。",
        options: [
            {
                text: "与港口管理员王交谈",
                action: "changeScene",
                target: "tianjinPortMaster"
            },
            {
                text: "查看船只",
                action: "showModal",
                title: "港口船只",
                content: "港口停靠着：商船（可前往第二大陆，需要航海许可证）、渔船（可出海捕鱼）"
            },
            {
                text: "前往海滩",
                action: "changeScene",
                target: "tianjinBeach"
            },
            {
                text: "查看任务进度",
                action: "checkQuestStatus"
            }
        ]
    },

    // 天津镇海滩
    tianjinBeach: {
        name: "天津镇海滩",
        description: "你来到了天津镇的海滩，沙滩上散落着贝壳和海草。远处可以看到一只巨大的螃蟹在沙滩上横行。",
        options: [
            {
                text: "攻击巨钳蟹",
                action: "encounterMonster",
                monster: "巨钳蟹"
            },
            {
                text: "采集贝壳",
                action: "showModal",
                title: "贝壳采集",
                content: "海滩上可以采集到各种美丽的贝壳，可以用来制作饰品。"
            },
            {
                text: "返回港口",
                action: "changeScene",
                target: "tianjinPort"
            }
        ]
    }
};