// 物品数据定义 - 根据设计文档完善装备和道具系统
const gameItems = {
    // 艾瑞亚大陆装备（1-10级）
    equipment: {
        // 新手村（1-3级）装备
        "新手木剑": {
            name: "新手木剑",
            effect: "攻击力+3",
            attack: 3,
            type: "weapon",
            slot: "weapon",
            quality: "普通",
            level: 1,
            price: 0
        },
        "麻布头盔": {
            name: "麻布头盔",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "head",
            quality: "普通",
            level: 1,
            price: 15
        },
        "粗布护肩": {
            name: "粗布护肩",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "shoulder",
            quality: "普通",
            level: 1,
            price: 15
        },
        "粗布上衣": {
            name: "粗布上衣",
            effect: "防御+2",
            defense: 2,
            type: "armor",
            slot: "body",
            quality: "普通",
            level: 1,
            price: 20
        },
        "粗布长裤": {
            name: "粗布长裤",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "leg",
            quality: "普通",
            level: 1,
            price: 15
        },
        "麻布鞋": {
            name: "麻布鞋",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "foot",
            quality: "普通",
            level: 1,
            price: 15
        },
        "麻布手套": {
            name: "麻布手套",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "hand",
            quality: "普通",
            level: 1,
            price: 10
        },
        "铜手镯": {
            name: "铜手镯",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "bracelet",
            quality: "普通",
            level: 1,
            price: 12
        },
        "木项链": {
            name: "木项链",
            effect: "攻击+1",
            attack: 1,
            type: "armor",
            slot: "necklace",
            quality: "普通",
            level: 1,
            price: 10
        },

        // 比奇村（4-6级）装备
        "精铁剑": {
            name: "精铁剑",
            effect: "攻击力+8",
            attack: 8,
            type: "weapon",
            slot: "weapon",
            quality: "精良",
            level: 4,
            price: 80
        },
        "精铁头盔": {
            name: "精铁头盔",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "head",
            quality: "精良",
            level: 4,
            price: 60
        },
        "精铁护肩": {
            name: "精铁护肩",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "shoulder",
            quality: "精良",
            level: 4,
            price: 60
        },
        "锁子甲": {
            name: "锁子甲",
            effect: "防御+6",
            defense: 6,
            type: "armor",
            slot: "body",
            quality: "精良",
            level: 4,
            price: 100
        },

        // 南宫村（7-9级）装备
        "毒刺剑": {
            name: "毒刺剑",
            effect: "攻击力+12，毒素伤害+5",
            attack: 12,
            special: "毒素伤害+5",
            type: "weapon",
            slot: "weapon",
            quality: "史诗",
            level: 7,
            price: 200
        },
        "抗毒皮甲": {
            name: "抗毒皮甲",
            effect: "防御+6，抗毒+10%",
            defense: 6,
            special: "抗毒+10%",
            type: "armor",
            slot: "body",
            quality: "精良",
            level: 7,
            price: 150
        },

        // 天津镇（10级）装备
        "蟹钳剑": {
            name: "蟹钳剑",
            effect: "攻击力+15",
            attack: 15,
            type: "weapon",
            slot: "weapon",
            quality: "史诗",
            level: 10,
            price: 300
        }
    },

    // 消耗品道具
    consumables: {
        "新手药水": {
            name: "新手药水",
            effect: "恢复20点生命值",
            type: "potion",
            heal: 20,
            price: 10
        },
        "中级药水": {
            name: "中级药水",
            effect: "恢复50点生命值",
            type: "potion",
            heal: 50,
            price: 25
        },
        "高级药水": {
            name: "高级药水",
            effect: "恢复100点生命值",
            type: "potion",
            heal: 100,
            price: 50
        },
        "解毒剂": {
            name: "解毒剂",
            effect: "解除中毒状态",
            type: "potion",
            special: "解毒",
            price: 30
        }
    },

    // 添加材料物品定义
    materials: {
        "青蛙腿": {
            name: "青蛙腿",
            effect: "绿皮青蛙的腿，可用于烹饪或任务",
            type: "material",
            price: 5
        },
        "野兔肉": {
            name: "野兔肉",
            effect: "尖牙野兔的肉，可用于烹饪或任务",
            type: "material",
            price: 8
        },
        "狼皮": {
            name: "狼皮",
            effect: "森林野狼的皮，可用于制作装备",
            type: "material",
            price: 15
        },
        "蝙蝠翅膀": {
            name: "蝙蝠翅膀",
            effect: "红眼蝙蝠的翅膀，可用于制作药剂",
            type: "material",
            price: 10
        },
        "野猪肉": {
            name: "野猪肉",
            effect: "狂暴野猪的肉，可用于烹饪",
            type: "material",
            price: 12
        },
        "史莱姆凝胶": {
            name: "史莱姆凝胶",
            effect: "荆棘史莱姆的凝胶，可用于制作药剂",
            type: "material",
            price: 8
        },
        "骷髅骨": {
            name: "骷髅骨",
            effect: "亡灵骷髅的骨头，可用于制作装备",
            type: "material",
            price: 15
        },
        "飞鼠尾": {
            name: "飞鼠尾",
            effect: "闪电飞鼠的尾巴，可用于制作饰品",
            type: "material",
            price: 20
        }
    },

    // 统一获取物品的方法
    getItem(itemName) {
        // 优先在装备中查找
        if (this.equipment[itemName]) {
            return this.equipment[itemName];
        }
        // 在消耗品中查找
        if (this.consumables[itemName]) {
            return this.consumables[itemName];
        }
        // 在材料中查找
        if (this.materials[itemName]) {
            return this.materials[itemName];
        }
        return null;
    },

    // 获取商店物品列表
    getShopItems(shopType, playerLevel) {
        let items = [];

        switch (shopType) {
            case "weapon":
                Object.values(this.equipment).forEach(item => {
                    if (item.type === "weapon" && item.level <= playerLevel) {
                        items.push(item);
                    }
                });
                break;
            case "armor":
                Object.values(this.equipment).forEach(item => {
                    if (item.type === "armor" && item.level <= playerLevel) {
                        items.push(item);
                    }
                });
                break;
            case "potion":
                items = Object.values(this.consumables);
                break;
        }

        return items;
    }
};