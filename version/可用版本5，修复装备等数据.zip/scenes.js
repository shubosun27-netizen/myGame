// 游戏场景定义
const gameScenes = {
    // 角色创建场景
    characterCreate: {
        title: "欢迎来到艾瑞亚大陆",
        desc: "这片神秘的土地充满了冒险与挑战。在开始你的旅程之前，请为自己取一个名字吧。",
        options: []
    },

    // 苏醒场景
    wakeUp: {
        title: "苏醒",
        desc: "你在一间简陋的小木屋里醒来，阳光透过窗户洒在地板上。一位慈祥的老者坐在你的床边，看到你醒来露出了微笑。",
        options: [
            {
                text: "询问老者这里是哪里",
                nextScene: "elderIntroduction",
                action: null
            },
            {
                text: "检查自己的状况",
                nextScene: "checkStatus",
                action: null
            }
        ]
    },

    // 村长介绍
    elderIntroduction: {
        title: "村长的介绍",
        desc: "老者：“你终于醒了！这里是晨曦村，我是村长。三天前我们发现你晕倒在村外，就把你救回来了。看你的样子，像是一位旅行者？”",
        options: [
            {
                text: "是的，我是一名冒险者",
                nextScene: "villageGuide",
                action: null
            },
            {
                text: "我记不清自己是谁了",
                nextScene: "villageGuide",
                action: null
            }
        ]
    },

    // 检查状态
    checkStatus: {
        title: "检查状态",
        desc: "你感觉身体有些虚弱，但并无大碍。身上穿着简单的粗布衣服，旁边放着一把新手木剑。背包里有两瓶新手药水。",
        options: [
            {
                text: "向老者询问情况",
                nextScene: "elderIntroduction",
                action: null
            }
        ]
    },

    // 村庄指引
    villageGuide: {
        title: "村庄指引",
        desc: "村长：“晨曦村是这片地区最安全的地方。村外有一些低级怪物，正好适合你这样的新手历练。对了，最近沼泽里的绿皮青蛙越来越多，已经开始破坏农田了，如果你能帮忙解决这个问题，我会给你奖励。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）"
                }
            },
            {
                text: "先了解一下村庄",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 村庄广场
    villageSquare: {
        title: "晨曦村广场",
        desc: "这是晨曦村的中心广场，有几位村民在这里活动。广场周围有几间重要的建筑：村长家、装备商店和村医的小屋。村口有一条路通向外面的世界。",
        options: [
            {
                text: "前往村长家",
                nextScene: "villageElderHome",
                action: null
            },
            {
                text: "前往猎人小屋",
                nextScene: "hunterCabin",
                action: null
            },
            {
                text: "前往装备商店",
                nextScene: "villageShop",
                action: null
            },
            {
                text: "前往村医的小屋",
                nextScene: "villageClinic",
                action: null
            },
            {
                text: "前往村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },

    // 村长家
    villageElderHome: {
        title: "村长家",
        desc: "村长正在整理一些文件，看到你进来便放下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "villageElderQuest",
                action: null
            },
            {
                text: "询问关于村外世界的信息",
                nextScene: "villageElderWorldInfo",
                action: null
            },
            // 添加检查任务完成状态的选项
            {
                text: "查看任务完成情况",
                nextScene: "villageElderHome",
                action: "checkFrogQuestStatus",
                actionData: {}
            },
            {
                text: "离开村长家",
                nextScene: "villageSquare",
                action: null
            },
        ]
    },

    // 村长任务
    villageElderQuest: {
        title: "村长的任务",
        desc: "村长：“目前最紧急的就是沼泽里的绿皮青蛙问题，它们破坏了我们的农田。如果你能消灭3只绿皮青蛙，我会给你不错的奖励。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）"
                }
            },
            {
                text: "暂时不接受",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 村长介绍世界
    villageElderWorldInfo: {
        title: "村外的世界",
        desc: "村长：“我们晨曦村只是艾瑞亚大陆的一个小村庄。向东是迷雾森林，里面有不少野兔和野狼；向南是沼泽地，那里是绿皮青蛙的栖息地；向西是平原，一直延伸到比奇城。”",
        options: [
            {
                text: "询问关于怪物的信息",
                nextScene: "villageElderMonsterInfo",
                action: null
            },
            {
                text: "感谢村长的介绍",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 村长介绍怪物
    villageElderMonsterInfo: {
        title: "关于怪物",
        desc: "村长：“绿皮青蛙生活在沼泽，攻击力不高但会轻微中毒；尖牙野兔在森林边缘活动，速度较快；森林深处有野狼，比较危险。你现在的实力，建议先从绿皮青蛙或野兔开始历练。”",
        options: [
            {
                text: "接受任务“消灭绿皮青蛙”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "frogKill",
                    name: "消灭绿皮青蛙",
                    target: "绿皮青蛙",
                    targetCount: 3,
                    reward: "金币20，经验值50，麻布手套（防御+1）",
                    rewardData: {
                        gold: 20,
                        exp: 50,
                        item: {
                            name: "麻布手套",
                            effect: "防御+1",
                            defense: 1,
                            type: "armor",
                            slot: "hand"
                        }
                    }
                }
            },
            {
                text: "返回村长家",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 新手村装备商店
    villageShop: {
        title: "装备商店",
        desc: "商店老板：欢迎光临！我这里有一些适合新手的装备，看看有没有需要的？",
        options: [
            {
                text: "购买普通的新手木剑（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的新手木剑",
                    effect: "攻击力+3",
                    attack: 3,
                    type: "weapon",
                    slot: "weapon",
                    quality: "普通",
                    level: 1,
                    price: 10
                }
            },
            {
                text: "购买普通的麻布头盔（15金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的麻布头盔",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "head",
                    quality: "普通",
                    level: 1,
                    price: 15
                }
            },
            {
                text: "购买普通的粗布护肩（15金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的粗布护肩",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "shoulder",
                    quality: "普通",
                    level: 1,
                    price: 15
                }
            },
            {
                text: "购买普通的粗布上衣（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的粗布上衣",
                    effect: "防御+2",
                    defense: 2,
                    type: "armor",
                    slot: "body",
                    quality: "普通",
                    level: 1,
                    price: 10
                }
            },
            {
                text: "购买普通的粗布长裤（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的粗布长裤",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "leg",
                    quality: "普通",
                    level: 1,
                    price: 10
                }
            },
            {
                text: "购买普通的麻布鞋（12金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的麻布鞋",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "foot",
                    quality: "普通",
                    level: 1,
                    price: 12
                }
            },
            {
                text: "购买普通的麻布手套（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的麻布手套",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "hand",
                    quality: "普通",
                    level: 1,
                    price: 10
                }
            },
            {
                text: "购买普通的铜手镯（20金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的铜手镯",
                    effect: "防御+1",
                    defense: 1,
                    type: "armor",
                    slot: "bracelet",
                    quality: "普通",
                    level: 1,
                    price: 20
                }
            },
            {
                text: "购买普通的木项链（18金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "普通的木项链",
                    effect: "攻击+1",
                    attack: 1,
                    type: "armor",
                    slot: "necklace",
                    quality: "普通",
                    level: 1,
                    price: 18
                }
            },
            {
                text: "购买新手药水（10金币）",
                nextScene: "villageShop",
                action: "buyItem",
                actionData: {
                    name: "新手药水",
                    effect: "恢复20点生命值",
                    type: "potion",
                    price: 10
                }
            },
            {
                text: "离开装备商店",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 村医小屋
    villageClinic: {
        title: "村医的小屋",
        desc: "屋内弥漫着草药的气味，村医正在整理药草。看到你进来，她微笑着打招呼。",
        options: [
            {
                text: "治疗伤势（恢复满生命值，5金币）",
                nextScene: "villageClinic",
                action: "restoreHp",
                actionData: { type: "full", cost: 5 }
            },
            {
                text: "购买新手药水（10金币）",
                nextScene: "villageClinic",
                action: "buyItem",
                actionData: {
                    name: "新手药水",
                    effect: "恢复20点生命值",
                    type: "potion",
                    price: 10
                }
            },
            {
                text: "离开村医的小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 村口
    villageEntrance: {
        title: "晨曦村村口",
        desc: "这里是晨曦村的出口，一条小路通向外面的世界。向东可以看到茂密的森林，向南则是一片沼泽地。",
        options: [
            {
                text: "前往沼泽地（绿皮青蛙）",
                nextScene: "swampArea",
                action: null
            },
            {
                text: "前往森林边缘（尖牙野兔）",
                nextScene: "forestEdge",
                action: null
            },
            {
                text: "前往森林深处（森林野狼）",
                nextScene: "forestDeep",
                action: null
            },
            {
                text: "前往比奇村",
                nextScene: "bichiVillageSquare",
                action: "checkQuestPrerequisite",
                actionData: { requiredQuest: "wolfThreat" }
            },
            {
                text: "返回村庄",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 沼泽地区
    swampArea: {
        title: "沼泽地区",
        desc: "浑浊的沼泽水泛着绿光，不时有气泡冒出。几只绿色的青蛙在沼泽中跳跃，正是你要找的绿皮青蛙。",
        options: [
            {
                text: "攻击绿皮青蛙",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "绿皮青蛙",
                    eliteChance: 0.2, // 20%概率遇到精英怪
                    eliteMonster: "精英绿皮青蛙"
                }
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },

    // 森林边缘
    forestEdge: {
        title: "森林边缘",
        desc: "这里是森林的边缘地带，树木不算茂密，阳光可以照到地面。几只长着尖锐牙齿的野兔正在啃食青草，看到你靠近便警惕地抬起头。",
        options: [
            {
                text: "攻击尖牙野兔",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "尖牙野兔",
                    eliteChance: 0.25, // 25%概率遇到精英怪（等级2）
                    eliteMonster: "精英尖牙野兔"
                }
            },
            {
                text: "深入森林",
                nextScene: "forestDeep",
                action: null
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },

    // 森林深处
    forestDeep: {
        title: "森林深处",
        desc: "茂密的森林深处，光线变得昏暗。几只野狼在远处徘徊，它们的眼睛在黑暗中闪烁着绿光。",
        options: [
            {
                text: "攻击森林野狼",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "森林野狼",
                    eliteChance: 0.3, // 30%概率遇到精英怪（等级3）
                    eliteMonster: "精英森林野狼"
                }
            },
            {
                text: "寻找精灵泉",
                nextScene: "spiritSpring",
                action: null
            },
            {
                text: "返回森林边缘",
                nextScene: "forestEdge",
                action: null
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },
    // 添加森林深处任务完成场景

    forestQuestCompleted: {
        title: "森林调查完成",
        desc: "你已经完成了森林调查任务，可以返回猎人小屋向猎人汤姆报告并领取奖励。",
        options: [
            {
                text: "返回猎人小屋",
                nextScene: "hunterCabin",
                action: null
            },
            {
                text: "继续探索森林",
                nextScene: "forestDeep",
                action: null
            }
        ]
    },

    // 战斗场景
    battle: {
        title: "战斗中",
        desc: "", // 动态生成
        options: [
            { text: "普通攻击", action: "playerAttack" },
            { text: "使用道具", action: "useItem" },
            { text: "尝试逃跑", action: "escapeBattle" }
        ]
    },

    // 任务完成场景
    questCompleted: {
        title: "任务完成",
        desc: "你已经完成了任务目标，可以返回村庄向发布者领取奖励了。",
        options: [
            {
                text: "返回晨曦村",
                nextScene: "villageSquare",
                action: null
            },
            {
                text: "继续在此区域冒险",
                nextScene: (game) => {
                    // 根据完成的任务决定返回哪个场景
                    return game.player.quests.completed.includes("frogKill") ? "swampArea" : "forestEdge";
                },
                action: null
            }
        ]
    },

    // 添加任务状态检查场景
    checkQuestStatus: {
        title: "任务状态",
        desc: "村长正在查看你的任务完成情况...",
        options: [
            {
                text: "查看消灭绿皮青蛙任务进度",
                nextScene: "villageElderHome",
                action: "checkFrogQuestStatus",
                actionData: {}
            },
            {
                text: "返回村长家",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },

    // 添加任务完成场景
    questCompleted: {
        title: "任务完成！",
        desc: "恭喜你完成了任务！请回到村长那里领取奖励。",
        options: [
            {
                text: "立即返回村庄",
                nextScene: "villageSquare",
                action: null
            },
            {
                text: "前往村长家领取奖励",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    // 猎人汤姆的小屋（新增场景）
    hunterCabin: {
        title: "猎人小屋",
        desc: "猎人汤姆正在整理他的狩猎工具，看到你进来便停下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "hunterQuest",
                action: null
            },
            {
                text: "询问关于森林深处的信息",
                nextScene: "hunterDeepForestInfo",
                action: null
            },
            {
                text: "报告森林调查结果",
                nextScene: "hunterQuestCompleted",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "报告森林深处的威胁任务结果",
                nextScene: "hunterDeepForestQuestCompleted",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "离开猎人小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 添加森林深处信息场景
    hunterDeepForestInfo: {
        title: "森林深处情报",
        desc: "猎人汤姆：“森林深处有野狼出没，比较危险。如果你已经完成了森林边缘的调查，可以考虑去森林深处看看。不过要小心，那里的野狼比野兔凶猛得多。”",
        options: [
            {
                text: "接受森林深处的任务",
                nextScene: "hunterDeepForestQuest",
                action: null
            },
            {
                text: "返回猎人小屋",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 添加森林深处任务场景
    hunterDeepForestQuest: {
        title: "森林深处的威胁",
        desc: "猎人汤姆：“最近森林深处的野狼活动频繁，我担心它们会威胁到村庄的安全。你能帮我消灭3只森林野狼吗？”",
        options: [
            {
                text: "接受任务“森林深处的威胁”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "wolfThreat",
                    name: "森林深处的威胁",
                    target: "森林野狼",
                    targetCount: 3,
                    reward: "金币50，经验值120，狼皮背心（防御+3）",
                    rewardData: {
                        gold: 50,
                        exp: 120,
                        item: {
                            name: "狼皮背心",
                            effect: "防御+3",
                            defense: 3,
                            type: "armor",
                            slot: "body"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 猎人任务完成场景（新增）
    hunterQuestCompleted: {
        title: "任务完成",
        desc: "猎人汤姆：“感谢你帮忙调查森林的情况！这是给你的奖励。”",
        options: [
            {
                text: "领取奖励",
                nextScene: "hunterCabin",
                action: "claimHunterQuestReward",
                actionData: {}
            },
            {
                text: "询问其他任务",
                nextScene: "hunterQuest",
                action: null
            },
            {
                text: "离开猎人小屋",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 猎人任务场景
    hunterQuest: {
        title: "猎人的请求",
        desc: "猎人汤姆：“森林边缘的野兔最近变得异常凶猛，你能帮我调查一下吗？我需要你消灭5只尖牙野兔。”",
        options: [
            // 修复villageGuide场景中的任务数据

            // 修复hunterQuest场景中的任务数据
            {
                text: "接受任务“森林调查”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "rabbitInvestigation",
                    name: "森林调查",
                    target: "尖牙野兔",
                    targetCount: 5,
                    reward: "金币30，经验值80，皮革护腕（防御+2）",
                    rewardData: {
                        gold: 30,
                        exp: 80,
                        item: {
                            name: "皮革护腕",
                            effect: "防御+2",
                            defense: 2,
                            type: "armor",
                            slot: "bracelet"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 猎人森林信息
    hunterForestInfo: {
        title: "森林情报",
        desc: "猎人汤姆：“迷雾森林分为三个区域：森林边缘主要是野兔，森林深处有野狼出没，最深处据说还有更危险的生物。建议你从森林边缘开始探索。”",
        options: [
            {
                text: "感谢信息",
                nextScene: "hunterCabin",
                action: null
            }
        ]
    },

    // 比奇村场景（新增）
    bichiVillageSquare: {
        title: "比奇村广场",
        desc: "比晨曦村更大的村庄广场，人来人往十分热闹。这里有村长家、铁匠铺和更大的装备商店。",
        options: [
            {
                text: "前往村长家",
                nextScene: "bichiElderHome",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往铁匠铺",
                nextScene: "blacksmithShop",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往装备商店",
                nextScene: "bichiEquipmentShop",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往村口",
                nextScene: "bichiVillageEntrance",
                action: "completeToBichiVillage",
                actionData: {}
            },
            {
                text: "前往南宫村",
                nextScene: "nangongVillageSquare",
                action: "checkQuestPrerequisite",
                actionData: { requiredQuest: "mineExploration" }
            },
            {
                text: "返回晨曦村",
                nextScene: "villageSquare",
                action: null
            }
        ]
    },

    // 比奇村长家
    bichiElderHome: {
        title: "比奇村长家",
        desc: "比奇村的村长正在处理村庄事务，看到你进来便热情地打招呼。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "bichiElderQuest",
                action: null
            },
            {
                text: "询问关于南宫村的情况",
                nextScene: "bichiElderNangongInfo",
                action: null
            },
            {
                text: "查看任务完成情况",
                nextScene: "bichiElderHome",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "离开村长家",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 村长介绍南宫村
    bichiElderNangongInfo: {
        title: "关于南宫村",
        desc: "村长：“南宫村是我们这里最繁华的村庄，位于比奇村东边。那里有锻造大师李的工坊和高级装备商店，还有丰富的矿藏。不过路途遥远，需要穿过危险的矿洞区域。”",
        options: [
            {
                text: "接受任务“前往南宫村”",
                nextScene: "bichiVillageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "toNangongVillage",
                    name: "前往南宫村",
                    target: "到达南宫村",
                    targetCount: 0,
                    reward: "金币300，经验值500"
                }
            },
            {
                text: "暂时不去",
                nextScene: "bichiElderHome",
                action: null
            }
        ]
    },

    // 比奇村长任务
    bichiElderQuest: {
        title: "比奇村长的请求",
        desc: "村长：“村外的农田被狂暴野猪破坏，严重影响我们的粮食收成。你能帮忙消灭10只狂暴野猪吗？”",
        options: [
            {
                text: "接受任务“农田守护者”",
                nextScene: "bichiVillageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "farmProtector",
                    name: "农田守护者",
                    target: "狂暴野猪",
                    targetCount: 10,
                    reward: "金币150，经验值300，精铁护肩（防御+3）",
                    rewardData: {
                        gold: 150,
                        exp: 300,
                        item: {
                            name: "精铁护肩",
                            effect: "防御+3",
                            defense: 3,
                            type: "armor",
                            slot: "shoulder"
                        }
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "bichiElderHome",
                action: null
            }
        ]
    },

// 铁匠任务
    blacksmithQuest: {
        title: "铁匠的困扰",
        desc: "铁匠鲍勃：“矿井里有红眼蝙蝠骚扰，影响我采集铁矿石。你能帮忙清理5只红眼蝙蝠吗？”",
        options: [
            {
                text: "接受任务“矿洞探险”",
                nextScene: "bichiVillageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "mineExploration",
                    name: "矿洞探险",
                    target: "红眼蝙蝠",
                    targetCount: 5,
                    reward: "金币200，经验值400，精铁剑（攻击+5），铁矿镐",
                    rewardData: {
                        gold: 200,
                        exp: 400,
                        items: ["精铁剑", "铁矿镐"]
                    }
                }
            },
            {
                text: "暂时不接受",
                nextScene: "blacksmithShop",
                action: null
            }
        ]
    },
    // 村长家
    villageElderHome: {
        title: "村长家",
        desc: "村长正在整理一些文件，看到你进来便放下了手中的工作。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "villageElderQuest",
                action: null
            },
            {
                text: "询问关于村外世界的信息",
                nextScene: "villageElderWorldInfo",
                action: null
            },
            // 添加前往比奇村任务选项
            {
                text: "询问关于比奇村的情况",
                nextScene: "villageElderBichiInfo",
                action: null
            },
            {
                text: "查看任务完成情况",
                nextScene: "villageElderHome",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "离开村长家",
                nextScene: "villageSquare",
                action: null
            },
        ]
    },

    // 村长介绍比奇村
    villageElderBichiInfo: {
        title: "关于比奇村",
        desc: "村长：“比奇村是我们这里最大的村庄，位于晨曦村西边。那里有更好的装备商店和铁匠铺，还有更多冒险机会。不过路途遥远，需要穿过危险的平原。”",
        options: [
            {
                text: "接受任务“前往比奇村”",
                nextScene: "villageSquare",
                action: "acceptQuest",
                actionData: {
                    id: "toBichiVillage",
                    name: "前往比奇村",
                    target: "到达比奇村",
                    targetCount: 0,
                    reward: "金币100，经验值200"
                }
            },
            {
                text: "暂时不去",
                nextScene: "villageElderHome",
                action: null
            }
        ]
    },
    // 比奇村村口
    bichiVillageEntrance: {
        title: "比奇村村口",
        desc: "比奇村的出口，视野开阔，可以看到远处的农田和矿洞。这里通向比奇村外的冒险区域。",
        options: [
            {
                text: "前往农田区域（狂暴野猪）",
                nextScene: "bichiFarmArea",
                action: null
            },
            {
                text: "前往矿洞入口（红眼蝙蝠）",
                nextScene: "bichiMineEntrance",
                action: null
            },
            {
                text: "返回比奇村广场",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 比奇村农田区域
    bichiFarmArea: {
        title: "比奇村农田",
        desc: "广阔的农田区域，庄稼被狂暴野猪破坏得一片狼藉。远处可以看到几只野猪正在破坏庄稼。",
        options: [
            {
                text: "攻击狂暴野猪",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "狂暴野猪",
                    eliteChance: 0.35, // 35%概率遇到精英怪（等级6）
                    eliteMonster: "精英狂暴野猪",
                    area: "比奇村农田"
                }
            },
            {
                text: "返回比奇村村口",
                nextScene: "bichiVillageEntrance",
                action: null
            }
        ]
    },

    // 比奇村矿洞入口
    bichiMineEntrance: {
        title: "矿洞入口",
        desc: "一个废弃的矿洞入口，洞口黑漆漆的，隐约能听到里面传来蝙蝠的叫声。",
        options: [
            {
                text: "进入矿洞内部",
                nextScene: "bichiMineInterior",
                action: null
            },
            {
                text: "攻击红眼蝙蝠",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "红眼蝙蝠",
                    eliteChance: 0.32, // 32%概率遇到精英怪（等级5）
                    eliteMonster: "精英红眼蝙蝠",
                    area: "矿洞入口"
                }
            },
            {
                text: "返回比奇村村口",
                nextScene: "bichiVillageEntrance",
                action: null
            }
        ]
    },

    // 比奇村矿洞内部
    bichiMineInterior: {
        title: "矿洞内部",
        desc: "矿洞内部阴暗潮湿，墙壁上闪烁着微弱的矿石光芒。红眼蝙蝠在洞顶倒挂着。",
        options: [
            {
                text: "攻击红眼蝙蝠",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "红眼蝙蝠",
                    eliteChance: 0.32, // 32%概率遇到精英怪（等级5）
                    eliteMonster: "精英红眼蝙蝠",
                    area: "矿洞内部"
                }
            },
            {
                text: "探索矿洞深处",
                nextScene: "bichiMineDeep",
                action: null
            },
            {
                text: "返回矿洞入口",
                nextScene: "bichiMineEntrance",
                action: null
            }
        ]
    },

    // 比奇村矿洞深处
    bichiMineDeep: {
        title: "矿洞深处",
        desc: "矿洞的最深处，这里矿石资源更加丰富，但也更加危险。",
        options: [
            {
                text: "攻击红眼蝙蝠",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "红眼蝙蝠",
                    eliteChance: 0.32, // 32%概率遇到精英怪（等级5）
                    eliteMonster: "精英红眼蝙蝠",
                    area: "矿洞深处"
                }
            },
            {
                text: "采集铁矿石",
                nextScene: "bichiMineDeep",
                action: "mineOre",
                actionData: {}
            },
            {
                text: "返回矿洞内部",
                nextScene: "bichiMineInterior",
                action: null
            }
        ]
    },

    // 比奇村装备商店
    bichiEquipmentShop: {
        title: "比奇村装备店",
        desc: "装备店老板：欢迎来到比奇村！我这里有一些中级装备，比晨曦村的要好一些。",
        options: [
            {
                text: "购买青铜剑（80金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的青铜剑",
                    effect: "攻击力+6",
                    attack: 6,
                    type: "weapon",
                    slot: "weapon",
                    quality: "优秀",
                    level: 4,
                    price: 80
                }
            },
            {
                text: "购买青铜头盔（70金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的青铜头盔",
                    effect: "防御+3",
                    defense: 3,
                    type: "armor",
                    slot: "head",
                    quality: "优秀",
                    level: 4,
                    price: 70
                }
            },
            {
                text: "购买野猪皮护肩（90金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的野猪皮护肩",
                    effect: "防御+3",
                    defense: 3,
                    type: "armor",
                    slot: "shoulder",
                    quality: "优秀",
                    level: 5,
                    price: 90
                }
            },
            {
                text: "购买野猪皮甲（100金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的野猪皮甲",
                    effect: "防御+4",
                    defense: 4,
                    type: "armor",
                    slot: "body",
                    quality: "优秀",
                    level: 5,
                    price: 100
                }
            },
            {
                text: "购买青铜护腿（65金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的青铜护腿",
                    effect: "防御+3",
                    defense: 3,
                    type: "armor",
                    slot: "leg",
                    quality: "优秀",
                    level: 4,
                    price: 65
                }
            },
            {
                text: "购买野猪皮靴（85金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的野猪皮靴",
                    effect: "防御+3",
                    defense: 3,
                    type: "armor",
                    slot: "foot",
                    quality: "优秀",
                    level: 5,
                    price: 85
                }
            },
            {
                text: "购买铜护腕（55金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的铜护腕",
                    effect: "防御+2",
                    defense: 2,
                    type: "armor",
                    slot: "bracelet",
                    quality: "优秀",
                    level: 4,
                    price: 55
                }
            },
            {
                text: "购买蝙蝠牙项链（75金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "优秀的蝙蝠牙项链",
                    effect: "攻击+2",
                    attack: 2,
                    type: "armor",
                    slot: "necklace",
                    quality: "优秀",
                    level: 5,
                    price: 75
                }
            },
            {
                text: "购买中级药水（25金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "中级药水",
                    effect: "恢复50点生命值",
                    type: "potion",
                    heal: 50,
                    price: 25
                }
            },
            {
                text: "购买铁矿镐（100金币）",
                nextScene: "bichiEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "铁矿镐",
                    effect: "采矿工具，可采集铁矿石",
                    type: "tool",
                    price: 100
                }
            },
            {
                text: "离开装备商店",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 比奇村铁匠铺
    blacksmithShop: {
        title: "铁匠铺",
        desc: "铁匠鲍勃正在打造武器，炉火映红了他的脸庞。",
        options: [
            {
                text: "询问是否有任务可以做",
                nextScene: "blacksmithQuest",
                action: null
            },
            {
                text: "查看任务完成情况",
                nextScene: "blacksmithShop",
                action: "checkQuestStatus",
                actionData: {}
            },
            {
                text: "离开铁匠铺",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 南宫村广场
    nangongVillageSquare: {
        title: "南宫村广场",
        desc: "你来到了南宫村的广场，这里比比奇村更加繁华。广场中央有一座巨大的锻造炉，周围有许多工匠在忙碌。空气中弥漫着金属和煤炭的味道。",
        options: [
            {
                text: "前往锻造大师李的工坊",
                nextScene: "nangongForge",
                action: "completeToNangongVillage",
                actionData: {}
            },
            {
                text: "前往南宫村装备店",
                nextScene: "nangongEquipmentShop",
                action: "completeToNangongVillage",
                actionData: {}
            },
            {
                text: "前往南宫村矿洞",
                nextScene: "nangongMineEntrance",
                action: "completeToNangongVillage",
                actionData: {}
            },
            {
                text: "返回比奇村",
                nextScene: "bichiVillageSquare",
                action: null
            }
        ]
    },

    // 南宫村锻造工坊
    nangongForge: {
        title: "锻造大师李的工坊",
        desc: "你进入了锻造大师李的工坊，这里摆满了各种高级锻造工具和半成品武器。李大师正在专注地打造一把宝剑。",
        options: [
            {
                text: "与李大师交谈",
                nextScene: "nangongMasterQuest",
                action: null
            },
            {
                text: "学习锻造技术",
                nextScene: "nangongForge",
                action: "showModal",
                actionData: {
                    title: "锻造技术",
                    content: "李大师可以教你高级锻造技术，需要完成相关任务才能学习。"
                }
            },
            {
                text: "返回南宫村广场",
                nextScene: "nangongVillageSquare",
action: null
            }
        ]
    },

    // 南宫村装备店
    nangongEquipmentShop: {
        title: "南宫村装备商店",
        desc: "南宫村的装备商店比比奇村的更加豪华，货架上摆满了各种稀有防具和饰品。",
        options: [
            {
                text: "购买天牛王甲壳（800金币）",
                nextScene: "nangongEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "天牛王甲壳",
                    effect: "防御+20",
                    defense: 20,
                    type: "armor",
                    slot: "body",
                    price: 800
                }
            },
            {
                text: "购买毒抗披风（600金币）",
                nextScene: "nangongEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "毒抗披风",
                    effect: "毒抗+15",
                    type: "armor",
                    slot: "cloak",
                    price: 600
                }
            },
            {
                text: "购买力量手镯（400金币）",
                nextScene: "nangongEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "力量手镯",
                    effect: "攻击+8",
                    attack: 8,
                    type: "armor",
                    slot: "wrist",
                    price: 400
                }
            },
            {
                text: "购买防御项链（400金币）",
                nextScene: "nangongEquipmentShop",
                action: "buyItem",
                actionData: {
                    name: "防御项链",
                    effect: "防御+8",
                    defense: 8,
                    type: "armor",
                    slot: "neck",
                    price: 400
                }
            },
            {
                text: "返回南宫村广场",
                nextScene: "nangongVillageSquare",
                action: null
            }
        ]
    },

    // 南宫村矿洞入口
    nangongMineEntrance: {
        title: "南宫村矿洞入口",
        desc: "你来到了南宫村的矿洞入口，这里比比奇村的矿洞更加深邃。洞口周围散落着一些毒刺天牛的甲壳碎片。",
        options: [
            {
                text: "进入矿洞",
                nextScene: "nangongMineInterior",
                action: null
            },
            {
                text: "攻击毒刺天牛",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "毒刺天牛",
                    eliteChance: 0.28, // 28%概率遇到精英怪（等级4）
                    eliteMonster: "精英毒刺天牛",
                    area: "南宫村矿洞入口"
                }
            },
            {
                text: "返回南宫村广场",
                nextScene: "nangongVillageSquare",
                action: null
            }
        ]
    },

    // 南宫村矿洞内部
    nangongMineInterior: {
        title: "南宫村矿洞内部",
        desc: "矿洞内部比想象中更加深邃，墙壁上闪烁着稀有的矿石光芒。空气中弥漫着淡淡的毒气。",
        options: [
            {
                text: "深入矿洞",
                nextScene: "nangongMineDeep",
                action: null
            },
            {
                text: "采集稀有矿石",
                nextScene: "nangongMineInterior",
                action: "mineOre",
                actionData: {
                    oreType: "稀有矿石",
                    successRate: 50,
                    minAmount: 1,
                    maxAmount: 2
                }
            },
            {
                text: "返回矿洞入口",
                nextScene: "nangongMineEntrance",
                action: null
            }
        ]
    },

    // 南宫村矿洞深处
    nangongMineDeep: {
        title: "南宫村矿洞深处",
        desc: "你来到了矿洞的最深处，这里有一只巨大的毒刺天牛在守护着珍贵的矿石。它的体型是普通毒刺天牛的三倍大！",
        options: [
            {
                text: "攻击巨型毒刺天牛",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "巨型毒刺天牛",
                    area: "南宫村矿洞深处"
                }
            },
            {
                text: "采集珍贵矿石",
                nextScene: "nangongMineDeep",
                action: "mineOre",
                actionData: {
                    oreType: "珍贵矿石",
                    successRate: 30,
                    minAmount: 1,
                    maxAmount: 1
                }
            },
            {
                text: "返回矿洞内部",
                nextScene: "nangongMineInterior",
                action: null
            }
        ]
    },

    // 南宫村锻造大师任务
    nangongMasterQuest: {
        title: "锻造大师的任务",
        desc: "锻造大师李放下手中的锤子，严肃地看着你：'年轻人，矿洞外的毒刺天牛越来越猖獗，已经影响了我们的矿石采集。你能帮我解决这个问题吗？'",
        options: [
            {
                text: "接受任务：毒刺威胁",
                nextScene: "nangongMasterQuest",
                action: "acceptQuest",
                actionData: {
                    id: "poisonThreat",
                    name: "毒刺威胁",
                    target: "消灭毒刺天牛",
                    targetCount: 8,
                    reward: "金币400，经验700，抗毒皮甲"
                }
            },
            {
                text: "询问任务详情",
                nextScene: "nangongMasterQuest",
                action: "showModal",
                actionData: {
                    title: "毒刺威胁任务",
                    content: "需要消灭8只毒刺天牛，完成后可以获得400金币、700经验和抗毒皮甲。"
                }
            },
            {
                text: "返回工坊",
                nextScene: "nangongForge",
                action: null
            }
        ]
    },

    // 天津镇港口管理员任务
    tianjinPortMaster: {
        name: "港口管理员的任务",
        desc: "港口管理员王指着远处的海滩说：'要前往第二大陆，你需要航海许可证。但许可证被藏在巨钳蟹的巢穴里，那只巨大的螃蟹非常危险。'",
        options: [
            {
                text: "接受任务：航海许可",
                action: "acceptQuest",
                questId: "sailingPermit"
            },
            {
                text: "询问任务详情",
                action: "showModal",
                title: "航海许可任务",
                content: "需要消灭巨钳蟹，完成后可以获得1000金币、2000经验、蟹钳剑和航海许可证。"
            },
            {
                text: "返回港口",
                action: "changeScene",
                target: "tianjinPort"
            }
        ]
    },

    // 天津镇港口
    tianjinPort: {
        name: "天津镇港口",
        desc: "你来到了天津镇的港口，这里是通往第二大陆的重要门户。码头上停靠着几艘大船，海风吹拂着你的脸庞。",
        options: [
            {
                text: "与港口管理员王交谈",
                nextScene: "tianjinPortMaster",
                action: null
            },
            {
                text: "查看船只",
                nextScene: "tianjinPort",
                action: "showModal",
                actionData: {
                    title: "港口船只",
                    content: "港口停靠着：商船（可前往第二大陆，需要航海许可证）、渔船（可出海捕鱼）"
                }
            },
            {
                text: "前往海滩",
                nextScene: "tianjinBeach",
                action: null
            }
        ]
    },

    // 天津镇海滩
    tianjinBeach: {
        name: "天津镇海滩",
        desc: "你来到了天津镇的海滩，沙滩上散落着贝壳和海草。远处可以看到一只巨大的螃蟹在沙滩上横行。",
        options: [
            {
                text: "攻击巨钳蟹",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "巨钳蟹"
                }
            },
            {
                text: "采集贝壳",
                nextScene: "tianjinBeach",
                action: "collectItem",
                actionData: {
                    itemType: "贝壳",
                    successRate: 70,
                    minAmount: 1,
                    maxAmount: 3
                }
            },
            {
                text: "前往湿地地区",
                nextScene: "wetlandArea",
                action: null
            },
            {
                text: "返回港口",
                nextScene: "tianjinPort",
                action: null
            }
        ]
    },

    // 湿地地区（7级怪物：荆棘史莱姆）
    wetlandArea: {
        title: "湿地地区",
        desc: "泥泞的湿地中生长着各种奇特的植物，空气中弥漫着潮湿的气息。几只半透明的荆棘史莱姆在泥潭中缓缓蠕动，它们对钝器伤害免疫，需要小心应对。",
        options: [
            {
                text: "攻击荆棘史莱姆",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "荆棘史莱姆",
                    eliteChance: 0.35, // 35%概率遇到精英怪（等级7）
                    eliteMonster: "精英荆棘史莱姆",
                    area: "湿地地区"
                }
            },
            {
                text: "采集湿地草药",
                nextScene: "wetlandArea",
                action: "collectHerb",
                actionData: {
                    herbType: "湿地草药",
                    successRate: 60,
                    minAmount: 1,
                    maxAmount: 3
                }
            },
            {
                text: "前往古代墓地",
                nextScene: "ancientGraveyard",
                action: null
            },
            {
                text: "返回天津镇",
                nextScene: "tianjinPort",
                action: null
            }
        ]
    },

    // 古代墓地（8级怪物：亡灵骷髅）
    ancientGraveyard: {
        title: "古代墓地",
        desc: "荒废的古代墓地中散落着破碎的墓碑，阴森氛围让人不寒而栗。几只亡灵骷髅在墓地中游荡，它们物理防御较低，但害怕火焰伤害。",
        options: [
            {
                text: "攻击亡灵骷髅",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "亡灵骷髅",
                    eliteChance: 0.38, // 38%概率遇到精英怪（等级8）
                    eliteMonster: "精英亡灵骷髅",
                    area: "古代墓地"
                }
            },
            {
                text: "搜索古代遗物",
                nextScene: "ancientGraveyard",
                action: "searchRelic",
                actionData: {
                    relicType: "古代遗物",
                    successRate: 40,
                    minAmount: 1,
                    maxAmount: 1
                }
            },
            {
                text: "前往大树顶端",
                nextScene: "treeTop",
                action: null
            },
            {
                text: "返回湿地地区",
                nextScene: "wetlandArea",
                action: null
            }
        ]
    },

    // 大树顶端（9级怪物：闪电飞鼠）
    treeTop: {
        title: "大树顶端",
        desc: "你爬上了一棵参天古树的顶端，这里的视野极其开阔。几只闪电飞鼠在树枝间快速穿梭，它们移动速度极快，攻击带有麻痹效果。",
        options: [
            {
                text: "攻击闪电飞鼠",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "闪电飞鼠",
                    eliteChance: 0.4, // 40%概率遇到精英怪（等级9）
                    eliteMonster: "精英闪电飞鼠",
                    area: "大树顶端"
                }
            },
            {
                text: "采集稀有鸟巢",
                nextScene: "treeTop",
                action: "collectNest",
                actionData: {
                    nestType: "稀有鸟巢",
                    successRate: 25,
                    minAmount: 1,
                    maxAmount: 1
                }
            },
            {
                text: "观察远方",
                nextScene: "treeTop",
                action: "showModal",
                actionData: {
                    title: "远方景色",
                    content: "从树顶可以看到远处的山脉和海洋，还能隐约看到第二大陆的轮廓。"
                }
            },
            {
                text: "返回古代墓地",
                nextScene: "ancientGraveyard",
                action: null
            }
        ]
    },

    // 森林深处
    forestDeep: {
        title: "森林深处",
        desc: "茂密的森林深处，光线变得昏暗。几只野狼在远处徘徊，它们的眼睛在黑暗中闪烁着绿光。",
        options: [
            {
                text: "攻击森林野狼",
                nextScene: "battle",
                action: "encounterMonster",
                actionData: {
                    monster: "森林野狼",
                    eliteChance: 0.3, // 30%概率遇到精英怪（等级3）
                    eliteMonster: "精英森林野狼"
                }
            },
            {
                text: "寻找精灵泉",
                nextScene: (game) => {
                    // 30%概率找到精灵泉，70%概率找不到
                    if (Math.random() < 0.3) {
                        return "spiritSpring";
                    } else {
                        game.showModal("寻找失败", "你在森林中仔细寻找，但没有发现精灵泉的踪迹。也许下次运气会更好。");
                        return "forestDeep";
                    }
                },
                action: null
            },
            {
                text: "返回森林边缘",
                nextScene: "forestEdge",
                action: null
            },
            {
                text: "返回村口",
                nextScene: "villageEntrance",
                action: null
            }
        ]
    },
};