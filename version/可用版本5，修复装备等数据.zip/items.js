// 物品数据定义 - 根据设计文档完善装备和道具系统
const gameItems = {
    // 艾瑞亚大陆装备（1-10级）
    equipment: {
        // 新手村（1-3级）装备
        "普通的新手木剑": {
            name: "普通的新手木剑",
            effect: "攻击力+3",
            attack: 3,
            type: "weapon",
            slot: "weapon",
            quality: "普通",
            level: 1,
            price: 10
        },
        "优秀的硬木剑": {
            name: "优秀的硬木剑",
            effect: "攻击力+5",
            attack: 5,
            type: "weapon",
            slot: "weapon",
            quality: "优秀",
            level: 2,
            price: 50
        },
        "普通的麻布头盔": {
            name: "普通的麻布头盔",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "head",
            quality: "普通",
            level: 1,
            price: 15
        },
        "优秀的皮头盔": {
            name: "优秀的皮头盔",
            effect: "防御+2",
            defense: 2,
            type: "armor",
            slot: "head",
            quality: "优秀",
            level: 2,
            price: 40
        },
        "普通的粗布护肩": {
            name: "普通的粗布护肩",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "shoulder",
            quality: "普通",
            level: 1,
            price: 15
        },
        "优秀的狼皮护肩": {
            name: "优秀的狼皮护肩",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "shoulder",
            quality: "优秀",
            level: 3,
            price: 45
        },
        "普通的粗布上衣": {
            name: "普通的粗布上衣",
            effect: "防御+2",
            defense: 2,
            type: "armor",
            slot: "body",
            quality: "普通",
            level: 1,
            price: 10
        },
        "优秀的皮革胸甲": {
            name: "优秀的皮革胸甲",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "body",
            quality: "优秀",
            level: 3,
            price: 60
        },
        "普通的粗布长裤": {
            name: "普通的粗布长裤",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "leg",
            quality: "普通",
            level: 1,
            price: 10
        },
        "优秀的皮护腿": {
            name: "优秀的皮护腿",
            effect: "防御+2",
            defense: 2,
            type: "armor",
            slot: "leg",
            quality: "优秀",
            level: 2,
            price: 35
        },
        "普通的麻布鞋": {
            name: "普通的麻布鞋",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "foot",
            quality: "普通",
            level: 1,
            price: 12
        },
        "优秀的皮靴": {
            name: "优秀的皮靴",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "foot",
            quality: "优秀",
            level: 3,
            price: 40
        },
        "普通的麻布手套": {
            name: "普通的麻布手套",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "hand",
            quality: "普通",
            level: 1,
            price: 10
        },
        "优秀的皮革护腕": {
            name: "优秀的皮革护腕",
            effect: "防御+2",
            defense: 2,
            type: "armor",
            slot: "bracelet",
            quality: "优秀",
            level: 3,
            price: 55
        },
        "普通的铜手镯": {
            name: "普通的铜手镯",
            effect: "防御+1",
            defense: 1,
            type: "armor",
            slot: "bracelet",
            quality: "普通",
            level: 1,
            price: 20
        },
        "普通的木项链": {
            name: "普通的木项链",
            effect: "攻击+1",
            attack: 1,
            type: "armor",
            slot: "necklace",
            quality: "普通",
            level: 1,
            price: 18
        },
        "优秀的小珍珠项链": {
            name: "优秀的小珍珠项链",
            effect: "攻击+2",
            attack: 2,
            type: "armor",
            slot: "necklace",
            quality: "优秀",
            level: 2,
            price: 65
        },

        // 比奇村（4-6级）装备
        "精良的精铁剑": {
            name: "精良的精铁剑",
            effect: "攻击力+8",
            attack: 8,
            type: "weapon",
            slot: "weapon",
            quality: "精良",
            level: 5,
            price: 200
        },
        "优秀的青铜剑": {
            name: "优秀的青铜剑",
            effect: "攻击力+6",
            attack: 6,
            type: "weapon",
            slot: "weapon",
            quality: "优秀",
            level: 4,
            price: 80
        },
        "精良的精铁头盔": {
            name: "精良的精铁头盔",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "head",
            quality: "精良",
            level: 6,
            price: 180
        },
        "优秀的青铜头盔": {
            name: "优秀的青铜头盔",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "head",
            quality: "优秀",
            level: 4,
            price: 70
        },
        "精良的精铁护肩": {
            name: "精良的精铁护肩",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "shoulder",
            quality: "精良",
            level: 6,
            price: 160
        },
        "优秀的野猪皮护肩": {
            name: "优秀的野猪皮护肩",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "shoulder",
            quality: "优秀",
            level: 5,
            price: 90
        },
        "精良的锁子甲": {
            name: "精良的锁子甲",
            effect: "防御+6",
            defense: 6,
            type: "armor",
            slot: "body",
            quality: "精良",
            level: 6,
            price: 220
        },
        "优秀的野猪皮甲": {
            name: "优秀的野猪皮甲",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "body",
            quality: "优秀",
            level: 5,
            price: 100
        },
        "精良的精铁护腿": {
            name: "精良的精铁护腿",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "leg",
            quality: "精良",
            level: 6,
            price: 150
        },
        "优秀的青铜护腿": {
            name: "优秀的青铜护腿",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "leg",
            quality: "优秀",
            level: 4,
            price: 65
        },
        "精良的铁靴": {
            name: "精良的铁靴",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "foot",
            quality: "精良",
            level: 6,
            price: 140
        },
        "优秀的野猪皮靴": {
            name: "优秀的野猪皮靴",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "foot",
            quality: "优秀",
            level: 5,
            price: 85
        },
        "精良的铁手镯": {
            name: "精良的铁手镯",
            effect: "防御+3",
            defense: 3,
            type: "armor",
            slot: "bracelet",
            quality: "精良",
            level: 6,
            price: 130
        },
        "优秀的铜护腕": {
            name: "优秀的铜护腕",
            effect: "防御+2",
            defense: 2,
            type: "armor",
            slot: "bracelet",
            quality: "优秀",
            level: 4,
            price: 55
        },
        "精良的银项链": {
            name: "精良的银项链",
            effect: "攻击+3",
            attack: 3,
            type: "armor",
            slot: "necklace",
            quality: "精良",
            level: 6,
            price: 170
        },
        "优秀的蝙蝠牙项链": {
            name: "优秀的蝙蝠牙项链",
            effect: "攻击+2",
            attack: 2,
            type: "armor",
            slot: "necklace",
            quality: "优秀",
            level: 5,
            price: 75
        },

        // 南宫村（7-9级）装备
        "史诗的毒刺剑": {
            name: "史诗的毒刺剑",
            effect: "攻击力+12，毒素伤害+5",
            attack: 12,
            type: "weapon",
            slot: "weapon",
            quality: "史诗",
            level: 9,
            price: 0
        },
        "精良的精钢剑": {
            name: "精良的精钢剑",
            effect: "攻击力+10",
            attack: 10,
            type: "weapon",
            slot: "weapon",
            quality: "精良",
            level: 7,
            price: 350
        },
        "精良的钢头盔": {
            name: "精良的钢头盔",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "head",
            quality: "精良",
            level: 8,
            price: 320
        },
        "优秀的抗毒头盔": {
            name: "优秀的抗毒头盔",
            effect: "防御+3，抗毒+5%",
            defense: 3,
            type: "armor",
            slot: "head",
            quality: "优秀",
            level: 7,
            price: 180
        },
        "精良的钢护肩": {
            name: "精良的钢护肩",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "shoulder",
            quality: "精良",
            level: 8,
            price: 300
        },
        "优秀的抗毒护肩": {
            name: "优秀的抗毒护肩",
            effect: "防御+3，抗毒+5%",
            defense: 3,
            type: "armor",
            slot: "shoulder",
            quality: "优秀",
            level: 7,
            price: 160
        },
        "精良的抗毒皮甲": {
            name: "精良的抗毒皮甲",
            effect: "防御+6，抗毒+10%",
            defense: 6,
            type: "armor",
            slot: "body",
            quality: "精良",
            level: 9,
            price: 400
        },
        "优秀的钢甲": {
            name: "优秀的钢甲",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "body",
            quality: "优秀",
            level: 7,
            price: 190
        },
        "精良的钢护腿": {
            name: "精良的钢护腿",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "leg",
            quality: "精良",
            level: 8,
            price: 280
        },
        "优秀的抗毒护腿": {
            name: "优秀的抗毒护腿",
            effect: "防御+3，抗毒+5%",
            defense: 3,
            type: "armor",
            slot: "leg",
            quality: "优秀",
            level: 7,
            price: 150
        },
        "精良的钢靴": {
            name: "精良的钢靴",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "foot",
            quality: "精良",
            level: 8,
            price: 260
        },
        "优秀的抗毒皮靴": {
            name: "优秀的抗毒皮靴",
            effect: "防御+3，抗毒+5%",
            defense: 3,
            type: "armor",
            slot: "foot",
            quality: "优秀",
            level: 7,
            price: 140
        },
        "精良的精钢手镯": {
            name: "精良的精钢手镯",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "bracelet",
            quality: "精良",
            level: 8,
            price: 250
        },
        "优秀的天牛甲壳手镯": {
            name: "优秀的天牛甲壳手镯",
            effect: "防御+3，抗毒+5%",
            defense: 3,
            type: "armor",
            slot: "bracelet",
            quality: "优秀",
            level: 7,
            price: 170
        },
        "精良的抗毒项链": {
            name: "精良的抗毒项链",
            effect: "攻击+4，抗毒+10%",
            attack: 4,
            type: "armor",
            slot: "necklace",
            quality: "精良",
            level: 9,
            price: 330
        },
        "优秀的绿宝石项链": {
            name: "优秀的绿宝石项链",
            effect: "攻击+3",
            attack: 3,
            type: "armor",
            slot: "necklace",
            quality: "优秀",
            level: 7,
            price: 200
        },

        // 天津镇（10级）装备
        "史诗的蟹钳剑": {
            name: "史诗的蟹钳剑",
            effect: "攻击力+15",
            attack: 15,
            type: "weapon",
            slot: "weapon",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的高级精钢剑": {
            name: "精良的高级精钢剑",
            effect: "攻击力+12",
            attack: 12,
            type: "weapon",
            slot: "weapon",
            quality: "精良",
            level: 10,
            price: 500
        },
        "史诗的巨钳蟹头盔": {
            name: "史诗的巨钳蟹头盔",
            effect: "防御+8",
            defense: 8,
            type: "armor",
            slot: "head",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的精钢头盔": {
            name: "精良的精钢头盔",
            effect: "防御+6",
            defense: 6,
            type: "armor",
            slot: "head",
            quality: "精良",
            level: 10,
            price: 480
        },
        "史诗的巨钳蟹护肩": {
            name: "史诗的巨钳蟹护肩",
            effect: "防御+7",
            defense: 7,
            type: "armor",
            slot: "shoulder",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的精钢护肩": {
            name: "精良的精钢护肩",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "shoulder",
            quality: "精良",
            level: 10,
            price: 450
        },
        "史诗的巨钳蟹甲": {
            name: "史诗的巨钳蟹甲",
            effect: "防御+10",
            defense: 10,
            type: "armor",
            slot: "body",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的精钢战甲": {
            name: "精良的精钢战甲",
            effect: "防御+8",
            defense: 8,
            type: "armor",
            slot: "body",
            quality: "精良",
            level: 10,
            price: 550
        },
        "史诗的巨钳蟹护腿": {
            name: "史诗的巨钳蟹护腿",
            effect: "防御+7",
            defense: 7,
            type: "armor",
            slot: "leg",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的精钢护腿": {
            name: "精良的精钢护腿",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "leg",
            quality: "精良",
            level: 10,
            price: 420
        },
        "史诗的巨钳蟹靴": {
            name: "史诗的巨钳蟹靴",
            effect: "防御+7",
            defense: 7,
            type: "armor",
            slot: "foot",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的精钢战靴": {
            name: "精良的精钢战靴",
            effect: "防御+5",
            defense: 5,
            type: "armor",
            slot: "foot",
            quality: "精良",
            level: 10,
            price: 400
        },
        "史诗的蟹爪手镯": {
            name: "史诗的蟹爪手镯",
            effect: "防御+6",
            defense: 6,
            type: "armor",
            slot: "bracelet",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的高级精钢手镯": {
            name: "精良的高级精钢手镯",
            effect: "防御+4",
            defense: 4,
            type: "armor",
            slot: "bracelet",
            quality: "精良",
            level: 10,
            price: 380
        },
        "史诗的海神项链": {
            name: "史诗的海神项链",
            effect: "攻击+6",
            attack: 6,
            type: "armor",
            slot: "necklace",
            quality: "史诗",
            level: 10,
            price: 0
        },
        "精良的珍珠项链": {
            name: "精良的珍珠项链",
            effect: "攻击+4",
            attack: 4,
            type: "armor",
            slot: "necklace",
            quality: "精良",
            level: 10,
            price: 430
        }
    },

    // 消耗品道具
    consumables: {
        "新手药水": {
            name: "新手药水",
            effect: "恢复20点生命值",
            type: "potion",
            heal: 20,
            price: 10
        },
        "中级药水": {
            name: "中级药水",
            effect: "恢复50点生命值",
            type: "potion",
            heal: 50,
            price: 25
        },
        "高级药水": {
            name: "高级药水",
            effect: "恢复100点生命值",
            type: "potion",
            heal: 100,
            price: 50
        },
        "解毒剂": {
            name: "解毒剂",
            effect: "解除中毒状态",
            type: "potion",
            special: "解毒",
            price: 30
        }
    },

    // 添加材料物品定义
    materials: {
        "青蛙腿": {
            name: "青蛙腿",
            effect: "绿皮青蛙的腿，可用于烹饪或任务",
            type: "material",
            price: 1,
            rarity: "普通"
        },
        "兔肉": {
            name: "兔肉",
            effect: "尖牙野兔的肉，可用于烹饪或任务",
            type: "material",
            price: 1,
            rarity: "普通"
        },
        "兔毛": {
            name: "兔毛",
            effect: "尖牙野兔的毛，可用于制作低级皮甲",
            type: "material",
            price: 2,
            rarity: "普通"
        },
        "狼皮": {
            name: "狼皮",
            effect: "森林野狼的皮，可用于制作装备",
            type: "material",
            price: 3,
            rarity: "普通"
        },
        "狼牙": {
            name: "狼牙",
            effect: "森林野狼的牙，可用于制作初级毒素",
            type: "material",
            price: 2,
            rarity: "普通"
        },
        "天牛甲壳": {
            name: "天牛甲壳",
            effect: "毒刺天牛的甲壳，可用于制作抗毒装备",
            type: "material",
            price: 5,
            rarity: "普通"
        },
        "蝙蝠翅膀": {
            name: "蝙蝠翅膀",
            effect: "红眼蝙蝠的翅膀，可用于制作药剂",
            type: "material",
            price: 4,
            rarity: "普通"
        },
        "野猪肉": {
            name: "野猪肉",
            effect: "狂暴野猪的肉，可用于烹饪",
            type: "material",
            price: 3,
            rarity: "普通"
        },
        "猪皮": {
            name: "猪皮",
            effect: "狂暴野猪的皮，可用于制作中级皮甲",
            type: "material",
            price: 4,
            rarity: "普通"
        },
        "史莱姆凝胶": {
            name: "史莱姆凝胶",
            effect: "荆棘史莱姆的凝胶，可用于制作药剂",
            type: "material",
            price: 3,
            rarity: "普通"
        },
        "骷髅骨": {
            name: "骷髅骨",
            effect: "亡灵骷髅的骨头，可用于制作装备",
            type: "material",
            price: 0,
            rarity: "任务专属"
        },
        "飞鼠尾": {
            name: "飞鼠尾",
            effect: "闪电飞鼠的尾巴，可用于制作饰品",
            type: "material",
            price: 6,
            rarity: "普通"
        },
        "马鬃毛": {
            name: "马鬃毛",
            effect: "迅捷天马的鬃毛，可用于制作中级披风",
            type: "material",
            price: 8,
            rarity: "普通"
        },
        "狮鹫利爪": {
            name: "狮鹫利爪",
            effect: "风刃狮鹫的利爪，可用于制作精英匕首",
            type: "material",
            price: 12,
            rarity: "精英"
        },
        "暗影皮毛": {
            name: "暗影皮毛",
            effect: "暗影豹的皮毛，可用于制作隐身装备",
            type: "material",
            price: 15,
            rarity: "精英"
        },
        "蜥蜴鳞片": {
            name: "蜥蜴鳞片",
            effect: "熔岩蜥蜴的鳞片，可用于制作防火甲",
            type: "material",
            price: 10,
            rarity: "精英"
        },
        "冰晶核心": {
            name: "冰晶核心",
            effect: "冰晶巨人的核心，可用于制作魔法武器",
            type: "material",
            price: 20,
            rarity: "精英"
        },
        "毒藤种子": {
            name: "毒藤种子",
            effect: "剧毒藤蔓的种子，可用于制作高级毒素",
            type: "material",
            price: 8,
            rarity: "普通"
        },
        "骑士勋章": {
            name: "骑士勋章",
            effect: "亡灵骑士的勋章，任务专属道具",
            type: "material",
            price: 0,
            rarity: "任务专属"
        },
        "雷鸟羽毛": {
            name: "雷鸟羽毛",
            effect: "雷鸟的羽毛，可用于制作精英饰品",
            type: "material",
            price: 25,
            rarity: "精英"
        },
        "傀儡核心": {
            name: "傀儡核心",
            effect: "岩石傀儡的核心，可用于制作机械装备",
            type: "material",
            price: 30,
            rarity: "精英"
        },
        "守护者之心": {
            name: "守护者之心",
            effect: "瓦尔哈拉守护者的心脏，可用于制作传说装备",
            type: "material",
            price: 0,
            rarity: "稀有"
        },
        "云朵精华": {
            name: "云朵精华",
            effect: "云元素精灵的精华，可用于制作飞行装备",
            type: "material",
            price: 35,
            rarity: "精英"
        },
        "星辰鳞片": {
            name: "星辰鳞片",
            effect: "星辰鱼的鳞片，可用于制作传说饰品",
            type: "material",
            price: 40,
            rarity: "精英"
        },
        "雷霆羽毛": {
            name: "雷霆羽毛",
            effect: "雷霆巨鹰的羽毛，可用于制作雷霆武器",
            type: "material",
            price: 45,
            rarity: "精英"
        },
        "水晶核心": {
            name: "水晶核心",
            effect: "水晶巨人的核心，可用于制作高级魔法武器",
            type: "material",
            price: 50,
            rarity: "精英"
        },
        "龙鳞": {
            name: "龙鳞",
            effect: "魔法飞龙的鳞片，可用于制作龙鳞甲",
            type: "material",
            price: 60,
            rarity: "精英"
        },
        "神之印记": {
            name: "神之印记",
            effect: "神使的印记，任务专属道具",
            type: "material",
            price: 0,
            rarity: "任务专属"
        },
        "审判之剑（材料）": {
            name: "审判之剑（材料）",
            effect: "审判者的剑材料，可用于制作史诗武器",
            type: "material",
            price: 80,
            rarity: "稀有"
        },
        "雕像碎片": {
            name: "雕像碎片",
            effect: "守护者雕像的碎片，任务专属道具",
            type: "material",
            price: 0,
            rarity: "任务专属"
        },
        "天使之翼": {
            name: "天使之翼",
            effect: "堕落天使的翅膀，可用于制作传说翅膀",
            type: "material",
            price: 150,
            rarity: "稀有"
        },
        "创世神器（碎片）": {
            name: "创世神器（碎片）",
            effect: "创世神的神器碎片，可用于制作最终武器",
            type: "material",
            price: 0,
            rarity: "终极稀有"
        },
        "深海珍珠": {
            name: "深海珍珠",
            effect: "巨钳蟹的珍珠，可用于制作高级恢复食物",
            type: "material",
            price: 25,
            rarity: "稀有"
        },
        "守护者之心碎片": {
            name: "守护者之心碎片",
            effect: "瓦尔哈拉守护者的心脏碎片，可用于制作传说装备",
            type: "material",
            price: 0,
            rarity: "稀有"
        },
        "铁矿镐": {
            name: "铁矿镐",
            effect: "用于采集铁矿的工具",
            type: "tool",
            price: 15,
            rarity: "普通"
        },
        "初级生命药水配方": {
            name: "初级生命药水配方",
            effect: "制作初级生命药水的配方",
            type: "recipe",
            price: 30,
            rarity: "普通"
        },
        "高级锻造配方": {
            name: "高级锻造配方",
            effect: "高级装备锻造配方",
            type: "recipe",
            price: 100,
            rarity: "稀有"
        },
        "航海许可证": {
            name: "航海许可证",
            effect: "前往天津镇的航海许可证",
            type: "quest",
            price: 0,
            rarity: "任务专属"
        },
    },

    // 统一获取物品的方法
    getItem(itemName) {
        // 优先在装备中查找
        if (this.equipment[itemName]) {
            return this.equipment[itemName];
        }
        // 在消耗品中查找
        if (this.consumables[itemName]) {
            return this.consumables[itemName];
        }
        // 在材料中查找
        if (this.materials[itemName]) {
            return this.materials[itemName];
        }
        return null;
    },

    // 获取商店物品列表
    getShopItems(shopType, playerLevel) {
        let items = [];

        switch (shopType) {
            case "weapon":
                Object.values(this.equipment).forEach(item => {
                    if (item.type === "weapon" && item.level <= playerLevel) {
                        items.push(item);
                    }
                });
                break;
            case "armor":
                Object.values(this.equipment).forEach(item => {
                    if (item.type === "armor" && item.level <= playerLevel) {
                        items.push(item);
                    }
                });
                break;
            case "potion":
                items = Object.values(this.consumables);
                break;
        }

        return items;
    }
};