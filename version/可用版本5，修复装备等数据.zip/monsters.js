// 怪物数据定义 - 根据设计文档完善怪物系统
const gameMonsters = {
    // 艾瑞亚大陆怪物（1-10级）
    "艾瑞亚大陆": {
        "绿皮青蛙": {
            name: "绿皮青蛙",
            level: 1,
            hp: 20,
            maxHp: 20,
            attack: 5,
            defense: 2,
            exp: 10,
            gold: 5,
            drop: {
                item: "青蛙腿",
                chance: 0.7,
                count: 1
            },
            trait: "移动速度慢，攻击附带轻微中毒效果",
            area: "晨曦村周边沼泽"
        },
        "精英绿皮青蛙": {
            name: "精英绿皮青蛙",
            level: 2,
            hp: 35,
            maxHp: 35,
            attack: 8,
            defense: 4,
            exp: 20,
            gold: 10,
            drop: {
                item: "青蛙腿",
                chance: 0.9,
                count: 2
            },
            equipmentDrop: [
                { item: "普通的新手木剑", chance: 0.3 },
                { item: "普通的麻布头盔", chance: 0.4 },
                { item: "普通的粗布上衣", chance: 0.4 }
            ],
            trait: "移动速度中等，攻击附带中毒效果，生命值更高",
            area: "晨曦村周边沼泽"
        },
        "尖牙野兔": {
            name: "尖牙野兔",
            level: 2,
            hp: 30,
            maxHp: 30,
            attack: 8,
            defense: 3,
            exp: 15,
            gold: 8,
            drop: {
                item: "野兔肉",
                chance: 0.8,
                count: 1
            },
            trait: "警惕性高，被攻击后会迅速逃跑",
            area: "森林边缘"
        },
        "精英尖牙野兔": {
            name: "精英尖牙野兔",
            level: 3,
            hp: 50,
            maxHp: 50,
            attack: 12,
            defense: 6,
            exp: 25,
            gold: 16,
            drop: {
                item: "野兔肉",
                chance: 0.9,
                count: 2
            },
            equipmentDrop: [
                { item: "优秀的硬木剑", chance: 0.25 },
                { item: "优秀的皮头盔", chance: 0.35 },
                { item: "优秀的皮护腿", chance: 0.35 }
            ],
            trait: "警惕性极高，被攻击后会迅速反击",
            area: "森林边缘"
        },
        "森林野狼": {
            name: "森林野狼",
            level: 3,
            hp: 45,
            maxHp: 45,
            attack: 12,
            defense: 5,
            exp: 20,
            gold: 12,
            drop: {
                item: "狼皮",
                chance: 0.6,
                count: 1
            },
            trait: "以群体形式出没，通常 3-5 只一起活动",
            area: "森林深处"
        },
        "精英森林野狼": {
            name: "精英森林野狼",
            level: 4,
            hp: 70,
            maxHp: 70,
            attack: 18,
            defense: 8,
            exp: 35,
            gold: 24,
            drop: {
                item: "狼皮",
                chance: 0.8,
                count: 2
            },
            equipmentDrop: [
                { item: "优秀的狼皮护肩", chance: 0.3 },
                { item: "优秀的皮革胸甲", chance: 0.25 },
                { item: "优秀的皮靴", chance: 0.3 }
            ],
            trait: "以精英群体形式出没，通常 2-3 只一起活动",
            area: "森林深处"
        },
        "毒刺天牛": {
            name: "毒刺天牛",
            level: 4,
            hp: 60,
            maxHp: 60,
            attack: 15,
            defense: 8,
            exp: 25,
            gold: 18,
            drop: {
                item: "天牛甲壳",
                chance: 0.5,
                count: 1
            },
            trait: "防御能力较高，会喷射毒液",
            area: "南宫村矿洞外"
        },
        "精英毒刺天牛": {
            name: "精英毒刺天牛",
            level: 5,
            hp: 90,
            maxHp: 90,
            attack: 22,
            defense: 12,
            exp: 40,
            gold: 32,
            drop: {
                item: "天牛甲壳",
                chance: 0.7,
                count: 2
            },
            equipmentDrop: [
                { item: "优秀的青铜剑", chance: 0.25 },
                { item: "优秀的青铜头盔", chance: 0.3 },
                { item: "优秀的铜护腕", chance: 0.35 }
            ],
            trait: "防御能力极强，会喷射剧毒毒液",
            area: "南宫村矿洞外"
        },
        "红眼蝙蝠": {
            name: "红眼蝙蝠",
            level: 5,
            hp: 75,
            maxHp: 75,
            attack: 18,
            defense: 10,
            exp: 30,
            gold: 22,
            drop: {
                item: "蝙蝠翅膀",
                chance: 0.4,
                count: 1
            },
            trait: "在夜间，其攻击力会有所提升",
            area: "废弃矿井"
        },
        "精英红眼蝙蝠": {
            name: "精英红眼蝙蝠",
            level: 6,
            hp: 110,
            maxHp: 110,
            attack: 26,
            defense: 15,
            exp: 45,
            gold: 40,
            drop: {
                item: "蝙蝠翅膀",
                chance: 0.6,
                count: 2
            },
            equipmentDrop: [
                { item: "精良的精铁剑", chance: 0.2 },
                { item: "精良的精铁头盔", chance: 0.25 },
                { item: "精良的精铁护肩", chance: 0.25 }
            ],
            trait: "在夜间，其攻击力会大幅提升",
            area: "废弃矿井"
        },
        "狂暴野猪": {
            name: "狂暴野猪",
            level: 6,
            hp: 90,
            maxHp: 90,
            attack: 22,
            defense: 12,
            exp: 35,
            gold: 28,
            drop: {
                item: "野猪肉",
                chance: 0.7,
                count: 1
            },
            trait: "被攻击后会进入狂暴状态（攻击力 + 5）",
            area: "比奇村农田"
        },
        "精英狂暴野猪": {
            name: "精英狂暴野猪",
            level: 7,
            hp: 130,
            maxHp: 130,
            attack: 30,
            defense: 18,
            exp: 50,
            gold: 48,
            drop: {
                item: "野猪肉",
                chance: 0.8,
                count: 2
            },
            equipmentDrop: [
                { item: "精良的锁子甲", chance: 0.2 },
                { item: "精良的精铁护腿", chance: 0.25 },
                { item: "精良的铁靴", chance: 0.25 }
            ],
            trait: "被攻击后会立即进入狂暴状态（攻击力 + 8）",
            area: "比奇村农田"
        },
        "荆棘史莱姆": {
            name: "荆棘史莱姆",
            level: 7,
            hp: 110,
            maxHp: 110,
            attack: 25,
            defense: 15,
            exp: 40,
            gold: 35,
            drop: {
                item: "史莱姆凝胶",
                chance: 0.6,
                count: 1
            },
            trait: "对钝器伤害免疫，受到穿刺伤害时 hp-20%",
            area: "湿地"
        },
        "精英荆棘史莱姆": {
            name: "精英荆棘史莱姆",
            level: 8,
            hp: 160,
            maxHp: 160,
            attack: 35,
            defense: 22,
            exp: 55,
            gold: 56,
            drop: {
                item: "史莱姆凝胶",
                chance: 0.7,
                count: 2
            },
            equipmentDrop: [
                { item: "精良的钢头盔", chance: 0.18 },
                { item: "精良的钢护肩", chance: 0.2 },
                { item: "精良的钢护腿", chance: 0.2 }
            ],
            trait: "对钝器伤害完全免疫，受到穿刺伤害时 hp-30%",
            area: "湿地"
        },
        "亡灵骷髅": {
            name: "亡灵骷髅",
            level: 8,
            hp: 130,
            maxHp: 130,
            attack: 28,
            defense: 18,
            exp: 45,
            gold: 40,
            drop: {
                item: "骷髅骨",
                chance: 0.8,
                count: 1
            },
            trait: "物理防御较低，害怕火焰伤害（火焰攻击 + 30%）",
            area: "古代墓地"
        },
        "精英亡灵骷髅": {
            name: "精英亡灵骷髅",
            level: 9,
            hp: 190,
            maxHp: 190,
            attack: 40,
            defense: 25,
            exp: 60,
            gold: 64,
            drop: {
                item: "骷髅骨",
                chance: 0.9,
                count: 2
            },
            equipmentDrop: [
                { item: "精良的精钢剑", chance: 0.15 },
                { item: "精良的抗毒皮甲", chance: 0.18 },
                { item: "精良的抗毒项链", chance: 0.2 }
            ],
            trait: "物理防御极低，但火焰伤害抗性 + 50%",
            area: "古代墓地"
        },
        "闪电飞鼠": {
            name: "闪电飞鼠",
            level: 9,
            hp: 150,
            maxHp: 150,
            attack: 32,
            defense: 20,
            exp: 50,
            gold: 45,
            drop: {
                item: "飞鼠尾",
                chance: 0.4,
                count: 1
            },
            trait: "移动速度极快，攻击带有麻痹效果（持续 2 秒）",
            area: "大树顶端"
        },
        "精英闪电飞鼠": {
            name: "精英闪电飞鼠",
            level: 10,
            hp: 220,
            maxHp: 220,
            attack: 45,
            defense: 28,
            exp: 70,
            gold: 72,
            drop: {
                item: "飞鼠尾",
                chance: 0.5,
                count: 2
            },
            equipmentDrop: [
                { item: "史诗的毒刺剑", chance: 0.1 },
                { item: "精良的高级精钢剑", chance: 0.15 },
                { item: "精良的精钢战甲", chance: 0.18 }
            ],
            trait: "移动速度极快，攻击带有强力麻痹效果（持续 3 秒）",
            area: "大树顶端"
        },
        "巨型毒刺天牛": {
            name: "巨型毒刺天牛",
            level: 9,
            hp: 500,
            maxHp: 500,
            attack: 80,
            defense: 30,
            exp: 135,
            gold: 200,
            drop: {},
            equipmentDrop: [
                { item: "精良的精铁剑", chance: 0.25 },
                { item: "精良的精铁头盔", chance: 0.3 },
                { item: "精良的精铁胸甲", chance: 0.3 },
                { item: "精良的精铁护腿", chance: 0.25 },
                { item: "精良的精铁护手", chance: 0.2 }
            ],
            trait: "喷射毒液范围扩大，每 10 秒释放一次毒雾",
            area: "南宫村矿洞深处",
            isBoss: true
        },
        "巨钳蟹": {
            name: "巨钳蟹",
            level: 10,
            hp: 1000,
            maxHp: 1000,
            attack: 120,
            defense: 50,
            exp: 650,
            gold: 500,
            drop: {},
            equipmentDrop: [
                { item: "史诗的巨钳剑", chance: 0.15 },
                { item: "史诗的巨钳头盔", chance: 0.2 },
                { item: "史诗的巨钳胸甲", chance: 0.2 },
                { item: "史诗的巨钳护腿", chance: 0.15 },
                { item: "史诗的巨钳护手", chance: 0.1 }
            ],
            trait: "每隔 30 秒释放范围夹击技能（伤害 + 50%）",
            area: "天津镇海岸",
            isBoss: true
        }
    },

    // 瓦尔哈拉荒原怪物（11-20级）
    "瓦尔哈拉荒原": {
        "迅捷天马": {
            name: "迅捷天马",
            level: 11,
            hp: 180,
            maxHp: 180,
            attack: 38,
            defense: 25,
            exp: 60,
            gold: 50,
            drop: {
                item: "马鬃毛",
                chance: 0.5,
                count: 1
            },
            trait: "会使用冲撞技能（击退玩家 3 米），需预判躲避",
            area: "草原"
        },
        "风刃狮鹫": {
            name: "风刃狮鹫",
            level: 12,
            hp: 220,
            maxHp: 220,
            attack: 45,
            defense: 30,
            exp: 70,
            gold: 60,
            drop: {
                item: "狮鹫利爪",
                chance: 0.4,
                count: 1
            },
            trait: "飞行单位，地面近战职业命中率 - 30%",
            area: "悬崖峭壁"
        },
        "暗影豹": {
            name: "暗影豹",
            level: 13,
            hp: 260,
            maxHp: 260,
            attack: 52,
            defense: 35,
            exp: 80,
            gold: 70,
            drop: {
                item: "暗影皮毛",
                chance: 0.6,
                count: 1
            },
            trait: "夜间隐身（仅光明魔法可显形），暴击率 + 15%",
            area: "黑森林"
        },
        "熔岩蜥蜴": {
            name: "熔岩蜥蜴",
            level: 14,
            hp: 300,
            maxHp: 300,
            attack: 60,
            defense: 40,
            exp: 90,
            gold: 80,
            drop: {
                item: "蜥蜴鳞片",
                chance: 0.5,
                count: 1
            },
            trait: "接触后造成灼烧伤害（hp 每秒 - 5），防火装备可减免",
            area: "火山边缘"
        },
        "冰晶巨人": {
            name: "冰晶巨人",
            level: 15,
            hp: 2500,
            maxHp: 2500,
            attack: 250,
            defense: 120,
            exp: 2000,
            gold: 800,
            drop: {
                item: "冰晶核心",
                chance: 0.1,
                count: 1
            },
            equipmentDrop: [
                { item: "史诗的冰晶巨剑", chance: 0.2 },
                { item: "史诗的冰晶头盔", chance: 0.25 },
                { item: "史诗的冰晶胸甲", chance: 0.25 },
                { item: "史诗的冰晶护腿", chance: 0.2 },
                { item: "史诗的冰晶护手", chance: 0.15 }
            ],
            trait: "死后分裂为 3 只 12 级小冰晶怪",
            area: "冰川地带",
            isBoss: true
        },
        "剧毒藤蔓": {
            name: "剧毒藤蔓",
            level: 16,
            hp: 350,
            maxHp: 350,
            attack: 68,
            defense: 45,
            exp: 100,
            gold: 90,
            drop: {
                item: "毒藤种子",
                chance: 0.5,
                count: 1
            },
            trait: "缠绕技能（玩家无法移动，持续 3 秒）",
            area: "沼泽深处"
        },
        "亡灵骑士": {
            name: "亡灵骑士",
            level: 17,
            hp: 400,
            maxHp: 400,
            attack: 75,
            defense: 50,
            exp: 110,
            gold: 100,
            drop: {
                item: "骑士勋章",
                chance: 0.6,
                count: 1
            },
            trait: "持有盾牌，正面防御 + 50%，背面防御 - 30%",
            area: "废弃城堡"
        },
        "雷鸟": {
            name: "雷鸟",
            level: 18,
            hp: 800,
            maxHp: 800,
            attack: 150,
            defense: 80,
            exp: 540,
            gold: 300,
            drop: {
                item: "雷鸟羽毛",
                chance: 0.3,
                count: 1
            },
            equipmentDrop: [
                { item: "史诗的雷鸟法杖", chance: 0.25 },
                { item: "史诗的雷鸟头盔", chance: 0.3 },
                { item: "史诗的雷鸟胸甲", chance: 0.3 },
                { item: "史诗的雷鸟护腿", chance: 0.25 },
                { item: "史诗的雷鸟护手", chance: 0.2 }
            ],
            trait: "召唤闪电（范围伤害，每秒 1 次），免疫电属性",
            area: "风暴山顶",
            isBoss: true
        },
        "岩石傀儡": {
            name: "岩石傀儡",
            level: 19,
            hp: 480,
            maxHp: 480,
            attack: 85,
            defense: 60,
            exp: 120,
            gold: 120,
            drop: {
                item: "傀儡核心",
                chance: 0.4,
                count: 1
            },
            trait: "仅受暴击伤害（非暴击伤害 - 80%），移动速度慢",
            area: "矿坑底层"
        },
        "瓦尔哈拉守护者": {
            name: "瓦尔哈拉守护者",
            level: 20,
            hp: 4000,
            maxHp: 4000,
            attack: 350,
            defense: 180,
            exp: 3000,
            gold: 1500,
            drop: {
                item: "守护者之心",
                chance: 0.05,
                count: 1
            },
            equipmentDrop: [
                { item: "传说的守护者之剑", chance: 0.1 },
                { item: "传说的守护者头盔", chance: 0.15 },
                { item: "传说的守护者胸甲", chance: 0.15 },
                { item: "传说的守护者护腿", chance: 0.1 },
                { item: "传说的守护者护手", chance: 0.05 }
            ],
            trait: "切换物理 / 魔法免疫形态（每 20 秒切换 1 次）",
            area: "古代遗迹",
            isBoss: true
        }
    },

    // 获取怪物数据的方法
    getMonster: function (monsterName) {
        // 先在艾瑞亚大陆查找
        if (this["艾瑞亚大陆"][monsterName]) {
            return { ...this["艾瑞亚大陆"][monsterName] };
        }
        // 在瓦尔哈拉荒原查找
        if (this["瓦尔哈拉荒原"][monsterName]) {
            return { ...this["瓦尔哈拉荒原"][monsterName] };
        }
        return null;
    },

    // 根据区域获取怪物列表
    getMonstersByArea: function (area) {
        let monsters = [];

        // 查找艾瑞亚大陆的怪物
        Object.values(this["艾瑞亚大陆"]).forEach(monster => {
            if (monster.area === area) {
                monsters.push(monster);
            }
        });

        // 查找瓦尔哈拉荒原的怪物
        Object.values(this["瓦尔哈拉荒原"]).forEach(monster => {
            if (monster.area === area) {
                monsters.push(monster);
            }
        });

        return monsters;
    },

    // 根据等级获取合适的怪物
    getMonstersByLevel: function (level) {
        let monsters = [];
        const continent = level <= 10 ? "艾瑞亚大陆" : "瓦尔哈拉荒原";

        Object.values(this[continent]).forEach(monster => {
            if (Math.abs(monster.level - level) <= 2) {
                monsters.push(monster);
            }
        });

        return monsters;
    }
};