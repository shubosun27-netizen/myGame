// 玩家类 - 管理玩家数据和行为
class Player {
    constructor() {
        // 基本属性
        this.name = "冒险者";
        this.level = 1;
        this.hp = 50;
        this.maxHp = 50;
        this.mp = 30; // 新增：魔法值
        this.maxMp = 30; // 新增：最大魔法值
        this.stamina = 100; // 新增：体力值
        this.maxStamina = 100; // 新增：最大体力值
        this.baseAttack = 5;
        this.baseDefense = 0;
        this.gold = 10;
        this.exp = 0;
        this.expToNextLevel = 100;

        // 装备系统 - 新增多个装备槽位
        this.equipment = {
            head: null,      // 头部
            shoulder: null,  // 肩部
            body: null,      // 身体
            hand: null,      // 手部
            leg: null,       // 腿部
            foot: null,      // 脚部
            bracelet: null,  // 手镯
            necklace: null,  // 项链
            weapon: {        // 武器
                name: "新手木剑（白色）",
                effect: "攻击力+3",
                attack: 3,
                type: "weapon",
                ity: "普通",
                level: 1,
                price: 10
            }
        };

        // 背包系统
        this.inventory = {
            items: [
                { name: "新手药水", count: 2, effect: "恢复20点生命值", type: "potion" }
            ],
            equipment: []  // 背包中的装备
        };

        // 任务系统 - 统一使用新的任务系统
        this.currentQuest = null;
        this.completedQuests = [];
    }

    // 获取总攻击力
    get totalAttack() {
        let attack = this.baseAttack;
        // 累加所有装备提供的攻击力
        if (this.equipment.weapon) attack += this.equipment.weapon.attack || 0;
        if (this.equipment.bracelet) attack += this.equipment.bracelet.attack || 0;
        if (this.equipment.necklace) attack += this.equipment.necklace.attack || 0;
        return attack;
    }

    // 获取总防御力
    get totalDefense() {
        let defense = this.baseDefense;
        // 累加所有装备提供的防御力
        if (this.equipment.head) defense += this.equipment.head.defense || 0;
        if (this.equipment.shoulder) defense += this.equipment.shoulder.defense || 0;
        if (this.equipment.body) defense += this.equipment.body.defense || 0;
        if (this.equipment.hand) defense += this.equipment.hand.defense || 0;
        if (this.equipment.leg) defense += this.equipment.leg.defense || 0;
        if (this.equipment.foot) defense += this.equipment.foot.defense || 0;
        if (this.equipment.bracelet) defense += this.equipment.bracelet.defense || 0;
        if (this.equipment.necklace) defense += this.equipment.necklace.defense || 0;
        return defense;
    }

    // 设置玩家名称
    setName(name) {
        this.name = name || "冒险者";
    }

    // 获得物品 - 更新为使用items.js
    getItem(itemData) {
        let item;

        // 如果是字符串，从items.js获取
        if (typeof itemData === 'string') {
            item = gameItems.getItem(itemData);
        } else {
            item = itemData;
        }

        if (!item) return null;

        // 检查是道具还是装备
        if (item.type === "weapon" || item.type === "armor") {
            this.inventory.equipment.push({
                ...item,
                count: 1
            });
        } else {
            // 修复：处理材料类型的物品
            const existingItem = this.inventory.items.find(i => i.name === item.name);
            if (existingItem) {
                existingItem.count += item.count || 1;
            } else {
                this.inventory.items.push({
                    ...item,
                    count: item.count || 1
                });
            }
        }
        return item;
    }

    // 使用物品
    useItem(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.items.length) {
            return { success: false, message: "无效的物品索引" };
        }

        const item = this.inventory.items[itemIndex];

        // 处理不同类型物品的使用效果
        if (item.type === "potion") {
            // 药水恢复生命值
            const healAmount = parseInt(item.effect.match(/恢复(\d+)点生命值/)[1]);
            this.hp = Math.min(this.maxHp, this.hp + healAmount);

            // 减少物品数量
            item.count -= 1;
            if (item.count <= 0) {
                this.inventory.items.splice(itemIndex, 1);
            }

            return {
                success: true,
                message: `使用了${item.name}，恢复了${healAmount}点生命值`
            };
        } else {
            return { success: false, message: `无法使用${item.name}` };
        }
    }

    // 出售物品
    sellItem(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.items.length) {
            return { success: false, message: "无效的物品索引" };
        }

        const item = this.inventory.items[itemIndex];
        // 简单定价：药水10金币，材料5金币
        const price = item.type === "potion" ? 10 : 5;

        // 增加金币
        this.gold += price * item.count;

        // 从背包移除
        const itemName = item.name;
        const count = item.count;
        this.inventory.items.splice(itemIndex, 1);

        return {
            success: true,
            message: `出售了${count}个${itemName}，获得${price * count}金币`
        };
    }

    // 出售装备
    sellEquipment(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.equipment.length) {
            return { success: false, message: "无效的装备索引" };
        }

        const item = this.inventory.equipment[itemIndex];

        // 装备定价：根据装备品质和等级定价
        let price = 0;
        if (item.quality === "优秀") {
            price = item.level * 20; // 绿色装备：等级 * 20
        } else if (item.quality === "精良") {
            price = item.level * 30; // 蓝色装备：等级 * 30
        } else {
            price = item.level * 10; // 白色装备：等级 * 10
        }

        // 如果装备有price属性，使用装备的原始价格
        if (item.price && item.price > 0) {
            price = Math.floor(item.price * 0.5); // 出售价格为原价的50%
        }

        // 最低价格保证
        price = Math.max(price, 5);

        // 增加金币
        this.gold += price;

        // 从背包移除装备
        const itemName = item.name;
        this.inventory.equipment.splice(itemIndex, 1);

        return {
            success: true,
            message: `出售了${itemName}，获得${price}金币`
        };
    }

    // 装备物品
    equipItem(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.equipment.length) {
            return { success: false, message: "无效的装备索引" };
        }

        const item = this.inventory.equipment[itemIndex];

        // 检查装备是否有对应的槽位
        if (!item.slot || !this.equipment.hasOwnProperty(item.slot)) {
            return { success: false, message: `无法装备${item.name}` };
        }

        // 如果该槽位已有装备，将其放回背包
        const currentEquipped = this.equipment[item.slot];
        if (currentEquipped) {
            this.inventory.equipment.push(currentEquipped);
        }

        // 装备新物品
        this.equipment[item.slot] = item;
        // 从背包移除
        this.inventory.equipment.splice(itemIndex, 1);

        return {
            success: true,
            message: `已装备${item.name}`
        };
    }

    // 卸下装备
    unequipItem(slot) {
        if (!this.equipment.hasOwnProperty(slot)) {
            return { success: false, message: "无效的装备槽位" };
        }

        const item = this.equipment[slot];
        if (!item) {
            return { success: false, message: "该槽位没有装备" };
        }

        // 将装备放回背包
        this.inventory.equipment.push(item);
        // 卸下装备
        this.equipment[slot] = null;

        return {
            success: true,
            message: `已卸下${item.name}`
        };
    }

    // 接受任务 - 修复为统一使用新的任务系统
    acceptQuest(questData) {
        // 检查是否已经接受过该任务
        if (this.currentQuest && this.currentQuest.id === questData.id) {
            return { success: false, message: "你已经接受了这个任务。" };
        }

        // 检查前置任务
        const questInfo = gameQuests.getQuest(questData.id);
        if (questInfo && questInfo.prerequisite) {
            if (!this.completedQuests.includes(questInfo.prerequisite)) {
                return { success: false, message: `你需要先完成"${gameQuests.getQuest(questInfo.prerequisite)?.name}"任务。` };
            }
        }

        // 接受任务
        this.currentQuest = {
            id: questData.id,
            name: questData.name,
            target: questData.target,
            targetCount: questData.targetCount,
            currentCount: 0,
            reward: questData.reward
        };

        return { success: true, quest: this.currentQuest };
    }

    // 更新任务进度 - 修复为使用新的任务系统
    updateQuestProgress(monsterName) {
        if (!this.currentQuest) return { quest: null, completed: false };

        // 检查击杀的怪物是否匹配任务目标
        if (monsterName === this.currentQuest.target) {
            this.currentQuest.currentCount++;

            // 检查任务是否完成
            if (this.currentQuest.currentCount >= this.currentQuest.targetCount) {
                return { quest: this.currentQuest, completed: true };
            }
        }

        return { quest: this.currentQuest, completed: false };
    }


    // 完成任务 - 修复为使用新的任务系统
    finishQuest() {
        if (!this.currentQuest) return false;

        if (!this.completedQuests) {
            this.completedQuests = [];
        }

        this.completedQuests.push(this.currentQuest.id);
        this.currentQuest = null;
        return true;
    }

    // 放弃当前任务
    abandonQuest() {
        if (!this.currentQuest) {
            return { success: false, message: "没有进行中的任务可以放弃。" };
        }

        const questName = this.currentQuest.name;
        this.currentQuest = null;

        return { success: true, message: `已放弃任务【${questName}】` };
    }

    // 检查升级
    checkLevelUp() {
        let leveledUp = false;

        // 检查是否可以升级
        while (this.exp >= this.expToNextLevel) {
            this.level += 1;
            this.exp -= this.expToNextLevel;
            this.expToNextLevel = Math.floor(this.expToNextLevel * 1.5);

            // 升级属性提升
            this.maxHp += 30;
            this.hp = this.maxHp;
            this.baseAttack += 2;
            this.baseDefense += 1;

            leveledUp = true;
        }

        return leveledUp;
    }

    // 添加物品到背包
    addItemToInventory(item) {
        // 检查是道具还是装备
        if (item.type === "weapon" || item.type === "armor") {
            this.inventory.equipment.push({
                ...item,
                count: 1
            });
        } else {
            const existingItem = this.inventory.items.find(i => i.name === item.name);
            if (existingItem) {
                existingItem.count += item.count || 1;
            } else {
                this.inventory.items.push({
                    ...item,
                    count: item.count || 1
                });
            }
        }
    }

    // 恢复生命值
    restoreHp(type) {
        if (type === "full") {
            this.hp = this.maxHp;
        } else if (typeof type === "number") {
            this.hp = Math.min(this.maxHp, this.hp + type);
        }
    }

    // 新增：恢复魔法值
    restoreMp(type) {
        if (type === "full") {
            this.mp = this.maxMp;
        } else if (typeof type === "number") {
            this.mp = Math.min(this.maxMp, this.mp + type);
        }
    }

    // 新增：恢复体力值
    restoreStamina(type) {
        if (type === "full") {
            this.stamina = this.maxStamina;
        } else if (typeof type === "number") {
            this.stamina = Math.min(this.maxStamina, this.stamina + type);
        }
    }

    // 新增：恢复全部状态
    restoreFullStatus() {
        this.hp = this.maxHp;
        this.mp = this.maxMp;
        this.stamina = this.maxStamina;
    }

    // 受到伤害
    takeDamage(attack) {
        // 计算实际伤害（攻击方攻击力 - 玩家防御力，最低1点）
        const damage = Math.max(1, attack - this.totalDefense);
        this.hp = Math.max(0, this.hp - damage);
        return damage;
    }

    // 增加经验值
    addExp(amount) {
        this.exp += amount;
        let leveledUp = false;

        // 检查是否可以升级
        while (this.exp >= this.expToNextLevel) {
            this.level += 1;
            this.exp -= this.expToNextLevel;
            this.expToNextLevel = Math.floor(this.expToNextLevel * 1.5);

            // 升级属性提升
            this.maxHp += 30;
            this.hp = this.maxHp;
            this.baseAttack += 2;
            this.baseDefense += 1;

            leveledUp = true;
        }

        return leveledUp;
    }

    // 购买物品
    buyItem(itemData) {
        if (this.gold < itemData.price) {
            return {
                success: false,
                message: `金币不足，需要${itemData.price}金币`
            };
        }

        // 扣除金币
        this.gold -= itemData.price;

        // 添加物品到背包
        this.getItem(itemData);

        return {
            success: true,
            message: `购买了${itemData.name}`
        };
    }

    // 完成任务
    completeQuest() {
        if (!this.currentQuest) return "没有进行中的任务。";

        const questInfo = gameQuests.getQuest(this.currentQuest.id);
        if (!questInfo) return "任务信息错误。";

        // 发放奖励
        if (questInfo.reward.gold) {
            this.gold += questInfo.reward.gold;
        }

        if (questInfo.reward.exp) {
            this.exp += questInfo.reward.exp;
            this.checkLevelUp();
        }

        if (questInfo.reward.items) {
            questInfo.reward.items.forEach(itemId => {
                const item = gameItems.getItem(itemId);
                if (item) {
                    this.addItemToInventory(item);
                }
            });
        }

        // 记录完成的任务
        this.completedQuests.push(this.currentQuest.id);

        // 清空当前任务
        const completedQuestName = this.currentQuest.name;
        this.currentQuest = null;

        return `任务"${completedQuestName}"完成！`;
    }

    // 获取可接取的任务列表
    getAvailableQuests() {
        return gameQuests.getAvailableQuests(this.completedQuests, this.level);
    }

}