// 游戏控制类 - 管理游戏流程和场景切换
class Game {
    constructor() {
        // 初始化玩家
        this.player = new Player();
        // 当前场景 - 初始为角色创建
        this.currentScene = "characterCreate";
        // 当前战斗中的怪物
        this.currentMonster = null;
        // DOM元素引用
        this.elements = this.initElements();
        // 绑定事件
        this.bindEvents();
        // 初始化游戏
        this.init();
    }

    // 初始化DOM元素引用
    initElements() {
        return {
            // 导航按钮
            gameNavBtn: document.getElementById("gameNavBtn"),
            inventoryNavBtn: document.getElementById("inventoryNavBtn"),
            equipmentNavBtn: document.getElementById("equipmentNavBtn"),
            
            // 页面容器
            gamePage: document.getElementById("gamePage"),
            inventoryPage: document.getElementById("inventoryPage"),
            equipmentPage: document.getElementById("equipmentPage"),
            
            // 状态面板元素
            playerName: document.getElementById("playerName"),
            level: document.getElementById("level"),
            hp: document.getElementById("hp"),
            maxHp: document.getElementById("maxHp"),
            gold: document.getElementById("gold"),
            attack: document.getElementById("attack"),
            defense: document.getElementById("defense"),
            
            // 场景元素
            sceneTitle: document.getElementById("sceneTitle"),
            sceneDesc: document.getElementById("sceneDesc"),
            optionsContainer: document.getElementById("optionsContainer"),
            characterName: document.getElementById("characterName"),
            startBtn: document.getElementById("startBtn"),
            characterCreatePanel: document.getElementById("characterCreatePanel"),
            
            // 任务面板
            activeQuestPanel: document.getElementById("activeQuestPanel"),
            activeQuestName: document.getElementById("activeQuestName"),
            activeQuestTarget: document.getElementById("activeQuestTarget"),
            activeQuestProgress: document.getElementById("activeQuestProgress"),
            activeQuestReward: document.getElementById("activeQuestReward"),
            
            // 背包页面元素
            inventoryList: document.getElementById("inventoryList"),
            backFromInventory: document.getElementById("backFromInventory"),
            
            // 装备页面元素
            equipmentSlots: document.getElementById("equipmentSlots"),
            backFromEquipment: document.getElementById("backFromEquipment"),
            
            // 弹窗元素
            modal: document.getElementById("modal"),
            modalTitle: document.getElementById("modalTitle"),
            modalDesc: document.getElementById("modalDesc"),
            modalBtn: document.getElementById("modalBtn")
        };
    }

    // 绑定事件处理程序
    bindEvents() {
        // 导航按钮事件
        this.elements.gameNavBtn.addEventListener("click", () => this.navigateTo("game"));
        this.elements.inventoryNavBtn.addEventListener("click", () => {
            this.navigateTo("inventory");
            this.renderInventory();
        });
        this.elements.equipmentNavBtn.addEventListener("click", () => {
            this.navigateTo("equipment");
            this.renderEquipment();
        });
        
        // 返回按钮事件
        this.elements.backFromInventory.addEventListener("click", () => this.navigateTo("game"));
        this.elements.backFromEquipment.addEventListener("click", () => this.navigateTo("game"));
        
        // 开始游戏按钮
        this.elements.startBtn.addEventListener("click", () => this.startGame());
        
        // 弹窗按钮
        this.elements.modalBtn.addEventListener("click", () => {
            this.elements.modal.classList.add("hidden");
            this.renderScene();
        });
    }

    // 导航到不同页面
    navigateTo(page) {
        // 隐藏所有页面
        this.elements.gamePage.classList.remove("active");
        this.elements.inventoryPage.classList.remove("active");
        this.elements.equipmentPage.classList.remove("active");
        
        // 移除所有导航按钮的活跃状态
        this.elements.gameNavBtn.classList.remove("active");
        this.elements.inventoryNavBtn.classList.remove("active");
        this.elements.equipmentNavBtn.classList.remove("active");
        
        // 显示目标页面并激活对应导航按钮
        if (page === "game") {
            this.elements.gamePage.classList.add("active");
            this.elements.gameNavBtn.classList.add("active");
        } else if (page === "inventory") {
            this.elements.inventoryPage.classList.add("active");
            this.elements.inventoryNavBtn.classList.add("active");
        } else if (page === "equipment") {
            this.elements.equipmentPage.classList.add("active");
            this.elements.equipmentNavBtn.classList.add("active");
        }
    }

    // 初始化游戏
    init() {
        // 首次加载显示角色创建界面
        this.renderScene();
    }

    // 开始游戏 - 从角色创建进入第一个场景
    startGame() {
        // 设置玩家名称
        this.player.setName(this.elements.characterName.value.trim());
        // 隐藏角色创建面板
        this.elements.characterCreatePanel.classList.add("hidden");
        // 显示选项容器
        this.elements.optionsContainer.classList.remove("hidden");
        // 切换到第一个场景
        this.currentScene = "wakeUp";
        // 渲染场景
        this.renderScene();
    }

    // 渲染当前场景
    renderScene() {
        const scene = gameScenes[this.currentScene];
        if (!scene) return;

        // 更新场景标题和描述
        this.elements.sceneTitle.textContent = scene.title;
        
        // 特殊处理战斗场景描述
        if (this.currentScene === "battle" && this.currentMonster) {
            this.elements.sceneDesc.innerHTML = `
                <div class="battle-info">
                    <p>当前对手：<span class="highlight">${this.currentMonster.name}（${this.currentMonster.level}级）</span></p>
                    <p>怪物生命值：<span class="highlight">${this.currentMonster.hp}/${this.currentMonster.maxHp}</span></p>
                    <p>怪物特性：<span class="highlight">${this.currentMonster.trait}</span></p>
                    <p>你的生命值：<span class="highlight">${this.player.hp}/${this.player.maxHp}</span></p>
                    ${this.currentMonster.name.includes("BOSS") ? '<p class="boss-warning">⚠️ BOSS警告：会释放范围技能，请谨慎应对！</p>' : ''}
                </div>
                你与${this.currentMonster.name}展开了战斗！
            `;
        } else {
            this.elements.sceneDesc.textContent = scene.desc;
        }

        // 清空选项容器
        this.elements.optionsContainer.innerHTML = "";
        
        // 生成场景选项
        if (scene.options && scene.options.length > 0) {
            scene.options.forEach((option) => {
                const btn = document.createElement("button");
                btn.className = "option-btn";
                btn.textContent = this.getOptionText(option);
                btn.addEventListener("click", () => {
                    this.handleOptionSelect(option);
                });
                this.elements.optionsContainer.appendChild(btn);
            });
        }

        // 更新玩家状态面板
        this.updateStatusPanel();
        
        // 更新任务面板
        this.updateQuestPanel();
    }

    // 渲染背包页面
    renderInventory() {
        this.elements.inventoryList.innerHTML = "";
        
        // 显示物品
        if (this.player.inventory.items.length > 0) {
            this.player.inventory.items.forEach((item, index) => {
                const itemSlot = document.createElement("div");
                itemSlot.className = "item-slot";
                itemSlot.innerHTML = `
                    <p>${item.name}（${item.count}个）</p>
                    <p>${item.effect}</p>
                    <div class="item-actions">
                        <button class="item-action-btn use" data-index="${index}" data-type="item">使用</button>
                        <button class="item-action-btn sell" data-index="${index}" data-type="item">出售</button>
                    </div>
                `;
                this.elements.inventoryList.appendChild(itemSlot);
            });
        } else {
            const emptySlot = document.createElement("div");
            emptySlot.className = "item-slot";
            emptySlot.innerHTML = "<p>暂无消耗品</p>";
            this.elements.inventoryList.appendChild(emptySlot);
        }
        
        // 添加分隔线
        const divider = document.createElement("div");
        divider.style.height = "1px";
        divider.style.backgroundColor = "#555";
        divider.style.margin = "15px 0";
        this.elements.inventoryList.appendChild(divider);
        
        // 显示装备
        if (this.player.inventory.equipment.length > 0) {
            this.player.inventory.equipment.forEach((item, index) => {
                const itemSlot = document.createElement("div");
                itemSlot.className = "item-slot";
                itemSlot.innerHTML = `
                    <p>${item.name}</p>
                    <p>${item.effect}</p>
                    <div class="item-actions">
                        <button class="item-action-btn equip" data-index="${index}" data-type="equipment">装备</button>
                    </div>
                `;
                this.elements.inventoryList.appendChild(itemSlot);
            });
        } else {
            const emptySlot = document.createElement("div");
            emptySlot.className = "item-slot";
            emptySlot.innerHTML = "<p>暂无未装备的装备</p>";
            this.elements.inventoryList.appendChild(emptySlot);
        }
        
        // 绑定背包物品按钮事件
        document.querySelectorAll(".item-action-btn.use").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.useItem(index);
                if (result.success) {
                    this.showModal("使用成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                } else {
                    this.showModal("使用失败", result.message);
                }
            });
        });
        
        document.querySelectorAll(".item-action-btn.sell").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.sellItem(index);
                if (result.success) {
                    this.showModal("出售成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                } else {
                    this.showModal("出售失败", result.message);
                }
            });
        });
        
        document.querySelectorAll(".item-action-btn.equip").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const index = parseInt(e.currentTarget.dataset.index);
                const result = this.player.equipItem(index);
                if (result.success) {
                    this.showModal("装备成功", result.message);
                    this.updateStatusPanel();
                    this.renderInventory();
                    this.renderEquipment();
                } else {
                    this.showModal("装备失败", result.message);
                }
            });
        });
    }

    // 渲染装备页面
    renderEquipment() {
        this.elements.equipmentSlots.innerHTML = "";
        
        // 装备槽位配置
        const equipmentSlots = [
            { slot: "head", name: "头部" },
            { slot: "shoulder", name: "肩部" },
            { slot: "body", name: "身体" },
            { slot: "hand", name: "手部" },
            { slot: "leg", name: "腿部" },
            { slot: "foot", name: "脚部" },
            { slot: "bracelet", name: "手镯" },
            { slot: "necklace", name: "项链" },
            { slot: "weapon", name: "武器" }
        ];
        
        // 渲染每个装备槽位
        equipmentSlots.forEach(({ slot, name }) => {
            const equipment = this.player.equipment[slot];
            const slotElement = document.createElement("div");
            slotElement.className = `equipment-slot ${equipment ? "" : "empty"}`;
            
            if (equipment) {
                slotElement.innerHTML = `
                    <p>${name}：${equipment.name}</p>
                    <p>${equipment.effect}</p>
                    ${slot !== "weapon" ? `<div class="item-actions">
                        <button class="item-action-btn unequip" data-slot="${slot}">卸下</button>
                    </div>` : ""}
                `;
            } else {
                slotElement.innerHTML = `<p>${name}：无</p>`;
            }
            
            this.elements.equipmentSlots.appendChild(slotElement);
        });
        
        // 绑定卸下装备按钮事件
        document.querySelectorAll(".item-action-btn.unequip").forEach(btn => {
            btn.addEventListener("click", (e) => {
                const slot = e.currentTarget.dataset.slot;
                const result = this.player.unequipItem(slot);
                if (result.success) {
                    this.showModal("卸下装备", result.message);
                    this.updateStatusPanel();
                    this.renderEquipment();
                    this.renderInventory();
                } else {
                    this.showModal("操作失败", result.message);
                }
            });
        });
    }

    // 获取选项文本（处理动态文本）
    getOptionText(option) {
        if (option.action === "useItem" && this.player.inventory.items.length === 0) {
            return "使用道具（无可用道具）";
        }
        return option.text;
    }

    // 处理选项选择
    handleOptionSelect(option) {
        // 处理动态场景
        if (typeof option.nextScene === "function") {
            option.nextScene = option.nextScene(this);
        }
        
        // 执行选项动作
        if (option.action) {
            const actionResult = this.executeAction(option.action, option.actionData);
            if (!actionResult) return; // 动作执行失败（如没钱买装备）
        }

        // 切换到下一场景
        if (option.nextScene) {
            this.currentScene = option.nextScene;
            this.renderScene();
        }
    }

    // 执行动作（如获取物品、接受任务）
    executeAction(actionType, actionData) {
        switch (actionType) {
            // 获取物品
            case "getItem":
                const item = this.player.getItem(actionData);
                this.showModal("获得物品", `你获得了${item.name}（${item.effect}）！`);
                this.renderInventory(); // 更新背包显示
                return true;

            // 接受任务
            case "acceptQuest":
                const quest = this.player.acceptQuest(actionData);
                this.showModal("接受任务", 
                    `你接受了任务【${quest.name}】\n` +
                    `目标：消灭${quest.targetCount}只${quest.target}\n` +
                    `奖励：${quest.reward}`
                );
                return true;

            // 恢复生命值
            case "restoreHp":
                // 检查是否需要付费
                if (actionData.cost && this.player.gold < actionData.cost) {
                    this.showModal("金币不足", `治疗需要${actionData.cost}金币，但你只有${this.player.gold}金币`);
                    return false;
                }
                
                // 扣除金币
                if (actionData.cost) {
                    this.player.gold -= actionData.cost;
                }
                
                this.player.restoreHp(actionData.type === "full" ? "full" : actionData.amount);
                this.showModal("生命值恢复", 
                    `你恢复了生命值，当前生命值：${this.player.hp}/${this.player.maxHp}`
                );
                return true;

            // 遭遇怪物
            case "encounterMonster":
                // 初始化怪物数据
                this.currentMonster = {
                    name: actionData.name,
                    level: actionData.level,
                    hp: actionData.hp,
                    maxHp: actionData.hp,
                    attack: actionData.attack,
                    defense: actionData.defense,
                    exp: actionData.exp,
                    drop: actionData.drop,
                    trait: actionData.trait
                };
                return true;

            // 玩家攻击
            case "playerAttack":
                if (!this.currentMonster) return false;

                // 计算伤害（玩家攻击-怪物防御，最低1点）
                const damageToMonster = Math.max(1, this.player.totalAttack - this.currentMonster.defense);
                this.currentMonster.hp -= damageToMonster;

                // 检查怪物是否死亡
                if (this.currentMonster.hp <= 0) {
                    this.handleMonsterDeath();
                    return true;
                }

                // 怪物反击
                const damageToPlayer = this.player.takeDamage(this.currentMonster.attack);

                // 检查玩家是否死亡
                if (this.player.hp <= 0) {
                    this.handlePlayerDeath();
                    return true;
                }

                // 显示战斗结果
                this.showModal("战斗回合", 
                    `你对${this.currentMonster.name}造成了${damageToMonster}点伤害！\n` +
                    `${this.currentMonster.name}对你反击，造成${damageToPlayer}点伤害！\n` +
                    `当前生命值：${this.player.hp}/${this.player.maxHp}`
                );
                return true;

            // 使用道具
            case "useItem":
                if (this.player.inventory.items.length === 0) {
                    this.showModal("无可用道具", "你的背包中没有可使用的道具！");
                    return false;
                }

                // 生成道具选择弹窗
                let itemOptions = this.player.inventory.items.map((item, index) => 
                    `${index+1}. ${item.name}（${item.count}个）- ${item.effect}`
                ).join("\n");
                
                const itemIndex = prompt(`请选择要使用的道具（输入编号）：\n${itemOptions}`) - 1;
                if (isNaN(itemIndex) || itemIndex < 0 || itemIndex >= this.player.inventory.items.length) {
                    this.showModal("选择无效", "你选择了无效的道具编号！");
                    return false;
                }

                const useResult = this.player.useItem(itemIndex);
                if (useResult.success) {
                    this.showModal("使用道具", 
                        `${useResult.message}！\n` +
                        `当前生命值：${this.player.hp}/${this.player.maxHp}`
                    );
                    this.renderInventory(); // 更新背包显示
                } else {
                    this.showModal("使用失败", useResult.message);
                }
                return useResult.success;

            // 尝试逃跑
            case "escapeBattle":
                if (!this.currentMonster) return false;

                // 计算逃跑成功率（普通怪物70%，BOSS50%）
                const escapeRate = this.currentMonster.name.includes("BOSS") ? 0.5 : 0.7;
                const isEscapeSuccess = Math.random() < escapeRate;

                if (isEscapeSuccess) {
                    // 逃跑成功
                    this.currentMonster = null;
                    this.currentScene = "villageEntrance"; // 返回村庄入口
                    this.showModal("逃跑成功", "你成功逃离了战斗！");
                } else {
                    // 逃跑失败，被怪物攻击
                    const damageToPlayer = this.player.takeDamage(this.currentMonster.attack);

                    this.showModal("逃跑失败", 
                        `你尝试逃跑失败！\n${this.currentMonster.name}对你发动攻击，造成${damageToPlayer}点伤害！\n` +
                        `当前生命值：${this.player.hp}/${this.player.maxHp}`
                    );
                }
                return true;

            // 购买物品
            case "buyItem":
                const buyResult = this.player.buyItem(actionData);
                if (buyResult.success) {
                    this.showModal("购买成功", 
                        `${buyResult.message}，花费了${actionData.price}金币。\n` +
                        `剩余金币：${this.player.gold}`
                    );
                    this.renderInventory(); // 更新背包显示
                } else {
                    this.showModal("购买失败", buyResult.message);
                }
                return buyResult.success;

            // 获取任务奖励
            case "getQuestReward":
                if (!this.player.quests.active) {
                    this.showModal("无法领取", "你没有可领取奖励的任务");
                    return false;
                }
                
                // 发放任务奖励
                this.player.gold += actionData.reward.gold;
                this.player.addExp(actionData.reward.exp);
                this.player.getItem(actionData.reward.item);
                // 标记任务为已完成
                this.player.finishQuest();
                
                this.showModal("任务奖励", 
                    `你获得了任务奖励：\n` +
                    `金币：${actionData.reward.gold}\n` +
                    `经验值：${actionData.reward.exp}\n` +
                    `物品：${actionData.reward.item.name}（${actionData.reward.item.effect}）`
                );
                this.renderInventory(); // 更新背包显示
                return true;

            default:
                this.showModal("功能未实现", `该动作（${actionType}）暂未实现！`);
                return false;
        }
    }

    // 处理怪物死亡
    handleMonsterDeath() {
        const monster = this.currentMonster;
        let rewardText = `你击败了${monster.name}（${monster.level}级）！\n获得经验值：${monster.exp}点\n`;

        // 增加经验
        const leveledUp = this.player.addExp(monster.exp);
        if (leveledUp) {
            rewardText += `恭喜！你升级到了${this.player.level}级！\n`;
        }

        // 获得掉落物品
        if (monster.drop) {
            this.player.getItem({
                name: monster.drop.name,
                count: monster.drop.count,
                effect: `类型：${monster.drop.type}`,
                type: "material"
            });
            rewardText += `获得掉落物：${monster.drop.name}（${monster.drop.count}个）\n`;
        }

        // 检查任务进度
        const questUpdate = this.player.updateQuestProgress(monster.name);
        if (questUpdate.quest) {
            rewardText += `任务【${questUpdate.quest.name}】进度：${questUpdate.quest.currentCount}/${questUpdate.quest.targetCount}\n`;
            
            // 检查任务是否完成
            if (questUpdate.completed) {
                this.currentScene = "questCompleted";
                rewardText += `任务【${questUpdate.quest.name}】已完成！可以回村领取奖励了！\n`;
            }
        }

        // 重置战斗状态
        this.currentMonster = null;
        
        // 如果任务未完成，返回之前的场景
        if (!questUpdate.completed) {
            // 返回战斗前的场景
            this.currentScene = monster.name === "绿皮青蛙" ? "swampArea" : 
                               monster.name === "尖牙野兔" ? "forestEdge" : "forestDeep";
        }

        // 显示奖励弹窗
        this.showModal("战斗胜利", rewardText);
        this.renderInventory(); // 更新背包显示
    }

    // 处理玩家死亡
    handlePlayerDeath() {
        // 重置玩家状态（回到村庄，生命值恢复50%，损失少量金币）
        const goldLost = Math.floor(this.player.gold * 0.1);
        this.player.gold = Math.max(0, this.player.gold - goldLost);
        this.player.hp = Math.floor(this.player.maxHp * 0.5);
        this.currentMonster = null;
        this.currentScene = "villageSquare";

        this.showModal("战斗失败", 
            `你被${this.currentMonster?.name || "怪物"}击败了！\n` +
            `损失金币：${goldLost}（当前剩余：${this.player.gold}）\n` +
            `你在晨曦村复活，生命值恢复至${this.player.hp}/${this.player.maxHp}`
        );
    }

    // 显示弹窗
    showModal(title, desc) {
        this.elements.modalTitle.textContent = title;
        this.elements.modalDesc.textContent = desc;
        this.elements.modal.classList.remove("hidden");
    }

    // 更新状态面板
    updateStatusPanel() {
        this.elements.playerName.textContent = this.player.name;
        this.elements.level.textContent = this.player.level;
        this.elements.hp.textContent = this.player.hp;
        this.elements.maxHp.textContent = this.player.maxHp;
        this.elements.gold.textContent = this.player.gold;
        this.elements.attack.textContent = this.player.totalAttack;
        this.elements.defense.textContent = this.player.totalDefense;
    }

    // 更新任务面板
    updateQuestPanel() {
        if (this.player.quests.active) {
            const quest = this.player.quests.active;
            this.elements.activeQuestPanel.classList.remove("hidden");
            this.elements.activeQuestName.textContent = `当前任务：${quest.name}`;
            this.elements.activeQuestTarget.textContent = `消灭${quest.targetCount}只${quest.target}`;
            this.elements.activeQuestProgress.textContent = `${quest.currentCount}/${quest.targetCount}`;
            this.elements.activeQuestReward.textContent = quest.reward;
        } else {
            this.elements.activeQuestPanel.classList.add("hidden");
        }
    }
}

// 当页面加载完成后启动游戏
window.addEventListener("DOMContentLoaded", () => {
    // 确保DOM完全加载后再初始化游戏
    setTimeout(() => {
        new Game();
    }, 100);
});
    