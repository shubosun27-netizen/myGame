// 玩家类 - 管理玩家数据和行为
class Player {
    constructor() {
        // 基本属性
        this.name = "冒险者";
        this.level = 1;
        this.hp = 50;
        this.maxHp = 50;
        this.baseAttack = 5;
        this.baseDefense = 0;
        this.gold = 10;
        this.exp = 0;
        this.expToNextLevel = 100;
        
        // 装备系统 - 新增多个装备槽位
        this.equipment = {
            head: null,      // 头部
            shoulder: null,  // 肩部
            body: null,      // 身体
            hand: null,      // 手部
            leg: null,       // 腿部
            foot: null,      // 脚部
            bracelet: null,  // 手镯
            necklace: null,  // 项链
            weapon: {        // 武器
                name: "新手木剑",
                effect: "攻击力+3",
                attack: 3,
                type: "weapon"
            }
        };
        
        // 背包系统
        this.inventory = {
            items: [
                { name: "新手药水", count: 2, effect: "恢复20点生命值", type: "potion" }
            ],
            equipment: []  // 背包中的装备
        };
        
        // 任务系统
        this.quests = {
            active: null,
            completed: []
        };
    }
    
    // 获取总攻击力
    get totalAttack() {
        let attack = this.baseAttack;
        // 累加所有装备提供的攻击力
        if (this.equipment.weapon) attack += this.equipment.weapon.attack || 0;
        if (this.equipment.bracelet) attack += this.equipment.bracelet.attack || 0;
        if (this.equipment.necklace) attack += this.equipment.necklace.attack || 0;
        return attack;
    }
    
    // 获取总防御力
    get totalDefense() {
        let defense = this.baseDefense;
        // 累加所有装备提供的防御力
        if (this.equipment.head) defense += this.equipment.head.defense || 0;
        if (this.equipment.shoulder) defense += this.equipment.shoulder.defense || 0;
        if (this.equipment.body) defense += this.equipment.body.defense || 0;
        if (this.equipment.hand) defense += this.equipment.hand.defense || 0;
        if (this.equipment.leg) defense += this.equipment.leg.defense || 0;
        if (this.equipment.foot) defense += this.equipment.foot.defense || 0;
        if (this.equipment.bracelet) defense += this.equipment.bracelet.defense || 0;
        if (this.equipment.necklace) defense += this.equipment.necklace.defense || 0;
        return defense;
    }
    
    // 设置玩家名称
    setName(name) {
        this.name = name || "冒险者";
    }
    
    // 获得物品
    getItem(itemData) {
        // 检查是道具还是装备
        if (itemData.type === "weapon" || itemData.type === "armor") {
            // 装备添加到背包中的装备栏
            this.inventory.equipment.push({
                name: itemData.name,
                effect: itemData.effect,
                attack: itemData.attack || 0,
                defense: itemData.defense || 0,
                type: itemData.type,
                slot: itemData.slot || null  // 装备槽位
            });
            return itemData;
        } else {
            // 道具添加到物品栏
            const existingItem = this.inventory.items.find(item => item.name === itemData.name);
            if (existingItem) {
                existingItem.count += itemData.count || 1;
            } else {
                this.inventory.items.push({
                    name: itemData.name,
                    count: itemData.count || 1,
                    effect: itemData.effect,
                    type: itemData.type || "item"
                });
            }
            return existingItem || itemData;
        }
    }
    
    // 使用物品
    useItem(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.items.length) {
            return { success: false, message: "无效的物品索引" };
        }
        
        const item = this.inventory.items[itemIndex];
        
        // 处理不同类型物品的使用效果
        if (item.type === "potion") {
            // 药水恢复生命值
            const healAmount = parseInt(item.effect.match(/恢复(\d+)点生命值/)[1]);
            this.hp = Math.min(this.maxHp, this.hp + healAmount);
            
            // 减少物品数量
            item.count -= 1;
            if (item.count <= 0) {
                this.inventory.items.splice(itemIndex, 1);
            }
            
            return { 
                success: true, 
                message: `使用了${item.name}，恢复了${healAmount}点生命值` 
            };
        } else {
            return { success: false, message: `无法使用${item.name}` };
        }
    }
    
    // 出售物品
    sellItem(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.items.length) {
            return { success: false, message: "无效的物品索引" };
        }
        
        const item = this.inventory.items[itemIndex];
        // 简单定价：药水10金币，材料5金币
        const price = item.type === "potion" ? 10 : 5;
        
        // 增加金币
        this.gold += price * item.count;
        
        // 从背包移除
        const itemName = item.name;
        const count = item.count;
        this.inventory.items.splice(itemIndex, 1);
        
        return { 
            success: true, 
            message: `出售了${count}个${itemName}，获得${price * count}金币` 
        };
    }
    
    // 装备物品
    equipItem(itemIndex) {
        if (itemIndex < 0 || itemIndex >= this.inventory.equipment.length) {
            return { success: false, message: "无效的装备索引" };
        }
        
        const item = this.inventory.equipment[itemIndex];
        
        // 检查装备是否有对应的槽位
        if (!item.slot || !this.equipment.hasOwnProperty(item.slot)) {
            return { success: false, message: `无法装备${item.name}` };
        }
        
        // 如果该槽位已有装备，将其放回背包
        const currentEquipped = this.equipment[item.slot];
        if (currentEquipped) {
            this.inventory.equipment.push(currentEquipped);
        }
        
        // 装备新物品
        this.equipment[item.slot] = item;
        // 从背包移除
        this.inventory.equipment.splice(itemIndex, 1);
        
        return { 
            success: true, 
            message: `已装备${item.name}` 
        };
    }
    
    // 卸下装备
    unequipItem(slot) {
        if (!this.equipment.hasOwnProperty(slot)) {
            return { success: false, message: "无效的装备槽位" };
        }
        
        const item = this.equipment[slot];
        if (!item) {
            return { success: false, message: "该槽位没有装备" };
        }
        
        // 将装备放回背包
        this.inventory.equipment.push(item);
        // 卸下装备
        this.equipment[slot] = null;
        
        return { 
            success: true, 
            message: `已卸下${item.name}` 
        };
    }
    
    // 接受任务
    acceptQuest(questData) {
        this.quests.active = {
            id: questData.id,
            name: questData.name,
            target: questData.target,
            targetCount: questData.targetCount,
            currentCount: 0,
            reward: questData.reward,
            rewardData: questData.rewardData
        };
        return this.quests.active;
    }
    
    // 更新任务进度
    updateQuestProgress(monsterName) {
        if (!this.quests.active || this.quests.active.target !== monsterName) {
            return { quest: null, completed: false };
        }
        
        this.quests.active.currentCount += 1;
        const completed = this.quests.active.currentCount >= this.quests.active.targetCount;
        
        return {
            quest: this.quests.active,
            completed: completed
        };
    }
    
    // 完成任务
    finishQuest() {
        if (!this.quests.active) return false;
        
        this.quests.completed.push(this.quests.active.id);
        this.quests.active = null;
        return true;
    }
    
    // 恢复生命值
    restoreHp(type) {
        if (type === "full") {
            this.hp = this.maxHp;
        } else if (typeof type === "number") {
            this.hp = Math.min(this.maxHp, this.hp + type);
        }
    }
    
    // 受到伤害
    takeDamage(attack) {
        // 计算实际伤害（攻击方攻击力 - 玩家防御力，最低1点）
        const damage = Math.max(1, attack - this.totalDefense);
        this.hp = Math.max(0, this.hp - damage);
        return damage;
    }
    
    // 增加经验值
    addExp(amount) {
        this.exp += amount;
        let leveledUp = false;
        
        // 检查是否可以升级
        while (this.exp >= this.expToNextLevel) {
            this.level += 1;
            this.exp -= this.expToNextLevel;
            this.expToNextLevel = Math.floor(this.expToNextLevel * 1.5);
            
            // 升级属性提升
            this.maxHp += 30;
            this.hp = this.maxHp;
            this.baseAttack += 2;
            this.baseDefense += 1;
            
            leveledUp = true;
        }
        
        return leveledUp;
    }
    
    // 购买物品
    buyItem(itemData) {
        if (this.gold < itemData.price) {
            return { 
                success: false, 
                message: `金币不足，需要${itemData.price}金币` 
            };
        }
        
        // 扣除金币
        this.gold -= itemData.price;
        
        // 添加物品到背包
        this.getItem(itemData);
        
        return { 
            success: true, 
            message: `购买了${itemData.name}` 
        };
    }
}
    